const path = require('node:path');
const { app, BrowserWindow, dialog, session } = require('electron');

process.env.BLACK_HORIZON_EMBEDDED = '1';
process.env.NODE_ENV = 'production';

let mainWindow = null;
let runningServer = null;

const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
}

async function createMainWindow() {
  const serverModulePath = path.join(__dirname, '..', 'dist-electron', 'server.cjs');
  const distDir = path.join(__dirname, '..', 'dist');

  const { startServer } = require(serverModulePath);
  runningServer = await startServer({
    port: Number(process.env.PORT || 3000),
    distDir,
    forceProd: true,
  });

  // Ensure Pointer Lock (FPS mouselook) and Fullscreen work smoothly
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
    if (permission === 'pointerLock' || permission === 'fullscreen') {
      callback(true);
      return;
    }
    callback(false);
  });

  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 640,
    backgroundColor: '#06090e',
    title: 'OPERATION: BLACK HORIZON',
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  mainWindow.webContents.on('before-input-event', (event, input) => {
    if (input.type === 'keyDown' && input.key === 'F11' && mainWindow) {
      event.preventDefault();
      mainWindow.setFullScreen(!mainWindow.isFullScreen());
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  await mainWindow.loadURL(`http://127.0.0.1:${runningServer.port}`);
}

app.on('second-instance', () => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
  }
});

app.whenReady().then(async () => {
  try {
    await createMainWindow();
  } catch (err) {
    dialog.showErrorBox(
      'OPERATION: BLACK HORIZON — Ishga tushirish xatosi',
      `Ichki serverni ishga tushirib bo'lmadi:\n${err instanceof Error ? err.message : String(err)}`,
    );
    app.quit();
  }
});

app.on('window-all-closed', async () => {
  if (runningServer) {
    try {
      await runningServer.close();
    } catch {
      // Ignore shutdown errors
    }
    runningServer = null;
  }
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
