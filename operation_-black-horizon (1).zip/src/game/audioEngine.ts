export class TacticalAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private worldFilter: BiquadFilterNode | null = null;
  private rainSource: AudioBufferSourceNode | null = null;
  private rainGain: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private muted = false;
  private masterVolume = 0.75;

  public isMuted(): boolean {
    return this.muted;
  }

  public setMasterVolume(vol: number): void {
    this.masterVolume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        this.muted ? 0 : this.masterVolume,
        this.ctx.currentTime,
        0.03,
      );
    }
  }

  public setMuted(mute: boolean): void {
    this.muted = mute;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        mute ? 0 : this.masterVolume,
        this.ctx.currentTime,
        0.03,
      );
    }
  }

  public toggleMute(): boolean {
    this.setMuted(!this.muted);
    return this.muted;
  }

  public unlock(): void {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.muted ? 0 : this.masterVolume;

      this.worldFilter = this.ctx.createBiquadFilter();
      this.worldFilter.type = 'lowpass';
      this.worldFilter.frequency.value = 18000;

      this.worldFilter.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);

      this.noiseBuffer = this.createNoiseBuffer(2.0);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    this.startRainLoop();
  }

  private createNoiseBuffer(durationSec: number): AudioBuffer {
    const ctx = this.ctx!;
    const length = Math.floor(ctx.sampleRate * durationSec);
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }

  private startRainLoop(): void {
    if (!this.ctx || !this.noiseBuffer || !this.worldFilter || this.rainSource) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 1150;
    filter.Q.value = 0.65;

    const gain = this.ctx.createGain();
    gain.gain.value = 0.055;

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.worldFilter);
    src.start();

    this.rainSource = src;
    this.rainGain = gain;
  }

  public setRainVolume(indoor: boolean): void {
    if (!this.ctx || !this.rainGain) return;
    const target = indoor ? 0.015 : 0.055;
    this.rainGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.18);
  }

  public playSuppressedShot(caliber: '5.56x45mm' | '9x19mm', indoor: boolean): void {
    if (!this.ctx || !this.noiseBuffer || !this.worldFilter || this.muted) return;
    const now = this.ctx.currentTime;
    const pitchJitter = 0.94 + Math.random() * 0.12;

    // 1. Subsonic suppressor baffle puff
    const puff = this.ctx.createBufferSource();
    puff.buffer = this.noiseBuffer;
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = (caliber === '5.56x45mm' ? 1450 : 1100) * pitchJitter;
    bp.Q.value = 1.1;

    const puffGain = this.ctx.createGain();
    const tailSec = indoor ? 0.16 : 0.11;
    puffGain.gain.setValueAtTime(0.42, now);
    puffGain.gain.exponentialRampToValueAtTime(0.001, now + tailSec);

    puff.connect(bp);
    bp.connect(puffGain);
    puffGain.connect(this.worldFilter);
    puff.start(now);
    puff.stop(now + tailSec + 0.02);

    // 2. Mechanical bolt carrier thump
    const osc = this.ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime((caliber === '5.56x45mm' ? 190 : 150) * pitchJitter, now);
    osc.frequency.exponentialRampToValueAtTime(52, now + 0.055);
    const oscGain = this.ctx.createGain();
    oscGain.gain.setValueAtTime(0.32, now);
    oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.065);
    osc.connect(oscGain);
    oscGain.connect(this.worldFilter);
    osc.start(now);
    osc.stop(now + 0.07);
  }

  public playEnemyGunshot(distanceM: number, heavy: boolean): void {
    if (!this.ctx || !this.noiseBuffer || !this.worldFilter || this.muted) return;
    const now = this.ctx.currentTime;
    const atten = Math.max(0.06, Math.min(0.65, 10 / Math.max(4, distanceM)));

    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = heavy ? 1600 : 2400;

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(atten * (heavy ? 0.65 : 0.45), now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.24);

    src.connect(lp);
    lp.connect(g);
    g.connect(this.worldFilter);
    src.start(now);
    src.stop(now + 0.26);
  }

  public playSupersonicCrack(): void {
    if (!this.ctx || !this.noiseBuffer || !this.worldFilter || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(2200, now);
    osc.frequency.exponentialRampToValueAtTime(340, now + 0.045);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.22, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(g);
    g.connect(this.worldFilter);
    osc.start(now);
    osc.stop(now + 0.055);
  }

  public playHitMarker(headshot: boolean): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(headshot ? 1680 : 940, now);
    osc.frequency.exponentialRampToValueAtTime(headshot ? 1220 : 560, now + 0.05);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(headshot ? 0.24 : 0.16, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.055);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.06);
  }

  public playNvgToggle(activating: boolean): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(activating ? 720 : 1850, now);
    osc.frequency.exponentialRampToValueAtTime(activating ? 2450 : 380, now + 0.22);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.14, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.25);
  }

  public playReloadClick(empty: boolean): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const freqs = empty ? [360, 520, 740] : [410, 620];
    freqs.forEach((f, idx) => {
      const t = now + idx * 0.22;
      const osc = this.ctx!.createOscillator();
      osc.type = 'square';
      osc.frequency.setValueAtTime(f, t);
      const g = this.ctx!.createGain();
      g.gain.setValueAtTime(0.07, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.045);
      osc.connect(g);
      g.connect(this.masterGain!);
      osc.start(t);
      osc.stop(t + 0.05);
    });
  }

  public playRadioSquelch(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1420, now);
    osc.frequency.setValueAtTime(1180, now + 0.035);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.075, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.085);
  }

  public playDoorBreach(explosive: boolean): void {
    if (!this.ctx || !this.noiseBuffer || !this.worldFilter || this.muted) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = explosive ? 480 : 320;

    const g = this.ctx.createGain();
    const dur = explosive ? 0.72 : 0.18;
    g.gain.setValueAtTime(explosive ? 0.85 : 0.45, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);

    src.connect(lp);
    lp.connect(g);
    g.connect(this.worldFilter);
    src.start(now);
    src.stop(now + dur + 0.03);
  }

  public playFootstep(sprinting: boolean): void {
    if (!this.ctx || !this.noiseBuffer || !this.worldFilter || this.muted) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 380 + Math.random() * 140;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(sprinting ? 0.11 : 0.055, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.075);
    src.connect(lp);
    lp.connect(g);
    g.connect(this.worldFilter);
    src.start(now);
    src.stop(now + 0.08);
  }

  public triggerFlashbangMuffle(): void {
    if (!this.ctx || !this.worldFilter || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    this.worldFilter.frequency.setValueAtTime(420, now);
    this.worldFilter.frequency.exponentialRampToValueAtTime(18000, now + 2.4);

    // High-pitched tinnitus ring
    const ring = this.ctx.createOscillator();
    ring.type = 'sine';
    ring.frequency.value = 4150;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.09, now);
    g.gain.exponentialRampToValueAtTime(0.0005, now + 2.1);
    ring.connect(g);
    g.connect(this.masterGain);
    ring.start(now);
    ring.stop(now + 2.2);
  }

  public playGrenadePinPull(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1650, now);
    osc.frequency.exponentialRampToValueAtTime(2400, now + 0.055);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.14, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.09);
  }

  public playGrenadeBounce(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(520 + Math.random() * 140, now);
    osc.frequency.exponentialRampToValueAtTime(190, now + 0.045);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.12, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.055);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.06);
  }

  /**
   * Heavy multi-layered Frag Grenade detonation (concussion sub-bass + blast crack + shrapnel + canyon tail)
   */
  public playGrenadeExplosion(distanceM: number): void {
    if (!this.ctx || !this.noiseBuffer || !this.worldFilter || this.muted) return;
    const now = this.ctx.currentTime;
    const atten = Math.max(0.22, Math.min(1.0, 14 / Math.max(4, distanceM)));

    // 1. Sub-bass concussion shockwave
    const sub = this.ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(125, now);
    sub.frequency.exponentialRampToValueAtTime(28, now + 0.45);
    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.95 * atten, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
    sub.connect(subGain);
    subGain.connect(this.worldFilter);
    sub.start(now);
    sub.stop(now + 0.58);

    // 2. High-energy blast front crack
    const crack = this.ctx.createBufferSource();
    crack.buffer = this.noiseBuffer;
    const hp = this.ctx.createBiquadFilter();
    hp.type = 'bandpass';
    hp.frequency.value = 1400;
    hp.Q.value = 0.5;
    const crackGain = this.ctx.createGain();
    crackGain.gain.setValueAtTime(0.85 * atten, now);
    crackGain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    crack.connect(hp);
    hp.connect(crackGain);
    crackGain.connect(this.worldFilter);
    crack.start(now);
    crack.stop(now + 0.24);

    // 3. Long canyon rumble & debris echo tail
    const rumble = this.ctx.createBufferSource();
    rumble.buffer = this.noiseBuffer;
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(750, now);
    lp.frequency.exponentialRampToValueAtTime(140, now + 1.4);
    const rumbleGain = this.ctx.createGain();
    rumbleGain.gain.setValueAtTime(0.75 * atten, now + 0.03);
    rumbleGain.gain.exponentialRampToValueAtTime(0.001, now + 1.55);
    rumble.connect(lp);
    lp.connect(rumbleGain);
    rumbleGain.connect(this.worldFilter);
    rumble.start(now);
    rumble.stop(now + 1.6);
  }

  public playHealBandage(): void {
    if (!this.ctx || !this.noiseBuffer || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 900;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.08, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
    src.connect(bp);
    bp.connect(g);
    g.connect(this.masterGain);
    src.start(now);
    src.stop(now + 0.24);
  }

  public playLootPickup(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    [520, 780].forEach((freq, i) => {
      const t = now + i * 0.06;
      const osc = this.ctx!.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      const g = this.ctx!.createGain();
      g.gain.setValueAtTime(0.11, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
      osc.connect(g);
      g.connect(this.masterGain!);
      osc.start(t);
      osc.stop(t + 0.1);
    });
  }

  public playAirdropHorn(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(110, now);
    osc.frequency.linearRampToValueAtTime(92, now + 1.1);
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 340;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(0.18, now + 0.25);
    g.gain.exponentialRampToValueAtTime(0.001, now + 1.2);
    osc.connect(lp);
    lp.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 1.25);
  }

  public playAllyHelpCallout(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    [880, 660, 880].forEach((freq, idx) => {
      const t = now + idx * 0.11;
      const osc = this.ctx!.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      const g = this.ctx!.createGain();
      g.gain.setValueAtTime(0.11, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
      osc.connect(g);
      g.connect(this.masterGain!);
      osc.start(t);
      osc.stop(t + 0.1);
    });
  }

  public playReviveComplete(): void {
    if (!this.ctx || !this.masterGain || this.muted) return;
    const now = this.ctx.currentTime;
    [523.25, 659.25, 783.99].forEach((freq, idx) => {
      const t = now + idx * 0.08;
      const osc = this.ctx!.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      const g = this.ctx!.createGain();
      g.gain.setValueAtTime(0.13, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
      osc.connect(g);
      g.connect(this.masterGain!);
      osc.start(t);
      osc.stop(t + 0.15);
    });
  }

  public dispose(): void {
    try {
      this.rainSource?.stop();
      void this.ctx?.close();
    } catch {
      // ignore audio context cleanup errors
    }
    this.rainSource = null;
    this.ctx = null;
  }
}
