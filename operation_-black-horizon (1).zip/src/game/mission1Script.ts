import type { EnemyArchetype, RadioCommsLine } from './types';

export interface ScriptTriggerZone {
  id: string;
  phase: number;
  label: string;
  position: [number, number, number];
  radiusM: number;
  lightingCue: string;
  audioCue: string;
  commsSequence: RadioCommsLine[];
}

export interface EnemySpawnPoint {
  id: string;
  callsign: string;
  archetype: EnemyArchetype;
  phase: number;
  position: [number, number, number];
  patrolTarget?: [number, number, number];
  facingYawRad: number;
  alertGroup: 'checkpoint' | 'courtyard' | 'sniper' | 'bunker' | 'qrf';
}

export interface BreachDoorSpec {
  id: string;
  label: string;
  position: [number, number, number];
  yawRad: number;
  widthM: number;
  heightM: number;
  locked: boolean;
}

export interface MissionPhaseObjective {
  phase: number;
  title: string;
  targetPosition: [number, number, number];
}

export const MISSION_1_OBJECTIVES: MissionPhaseObjective[] = [
  {
    phase: 0,
    title: 'INFILTRATE PERIMETER CHECKPOINT',
    targetPosition: [0, 0, 16],
  },
  {
    phase: 1,
    title: 'BREACH COMPOUND & NEUTRALIZE OVERWATCH',
    targetPosition: [-9.5, 0, 2],
  },
  {
    phase: 2,
    title: 'BREACH COMMAND BUNKER // SECURE AEGIS DRIVE',
    targetPosition: [0, 0, -26],
  },
  {
    phase: 3,
    title: 'REACH EXFIL LZ SPECTER-ACTUAL',
    targetPosition: [22, 0, -30],
  },
];

export const MISSION_1_BREACH_DOORS: BreachDoorSpec[] = [
  {
    id: 'DOOR_ARMORY',
    label: 'ARMORY WING ACCESS',
    position: [-9.5, 0, 2],
    yawRad: Math.PI / 2,
    widthM: 1.5,
    heightM: 2.35,
    locked: false,
  },
  {
    id: 'DOOR_BARRACKS',
    label: 'BARRACKS EAST DOOR',
    position: [9.5, 0, 0],
    yawRad: -Math.PI / 2,
    widthM: 1.5,
    heightM: 2.35,
    locked: false,
  },
  {
    id: 'DOOR_BUNKER',
    label: 'COMMAND BUNKER BLAST DOOR',
    position: [0, 0, -18],
    yawRad: 0,
    widthM: 1.9,
    heightM: 2.45,
    locked: true,
  },
];

export const MISSION_1_SPAWNS: EnemySpawnPoint[] = [
  // Phase 0: Checkpoint Sentries
  {
    id: 'VG_SENTRY_01',
    callsign: 'Vanguard Patrol-1',
    archetype: 'infantry',
    phase: 0,
    position: [-3.5, 0, 15.5],
    patrolTarget: [2.5, 0, 15.5],
    facingYawRad: 0,
    alertGroup: 'checkpoint',
  },
  {
    id: 'VG_SENTRY_02',
    callsign: 'Vanguard Patrol-2',
    archetype: 'infantry',
    phase: 0,
    position: [5.0, 0, 16.5],
    facingYawRad: 0.4,
    alertGroup: 'checkpoint',
  },

  // Phase 1: Courtyard, Armory & Sniper Watchtower
  {
    id: 'VG_SNIPER_01',
    callsign: 'Vanguard Overwatch',
    archetype: 'sniper',
    phase: 1,
    position: [-18, 4.8, -14],
    facingYawRad: 0.35,
    alertGroup: 'sniper',
  },
  {
    id: 'VG_BREACHER_01',
    callsign: 'Vanguard Breacher-1',
    archetype: 'breacher',
    phase: 1,
    position: [-13, 0, -1.5],
    facingYawRad: 1.57,
    alertGroup: 'courtyard',
  },
  {
    id: 'VG_INF_03',
    callsign: 'Vanguard Rifleman-3',
    archetype: 'infantry',
    phase: 1,
    position: [1.5, 0, -6],
    patrolTarget: [-4, 0, -6],
    facingYawRad: 0,
    alertGroup: 'courtyard',
  },
  {
    id: 'VG_BREACHER_02',
    callsign: 'Vanguard Breacher-2',
    archetype: 'breacher',
    phase: 1,
    position: [12, 0, -2],
    facingYawRad: -1.4,
    alertGroup: 'courtyard',
  },
  {
    id: 'VG_INF_04',
    callsign: 'Vanguard Rifleman-4',
    archetype: 'infantry',
    phase: 1,
    position: [-4.5, 0, -11.5],
    facingYawRad: 0.2,
    alertGroup: 'courtyard',
  },

  // Phase 2: Command Bunker Guard Detail
  {
    id: 'VG_OFFICER_01',
    callsign: 'Syndicate Cmdr. Guard',
    archetype: 'officer',
    phase: 2,
    position: [-2.2, 0, -24.5],
    facingYawRad: 0.15,
    alertGroup: 'bunker',
  },
  {
    id: 'VG_INF_05',
    callsign: 'Bunker Security-1',
    archetype: 'infantry',
    phase: 2,
    position: [3.6, 0, -23.0],
    facingYawRad: -0.25,
    alertGroup: 'bunker',
  },

  // Phase 3: QRF Counter-Attack on Telemetry Extraction
  {
    id: 'VG_QRF_01',
    callsign: 'Vanguard QRF-Alpha',
    archetype: 'breacher',
    phase: 3,
    position: [16, 0, -14],
    facingYawRad: -0.8,
    alertGroup: 'qrf',
  },
  {
    id: 'VG_QRF_02',
    callsign: 'Vanguard QRF-Bravo',
    archetype: 'infantry',
    phase: 3,
    position: [19, 0, -22],
    facingYawRad: -1.2,
    alertGroup: 'qrf',
  },
  {
    id: 'VG_QRF_03',
    callsign: 'Vanguard QRF-Charlie',
    archetype: 'infantry',
    phase: 3,
    position: [12, 0, -27],
    facingYawRad: 0.9,
    alertGroup: 'qrf',
  },
];

export const MISSION_1_TRIGGERS: ScriptTriggerZone[] = [
  {
    id: 'TRG_01_INSERTION',
    phase: 0,
    label: 'Insertion Ridge // 02:14 Local',
    position: [0, 0, 42],
    radiusM: 6,
    lightingCue:
      'Moonlight Rim (2.2 lx cool slate #6a86a8), heavy rain sheet fog (#060a10), distant sodium floodlight cones at Gatehouse.',
    audioCue: 'Ambient mountain wind + heavy rain loop + suppressed bolt check + radio squelch.',
    commsSequence: [
      {
        id: 'L01',
        speaker: 'IRIS',
        callsign: 'OVERLORD // IRIS',
        text: 'Specter-One, you are dark over Kashgar ridge. Vanguard Syndicate locked down the Soviet relay two hours ago.',
        durationSec: 4.8,
      },
      {
        id: 'L02',
        speaker: 'DAGGER',
        callsign: 'SPECTER-TWO // DAGGER',
        text: 'Warden, I have eyes on two gate sentries from the north scree. Drop your NVGs [N] and take out that floodlight transformer.',
        durationSec: 5.0,
      },
      {
        id: 'L03',
        speaker: 'WARDEN',
        callsign: 'SPECTER-ONE // WARDEN',
        text: 'Copy, Dagger. Suppressors hot. Moving on the checkpoint.',
        durationSec: 3.4,
      },
    ],
  },
  {
    id: 'TRG_02_CHECKPOINT',
    phase: 0,
    label: 'Outer Checkpoint Gate',
    position: [0, 0, 17],
    radiusM: 8,
    lightingCue:
      'Sodium floodlight #1 (3200K warm amber) casts hard shadows across Jersey barriers; flickers and dies if transformer is shot.',
    audioCue: 'Wet gravel footsteps, diesel generator hum at (-7, 0, 16), Vanguard sentry chatter.',
    commsSequence: [
      {
        id: 'L04',
        speaker: 'VANGUARD',
        callsign: 'VANGUARD PATROL-1',
        text: 'Keep your sector scanned. Volkov wants the Aegis uplink encrypted before dawn.',
        durationSec: 4.0,
      },
      {
        id: 'L05',
        speaker: 'DAGGER',
        callsign: 'SPECTER-TWO // DAGGER',
        text: 'Mount your carbine [Q] on the concrete barriers for stability. Stay quiet or they will wake the courtyard.',
        durationSec: 4.4,
      },
    ],
  },
  {
    id: 'TRG_03_COURTYARD',
    phase: 1,
    label: 'Main Compound Courtyard',
    position: [0, 0, 4],
    radiusM: 9,
    lightingCue:
      'Sweeping Guard Tower searchlight at (-18, 6.5, -14); sniper IR laser visible only through GPNVG-18 Night Vision.',
    audioCue: 'Metallic rain on MRAP hull, distant thunder crack, sniper laser warning chirp.',
    commsSequence: [
      {
        id: 'L06',
        speaker: 'DAGGER',
        callsign: 'SPECTER-TWO // DAGGER',
        text: 'Contacts! Marksman in the northwest watchtower—watch his IR beam under NVGs. Breachers inside the armory wing.',
        durationSec: 5.2,
      },
      {
        id: 'L07',
        speaker: 'IRIS',
        callsign: 'OVERLORD // IRIS',
        text: 'Thermal shows heavy plating on the Command Bunker blast door to the north. Use [F] to peek, [G] to bash, or [B] to plant a breach charge.',
        durationSec: 5.2,
      },
    ],
  },
  {
    id: 'TRG_04_BUNKER_BREACH',
    phase: 2,
    label: 'Command Bunker Interior',
    position: [0, 0, -21],
    radiusM: 5,
    lightingCue:
      'Interior shifts from rain-slick exterior to claustrophobic red emergency strobes & cold CRT server rack glow (#18a0c8).',
    audioCue: 'Acoustic reverb switches from outdoor canyon tail to tight concrete bunker slap-back.',
    commsSequence: [
      {
        id: 'L08',
        speaker: 'WARDEN',
        callsign: 'SPECTER-ONE // WARDEN',
        text: 'Bunker breached. Clearing command deck—eyes on the Aegis Sat-Link terminal.',
        durationSec: 4.0,
      },
      {
        id: 'L09',
        speaker: 'IRIS',
        callsign: 'OVERLORD // IRIS',
        text: 'Pull the drive from the main console [F]. Move fast—Vanguard QRF just scrambled from the eastern ridge.',
        durationSec: 4.5,
      },
    ],
  },
  {
    id: 'TRG_05_EXFIL',
    phase: 3,
    label: 'Aegis Extracted // Exfil Dash',
    position: [0, 0, -26],
    radiusM: 3.5,
    lightingCue:
      'Green IR strobe beacon pulses at Exfil LZ (22, 0, -30); alarm klaxon bathes east courtyard in pulsing crimson.',
    audioCue: 'Alarm klaxon pulse + helicopter turbine approach in the far northeast canyon.',
    commsSequence: [
      {
        id: 'L10',
        speaker: 'WARDEN',
        callsign: 'SPECTER-ONE // WARDEN',
        text: 'Aegis drive secured! Volkov already scrubbed the secondary nodes—we have to extract now!',
        durationSec: 4.4,
      },
      {
        id: 'L11',
        speaker: 'DAGGER',
        callsign: 'SPECTER-TWO // DAGGER',
        text: 'QRF breaching the east flank! Pop smoke and sprint to the green IR strobe at LZ Specter-Actual!',
        durationSec: 4.6,
      },
    ],
  },
];
