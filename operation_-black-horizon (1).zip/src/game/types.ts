export type GameState = 'title' | 'playing' | 'paused' | 'gameover';

export type GameMode = 'classic' | 'arena_4v4' | 'duel_1v1';

export type CameraPerspective = 'fpp' | 'tpp';

export type TacticalStance = 'standing' | 'crouched' | 'prone' | 'sliding' | 'tactical_sprint';

export type WeaponId = 'mk18_suppressed' | 'p226_suppressed';

export type CaliberType = '5.56x45mm' | '9x19mm';

export type SurfaceMaterial = 'flesh' | 'wood' | 'sheet_metal' | 'concrete' | 'armor_plate';

export interface WeaponSpec {
  id: WeaponId;
  name: string;
  designation: string;
  caliber: CaliberType;
  suppressed: boolean;
  magCapacity: number;
  reserveMax: number;
  rpm: number;
  muzzleVelocityMps: number;
  baseDamage: number;
  headshotMultiplier: number;
  penetrationPowerMm: number;
  adsTimeSec: number;
  tacSprintToFireSec: number;
  recoilPitchDeg: number;
  recoilYawDeg: number;
  hipSpreadDeg: number;
  adsSpreadDeg: number;
  tacticalReloadSec: number;
  emptyReloadSec: number;
}

export interface WeaponRuntimeState {
  id: WeaponId;
  magAmmo: number;
  chambered: boolean;
  reserveAmmo: number;
  isReloading: boolean;
  reloadTimer: number;
  reloadDuration: number;
  fireCooldown: number;
  burstIndex: number;
}

export type EnemyArchetype = 'infantry' | 'breacher' | 'sniper' | 'officer';

export type DoorInteractionMode = 'peek' | 'silent_open' | 'bash' | 'breach_charge';

export interface RadioCommsLine {
  id: string;
  speaker: 'IRIS' | 'DAGGER' | 'WARDEN' | 'VANGUARD' | 'SYSTEM';
  callsign: string;
  text: string;
  durationSec: number;
}

export type LootItemType = 'medkit' | 'bandage' | 'grenade' | 'ammo';

export interface LootCrateContents {
  medkits: number;
  bandages: number;
  grenades: number;
  ammo: number;
  isAirdrop?: boolean;
}

export interface NearbyLootHud {
  crateId: string;
  distanceM: number;
  contents: LootCrateContents;
}

export interface MinimapBlip {
  x: number; // world X relative to player (meters)
  z: number; // world Z relative to player (meters)
  kind: 'enemy' | 'loot' | 'objective' | 'grenade' | 'ally' | 'ally_knocked' | 'airdrop';
}

export interface IncomingGrenadeAlert {
  distanceM: number;
  bearingRad: number;
  fuseRemainingSec: number;
}

export interface TeammateStatus {
  id: string;
  callsign: string;
  hp: number;
  maxHp: number;
  state: 'alive' | 'knocked' | 'dead';
  knockedTimerSec: number;
  distanceM: number;
}

export interface RevivePromptHud {
  allyId: string;
  callsign: string;
  progress: number; // 0..1
  isReviving: boolean;
  bleedoutSec: number;
}

export interface AirdropStatusHud {
  nextDropInSec: number;
  activeDropCount: number;
  nearestDropDistanceM: number | null;
  justDroppedBannerSec: number;
}

export interface ArenaScoreHud {
  blueKills: number;
  redKills: number;
  targetKills: number;
  timeRemainingSec: number;
}

export interface DuelScoreHud {
  roomCode: string;
  myName: string;
  opponentName: string;
  myKills: number;
  opponentKills: number;
  targetKills: 10 | 20 | 30 | 40;
  timeRemainingSec: number;
  opponentConnected: boolean;
}

export interface GameSettings {
  lookSensitivity: number; // 0.3 .. 2.5 (default 1.0)
  adsSensitivity: number; // 0.3 .. 2.0 (default 0.75)
  invertY: boolean;
  fov: number; // 65 .. 95 (default 74)
  masterVolume: number; // 0 .. 1 (default 0.75)
}

export const DEFAULT_GAME_SETTINGS: GameSettings = {
  lookSensitivity: 1.0,
  adsSensitivity: 0.75,
  invertY: false,
  fov: 74,
  masterVolume: 0.75,
};

export interface HudSnapshot {
  gameState: GameState;
  gameMode: GameMode;
  cameraPerspective: CameraPerspective;
  outcome: 'none' | 'victory' | 'defeat' | 'draw';
  hp: number;
  maxHp: number;
  stance: TacticalStance;
  isMounted: boolean;
  canMount: boolean;
  isAds: boolean;
  nvgActive: boolean;
  nvgBattery: number;
  weaponId: WeaponId;
  weaponName: string;
  magAmmo: number;
  chambered: boolean;
  reserveAmmo: number;
  mk18ReserveAmmo: number;
  p226ReserveAmmo: number;
  isReloading: boolean;
  ammoRevealTimer: number;
  grenadeCount: number;
  medkitCount: number;
  bandageCount: number;
  bagWeightKg: number;
  bagMaxKg: number;
  isHealing: boolean;
  healKind: 'medkit' | 'bandage' | null;
  healProgress: number; // 0..1
  nearbyLoot: NearbyLootHud | null;
  incomingGrenade: IncomingGrenadeAlert | null;
  teammates: TeammateStatus[];
  nearbyKnockedAlly: RevivePromptHud | null;
  airdropStatus: AirdropStatusHud;
  arenaScore: ArenaScoreHud | null;
  duelScore: DuelScoreHud | null;
  respawnCountdownSec: number;
  minimapBlips: MinimapBlip[];
  headingDeg: number;
  objectiveLabel: string;
  objectiveDistanceM: number;
  objectiveBearingDeg: number;
  phaseIndex: number;
  totalPhases: number;
  activeComms: RadioCommsLine | null;
  interactPrompt: string | null;
  damageFlashAlpha: number;
  damageDirRad: number | null;
  hitMarkerTimer: number;
  hitMarkerHeadshot: boolean;
  flashbangStunTimer: number;
  pointerLocked: boolean;
  isMuted: boolean;
  elapsedSec: number;
  kills: number;
  headshots: number;
  shotsFired: number;
  shotsHit: number;
  stealthAlerted: boolean;
  breachesCompleted: number;
}
