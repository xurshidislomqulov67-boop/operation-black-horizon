export type TargetKillsOption = 10 | 20 | 30 | 40;

export const TARGET_KILLS_OPTIONS: readonly TargetKillsOption[] = [10, 20, 30, 40];

export const MATCH_DURATION_OPTIONS: readonly { label: string; sec: number }[] = [
  { label: '3 MIN', sec: 180 },
  { label: '5 MIN', sec: 300 },
  { label: '8 MIN', sec: 480 },
  { label: '10 MIN', sec: 600 },
];

export interface MultiplayerPlayerSummary {
  slot: 1 | 2;
  name: string;
  kills: number;
  hp: number;
  connected: boolean;
}

export interface MultiplayerRoomState {
  code: string;
  status: 'waiting' | 'playing' | 'finished';
  targetKills: TargetKillsOption;
  durationSec: number;
  timeRemainingSec: number;
  mySlot: 1 | 2 | null;
  winnerSlot: 1 | 2 | 'draw' | null;
  players: MultiplayerPlayerSummary[];
}

export interface RemotePlayerPose {
  slot: 1 | 2;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  stance: 'standing' | 'crouched' | 'prone' | 'sliding' | 'tactical_sprint';
  weaponId: 'mk18_suppressed' | 'p226_suppressed';
  isFiring: boolean;
  isReloading: boolean;
}

export interface RemoteShotFx {
  slot: 1 | 2;
  origin: [number, number, number];
  hitPoint: [number, number, number];
  weaponId: 'mk18_suppressed' | 'p226_suppressed';
}

export type ClientToServerMsg =
  | {
      type: 'create_room';
      playerName: string;
      targetKills: TargetKillsOption;
      durationSec: number;
    }
  | {
      type: 'join_room';
      code: string;
      playerName: string;
    }
  | {
      type: 'update_room_config';
      targetKills: TargetKillsOption;
      durationSec: number;
    }
  | {
      type: 'start_match';
    }
  | {
      type: 'rematch';
    }
  | {
      type: 'leave_room';
    }
  | {
      type: 'player_state';
      pose: Omit<RemotePlayerPose, 'slot'>;
    }
  | {
      type: 'player_shot_fx';
      origin: [number, number, number];
      hitPoint: [number, number, number];
      weaponId: 'mk18_suppressed' | 'p226_suppressed';
    }
  | {
      type: 'player_hit';
      damage: number;
      headshot: boolean;
    }
  | {
      type: 'player_heal';
      amount: number;
      capHp: number;
    };

export type ServerToClientMsg =
  | {
      type: 'room_state';
      room: MultiplayerRoomState;
    }
  | {
      type: 'match_started';
      room: MultiplayerRoomState;
    }
  | {
      type: 'remote_pose';
      pose: RemotePlayerPose;
    }
  | {
      type: 'remote_shot_fx';
      fx: RemoteShotFx;
    }
  | {
      type: 'damage_event';
      victimSlot: 1 | 2;
      attackerSlot: 1 | 2;
      victimHp: number;
      headshot: boolean;
    }
  | {
      type: 'kill_event';
      killerSlot: 1 | 2;
      victimSlot: 1 | 2;
      p1Kills: number;
      p2Kills: number;
      headshot: boolean;
      respawnDelaySec: number;
    }
  | {
      type: 'match_over';
      room: MultiplayerRoomState;
    }
  | {
      type: 'error';
      message: string;
    };

export function isValidTargetKills(value: number): value is TargetKillsOption {
  return value === 10 || value === 20 || value === 30 || value === 40;
}

export function clampDurationSec(sec: number): number {
  if (!Number.isFinite(sec)) return 300;
  return Math.max(60, Math.min(1800, Math.round(sec)));
}

export function normalizeRoomCode(raw: string): string {
  return raw
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 6);
}

export function buildInviteUrl(baseOrigin: string, roomCode: string): string {
  const cleanOrigin = baseOrigin.replace(/\/+$/, '');
  const code = normalizeRoomCode(roomCode);
  return `${cleanOrigin}/?room=${encodeURIComponent(code)}`;
}

export function resolveDuelWinner(
  p1Kills: number,
  p2Kills: number,
  targetKills: TargetKillsOption,
  timeRemainingSec: number,
): 1 | 2 | 'draw' | null {
  if (p1Kills >= targetKills && p1Kills > p2Kills) return 1;
  if (p2Kills >= targetKills && p2Kills > p1Kills) return 2;
  if (p1Kills >= targetKills && p2Kills >= targetKills) {
    return p1Kills === p2Kills ? 'draw' : p1Kills > p2Kills ? 1 : 2;
  }
  if (timeRemainingSec <= 0) {
    if (p1Kills === p2Kills) return 'draw';
    return p1Kills > p2Kills ? 1 : 2;
  }
  return null;
}

export function generateRoomCode(existingCodes: Set<string>): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let attempt = 0; attempt < 64; attempt += 1) {
    let code = '';
    for (let i = 0; i < 4; i += 1) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    if (!existingCodes.has(code)) return code;
  }
  return `BH${Math.floor(10 + Math.random() * 89)}`;
}
