import test from 'node:test';
import assert from 'node:assert/strict';
import {
  AIRDROP_INTERVAL_SEC,
  ARENA_TARGET_KILLS,
  ENEMY_SPEED_CONFIG,
  KNOCKED_BLEEDOUT_SEC,
  MOUNT_RECOIL_MULTIPLIER,
  WEAPON_SPECS,
  completeReload,
  computeArenaMatchOutcome,
  computeBagWeightKg,
  computeBallisticDropAndDamage,
  computeEffectiveAdsTimeSec,
  computeExplosionDamage,
  computeHealOutcome,
  computeMaterialPenetration,
  computeShotRecoil,
  computeTppCameraPosition,
  consumeRoundOnFire,
  createAirdropSupplyContents,
  createEnemyLootDrop,
  createInitialWeaponState,
  getEyeHeightForStance,
  getTargetSpeedMps,
  getTotalLoadedAmmo,
  startReload,
  stepAngleRad,
  stepKnockoutBleedout,
  stepSlideVelocity,
} from './tacticalPhysics';

test('tactical movement speeds and eye heights match stance hierarchy', () => {
  assert.ok(
    getTargetSpeedMps('tactical_sprint', false, false) >
      getTargetSpeedMps('standing', false, false),
  );
  assert.ok(
    getTargetSpeedMps('standing', false, false) >
      getTargetSpeedMps('crouched', false, false),
  );
  assert.ok(
    getTargetSpeedMps('crouched', false, false) >
      getTargetSpeedMps('prone', false, false),
  );
  assert.equal(getTargetSpeedMps('standing', false, true), 0);
  assert.ok(getEyeHeightForStance('standing') > getEyeHeightForStance('crouched'));
  assert.ok(getEyeHeightForStance('crouched') > getEyeHeightForStance('prone'));
});

test('tactical slide decays exponentially and ends at crouch speed', () => {
  const { nextSpeedMps, finished } = stepSlideVelocity(8.4, 0.15);
  assert.ok(nextSpeedMps < 8.4 && nextSpeedMps > 2.4);
  assert.equal(finished, false);

  const endStep = stepSlideVelocity(2.45, 0.2);
  assert.equal(endStep.finished, true);
  assert.equal(endStep.nextSpeedMps, 2.5);
});

test('tactical sprint imposes ADS recovery penalty while mounting accelerates ADS', () => {
  const mk18 = WEAPON_SPECS.mk18_suppressed;
  const normalAds = computeEffectiveAdsTimeSec(mk18, false, false);
  const sprintAds = computeEffectiveAdsTimeSec(mk18, true, false);
  const mountedAds = computeEffectiveAdsTimeSec(mk18, false, true);

  assert.ok(sprintAds > normalAds);
  assert.ok(mountedAds < normalAds);
});

test('weapon mounting reduces recoil by exactly 65%', () => {
  const mk18 = WEAPON_SPECS.mk18_suppressed;
  const unmounted = computeShotRecoil(mk18, 0, 'standing', false);
  const mounted = computeShotRecoil(mk18, 0, 'standing', true);

  const ratio = mounted.pitchDeg / unmounted.pitchDeg;
  assert.ok(Math.abs(ratio - MOUNT_RECOIL_MULTIPLIER) < 1e-6);
  assert.ok(Math.abs(ratio - 0.35) < 1e-6);
});

test('ballistic drop increases quadratically with distance and 5.56mm penetrates wood/sheet metal', () => {
  const mk18 = WEAPON_SPECS.mk18_suppressed;
  const close = computeBallisticDropAndDamage(mk18, 25, false);
  const far = computeBallisticDropAndDamage(mk18, 100, false);
  const headshot = computeBallisticDropAndDamage(mk18, 25, true);

  assert.ok(far.dropM > close.dropM * 10);
  assert.ok(headshot.impactDamage > close.impactDamage);

  const woodPen = computeMaterialPenetration(mk18, 'wood');
  const concretePen = computeMaterialPenetration(mk18, 'concrete');
  assert.equal(woodPen.penetrated, true);
  assert.equal(concretePen.penetrated, false);
});

test('tactical reload preserves +1 chambered round and runs faster than empty reload', () => {
  let state = createInitialWeaponState('mk18_suppressed');
  assert.equal(getTotalLoadedAmmo(state), 31); // 30 + 1

  // Fire 5 rounds -> 25 in mag + 1 chambered = 26
  for (let i = 0; i < 5; i++) {
    const res = consumeRoundOnFire(state);
    assert.equal(res.fired, true);
    state = { ...res.nextState, fireCooldown: 0 };
  }
  assert.equal(getTotalLoadedAmmo(state), 26);
  assert.equal(state.chambered, true);

  const tacReload = startReload(state);
  assert.equal(tacReload.reloadDuration, WEAPON_SPECS.mk18_suppressed.tacticalReloadSec);
  const doneTac = completeReload(tacReload);
  assert.equal(getTotalLoadedAmmo(doneTac), 31);
  assert.equal(doneTac.reserveAmmo, 145);

  // Empty entire weapon
  let emptyState = { ...doneTac, magAmmo: 1, chambered: false, fireCooldown: 0 };
  const lastShot = consumeRoundOnFire(emptyState);
  emptyState = lastShot.nextState;
  assert.equal(getTotalLoadedAmmo(emptyState), 0);

  const emptyReload = startReload(emptyState);
  assert.equal(emptyReload.reloadDuration, WEAPON_SPECS.mk18_suppressed.emptyReloadSec);
  const doneEmpty = completeReload(emptyReload);
  assert.equal(doneEmpty.magAmmo, 29);
  assert.equal(doneEmpty.chambered, true);
  assert.equal(getTotalLoadedAmmo(doneEmpty), 30);
});

test('frag grenade blast damage falls off smoothly with distance', () => {
  const core = computeExplosionDamage(1.0, 165, 8.0);
  const mid = computeExplosionDamage(4.5, 165, 8.0);
  const edge = computeExplosionDamage(8.5, 165, 8.0);
  assert.equal(core, 165);
  assert.ok(mid > 40 && mid < 140);
  assert.equal(edge, 0);
});

test('aptechka first aid kit restores up to 100 HP while bandage caps at 85 HP', () => {
  assert.equal(computeHealOutcome(25, 100, 'medkit'), 100);
  assert.equal(computeHealOutcome(15, 100, 'medkit'), 90);
  assert.equal(computeHealOutcome(70, 100, 'bandage'), 85);
  assert.equal(computeHealOutcome(90, 100, 'bandage'), 90);
});

test('enemy tactical speeds remain grounded and yaw interpolation turns smoothly', () => {
  assert.ok(ENEMY_SPEED_CONFIG.patrolMps <= 1.5);
  assert.ok(ENEMY_SPEED_CONFIG.tacticalAdvanceMps <= 2.5);
  assert.ok(ENEMY_SPEED_CONFIG.breacherRushMps <= 3.0);

  const nextYaw = stepAngleRad(0, Math.PI, ENEMY_SPEED_CONFIG.maxTurnRateRadPerSec, 0.1);
  assert.ok(Math.abs(nextYaw) < 0.6);
});

test('enemy loot drops always include healing supplies and ammo', () => {
  const dropOfficer = createEnemyLootDrop('officer', 0.2);
  assert.ok(dropOfficer.medkits >= 1 && dropOfficer.grenades >= 1 && dropOfficer.ammo > 0);
  const dropInfantry = createEnemyLootDrop('infantry', 0.8);
  assert.ok(dropInfantry.medkits + dropInfantry.bandages >= 1);
});

test('every 60s pubg airdrop contains aptechka medkits and ammo', () => {
  assert.equal(AIRDROP_INTERVAL_SEC, 60);
  const drop = createAirdropSupplyContents();
  assert.equal(drop.isAirdrop, true);
  assert.ok(drop.medkits >= 2 && drop.ammo >= 60 && drop.grenades >= 1);
});

test('third-person camera places camera behind and right of shoulder', () => {
  const cam = computeTppCameraPosition(0, 0, 0, 1.66, 0, 0, 2.6, 0.54);
  assert.ok(cam.x > 0.4);
  assert.ok(cam.z > 2.4);
  assert.ok(cam.y > 1.5);
});

test('knocked teammate bleeds out to dead after timer expires', () => {
  const mid = stepKnockoutBleedout('knocked', KNOCKED_BLEEDOUT_SEC, 5);
  assert.equal(mid.state, 'knocked');
  assert.equal(mid.bleedoutTimerSec, KNOCKED_BLEEDOUT_SEC - 5);

  const end = stepKnockoutBleedout('knocked', 1.2, 2.0);
  assert.equal(end.state, 'dead');
  assert.equal(end.bleedoutTimerSec, 0);
});

test('arena 4v4 outcome resolves target kills and timer expiry cleanly', () => {
  assert.equal(computeArenaMatchOutcome(10, 8, ARENA_TARGET_KILLS, 90), 'ongoing');
  assert.equal(computeArenaMatchOutcome(ARENA_TARGET_KILLS, 14, ARENA_TARGET_KILLS, 60), 'victory');
  assert.equal(computeArenaMatchOutcome(12, ARENA_TARGET_KILLS, ARENA_TARGET_KILLS, 60), 'defeat');
  assert.equal(computeArenaMatchOutcome(15, 11, ARENA_TARGET_KILLS, 0), 'victory');
  assert.equal(computeArenaMatchOutcome(9, 14, ARENA_TARGET_KILLS, 0), 'defeat');
  assert.ok(computeBagWeightKg(2, 3, 2, 150) > 5);
});

