import type {
  SurfaceMaterial,
  TacticalStance,
  WeaponId,
  WeaponRuntimeState,
  WeaponSpec,
} from './types';

export const GRAVITY_MPS2 = 9.81;
export const MOUNT_RECOIL_MULTIPLIER = 0.35; // 65% recoil reduction when weapon-mounted

export const WEAPON_SPECS: Record<WeaponId, WeaponSpec> = {
  mk18_suppressed: {
    id: 'mk18_suppressed',
    name: 'MK18 MOD 1 // SUPPRESSED',
    designation: '5.56mm CQB Carbine',
    caliber: '5.56x45mm',
    suppressed: true,
    magCapacity: 30,
    reserveMax: 150,
    rpm: 750,
    muzzleVelocityMps: 790,
    baseDamage: 34,
    headshotMultiplier: 2.35,
    penetrationPowerMm: 14,
    adsTimeSec: 0.21,
    tacSprintToFireSec: 0.34,
    recoilPitchDeg: 1.45,
    recoilYawDeg: 0.55,
    hipSpreadDeg: 3.1,
    adsSpreadDeg: 0.14,
    tacticalReloadSec: 1.45,
    emptyReloadSec: 2.05,
  },
  p226_suppressed: {
    id: 'p226_suppressed',
    name: 'P226 TACOPS // SUPPRESSED',
    designation: '9mm Tactical Sidearm',
    caliber: '9x19mm',
    suppressed: true,
    magCapacity: 15,
    reserveMax: 60,
    rpm: 380,
    muzzleVelocityMps: 340,
    baseDamage: 28,
    headshotMultiplier: 2.1,
    penetrationPowerMm: 5,
    adsTimeSec: 0.14,
    tacSprintToFireSec: 0.19,
    recoilPitchDeg: 1.9,
    recoilYawDeg: 0.45,
    hipSpreadDeg: 2.2,
    adsSpreadDeg: 0.25,
    tacticalReloadSec: 1.15,
    emptyReloadSec: 1.6,
  },
};

export const MATERIAL_RESISTANCE_MM: Record<SurfaceMaterial, number> = {
  flesh: 2.5,
  wood: 6.0,
  sheet_metal: 9.5,
  concrete: 22.0,
  armor_plate: 16.0,
};

export interface MovementConfig {
  walkSpeedMps: number;
  tacSprintSpeedMps: number;
  crouchSpeedMps: number;
  proneSpeedMps: number;
  slideInitialSpeedMps: number;
  slideMinSpeedMps: number;
  slideFriction: number;
  adsMoveMultiplier: number;
  mountedMoveMultiplier: number;
}

export const DEFAULT_MOVEMENT_CONFIG: MovementConfig = {
  walkSpeedMps: 4.3,
  tacSprintSpeedMps: 6.9,
  crouchSpeedMps: 2.5,
  proneSpeedMps: 1.35,
  slideInitialSpeedMps: 8.4,
  slideMinSpeedMps: 2.4,
  slideFriction: 3.6,
  adsMoveMultiplier: 0.62,
  mountedMoveMultiplier: 0.0,
};

export function getEyeHeightForStance(stance: TacticalStance): number {
  switch (stance) {
    case 'standing':
    case 'tactical_sprint':
      return 1.66;
    case 'crouched':
      return 1.08;
    case 'sliding':
      return 0.88;
    case 'prone':
      return 0.42;
  }
}

export function getTargetSpeedMps(
  stance: TacticalStance,
  isAds: boolean,
  isMounted: boolean,
  cfg: MovementConfig = DEFAULT_MOVEMENT_CONFIG,
): number {
  if (isMounted) return 0;
  let base: number;
  switch (stance) {
    case 'tactical_sprint':
      base = cfg.tacSprintSpeedMps;
      break;
    case 'crouched':
      base = cfg.crouchSpeedMps;
      break;
    case 'prone':
      base = cfg.proneSpeedMps;
      break;
    case 'sliding':
      base = cfg.slideInitialSpeedMps;
      break;
    case 'standing':
    default:
      base = cfg.walkSpeedMps;
      break;
  }
  return isAds && stance !== 'tactical_sprint' ? base * cfg.adsMoveMultiplier : base;
}

export function stepSlideVelocity(
  currentSpeedMps: number,
  dt: number,
  cfg: MovementConfig = DEFAULT_MOVEMENT_CONFIG,
): { nextSpeedMps: number; finished: boolean } {
  const decayed = currentSpeedMps * Math.exp(-cfg.slideFriction * Math.max(0, dt));
  if (decayed <= cfg.slideMinSpeedMps) {
    return { nextSpeedMps: cfg.crouchSpeedMps, finished: true };
  }
  return { nextSpeedMps: decayed, finished: false };
}

export function computeEffectiveAdsTimeSec(
  spec: WeaponSpec,
  fromTacSprint: boolean,
  isMounted: boolean,
): number {
  let time = spec.adsTimeSec;
  if (fromTacSprint) {
    time += spec.tacSprintToFireSec * 0.55;
  }
  if (isMounted) {
    time *= 0.72;
  }
  return time;
}

export interface RecoilImpulse {
  pitchDeg: number;
  yawDeg: number;
  kickZ: number;
}

/**
 * Computes single-shot procedural recoil impulse with:
 * - Weapon mounting 65% reduction (multiplier = 0.35)
 * - Stance stability bonus (Crouch: -20%, Prone: -40%)
 * - Deterministic horizontal sway alternation for predictable recoil control
 */
export function computeShotRecoil(
  spec: WeaponSpec,
  burstIndex: number,
  stance: TacticalStance,
  isMounted: boolean,
): RecoilImpulse {
  const mountFactor = isMounted ? MOUNT_RECOIL_MULTIPLIER : 1.0;
  const stanceFactor =
    stance === 'prone' ? 0.6 : stance === 'crouched' || stance === 'sliding' ? 0.8 : 1.0;

  // Progressive climb dampens slightly after shot 6, yaw alternates with slight drift
  const climbScale = 1 + Math.min(burstIndex, 6) * 0.045;
  const yawWave = Math.sin((burstIndex + 1) * 1.45);

  return {
    pitchDeg: spec.recoilPitchDeg * climbScale * stanceFactor * mountFactor,
    yawDeg: spec.recoilYawDeg * yawWave * stanceFactor * mountFactor,
    kickZ: 0.032 * stanceFactor * mountFactor,
  };
}

export function stepRecoilSpring(
  currentPitchDeg: number,
  currentYawDeg: number,
  dt: number,
  recoveryRate = 11.5,
): { pitchDeg: number; yawDeg: number } {
  const factor = Math.exp(-recoveryRate * Math.max(0, dt));
  return {
    pitchDeg: currentPitchDeg * factor,
    yawDeg: currentYawDeg * factor,
  };
}

/**
 * Ballistic projectile drop & aerodynamic drag at distance `distanceM`:
 *  t = distanceM / effectiveVelocity
 *  dropM = 0.5 * g * t^2
 */
export function computeBallisticDropAndDamage(
  spec: WeaponSpec,
  distanceM: number,
  isHeadshot: boolean,
): { dropM: number; flightTimeSec: number; impactDamage: number } {
  const clampedDist = Math.max(0, distanceM);
  // Linearized velocity bleed due to air drag (~0.25% per meter for supersonic rounds)
  const dragDecay = Math.exp(-0.0022 * clampedDist);
  const avgVelocity = Math.max(120, spec.muzzleVelocityMps * (0.5 + 0.5 * dragDecay));
  const flightTimeSec = clampedDist / avgVelocity;
  const dropM = 0.5 * GRAVITY_MPS2 * flightTimeSec * flightTimeSec;

  // Damage falloff beyond 35m for 5.56mm, 20m for 9mm
  const falloffStart = spec.caliber === '5.56x45mm' ? 35 : 20;
  const falloffFactor =
    clampedDist <= falloffStart
      ? 1.0
      : Math.max(0.55, 1.0 - (clampedDist - falloffStart) * 0.0075);

  const hitMultiplier = isHeadshot ? spec.headshotMultiplier : 1.0;
  const impactDamage = Math.round(spec.baseDamage * falloffFactor * hitMultiplier);

  return { dropM, flightTimeSec, impactDamage };
}

/**
 * Evaluates whether a projectile penetrates a barrier of given material & thickness.
 * Returns remaining damage multiplier (0 if stopped).
 */
export function computeMaterialPenetration(
  spec: WeaponSpec,
  material: SurfaceMaterial,
  thicknessFactor = 1.0,
): { penetrated: boolean; damageMultiplier: number } {
  const resistance = MATERIAL_RESISTANCE_MM[material] * Math.max(0.2, thicknessFactor);
  if (spec.penetrationPowerMm <= resistance) {
    return { penetrated: false, damageMultiplier: 0 };
  }
  const margin = (spec.penetrationPowerMm - resistance) / spec.penetrationPowerMm;
  return {
    penetrated: true,
    damageMultiplier: Math.max(0.25, Math.min(0.88, margin + 0.25)),
  };
}

export function createInitialWeaponState(id: WeaponId): WeaponRuntimeState {
  const spec = WEAPON_SPECS[id];
  return {
    id,
    magAmmo: spec.magCapacity,
    chambered: true, // +1 round in chamber on mission start
    reserveAmmo: spec.reserveMax,
    isReloading: false,
    reloadTimer: 0,
    reloadDuration: spec.tacticalReloadSec,
    fireCooldown: 0,
    burstIndex: 0,
  };
}

export function getTotalLoadedAmmo(state: WeaponRuntimeState): number {
  return state.magAmmo + (state.chambered ? 1 : 0);
}

/**
 * Consumes 1 round on fire:
 * Chambered round fires first; bolt strips next round from mag if magAmmo > 0.
 */
export function consumeRoundOnFire(state: WeaponRuntimeState): {
  fired: boolean;
  nextState: WeaponRuntimeState;
} {
  if (state.isReloading || state.fireCooldown > 0) {
    return { fired: false, nextState: state };
  }
  if (!state.chambered && state.magAmmo <= 0) {
    return { fired: false, nextState: state };
  }

  const spec = WEAPON_SPECS[state.id];
  let magAmmo = state.magAmmo;
  let chambered = state.chambered;

  if (chambered) {
    chambered = false;
    if (magAmmo > 0) {
      magAmmo -= 1;
      chambered = true;
    }
  } else if (magAmmo > 0) {
    magAmmo -= 1;
    chambered = magAmmo > 0;
  }

  return {
    fired: true,
    nextState: {
      ...state,
      magAmmo,
      chambered,
      fireCooldown: 60 / spec.rpm,
      burstIndex: state.burstIndex + 1,
    },
  };
}

/**
 * Initiates Tactical Reload (+1 in chamber preserved -> shorter time)
 * or Empty Reload (bolt/slide rack required -> longer time).
 */
export function startReload(state: WeaponRuntimeState): WeaponRuntimeState {
  const spec = WEAPON_SPECS[state.id];
  if (state.isReloading || state.reserveAmmo <= 0) return state;
  if (state.magAmmo >= spec.magCapacity && state.chambered) return state;

  const isTactical = state.chambered;
  const duration = isTactical ? spec.tacticalReloadSec : spec.emptyReloadSec;

  return {
    ...state,
    isReloading: true,
    reloadTimer: duration,
    reloadDuration: duration,
    burstIndex: 0,
  };
}

export function completeReload(state: WeaponRuntimeState): WeaponRuntimeState {
  const spec = WEAPON_SPECS[state.id];
  const neededForMag = spec.magCapacity - state.magAmmo;
  const loadedIntoMag = Math.min(neededForMag, state.reserveAmmo);
  let magAmmo = state.magAmmo + loadedIntoMag;
  const reserveAmmo = state.reserveAmmo - loadedIntoMag;
  let chambered = state.chambered;

  if (!chambered && magAmmo > 0) {
    magAmmo -= 1;
    chambered = true;
  }

  return {
    ...state,
    magAmmo,
    chambered,
    reserveAmmo,
    isReloading: false,
    reloadTimer: 0,
  };
}

/**
 * Frag Grenade Radial Blast Falloff (lethal core within 2.5m, linear falloff to radiusM)
 */
export function computeExplosionDamage(
  distanceM: number,
  maxDamage = 165,
  blastRadiusM = 8.0,
): number {
  const d = Math.max(0, distanceM);
  if (d >= blastRadiusM) return 0;
  if (d <= 2.2) return maxDamage;
  const t = 1 - (d - 2.2) / (blastRadiusM - 2.2);
  return Math.round(maxDamage * Math.pow(t, 1.35));
}

export const HEAL_CONFIGS = {
  medkit: {
    label: 'APTECHKA (FIRST AID)',
    castSec: 2.1,
    healAmount: 75,
    capHp: 100,
  },
  bandage: {
    label: 'TACTICAL BANDAGE',
    castSec: 1.0,
    healAmount: 25,
    capHp: 85,
  },
} as const;

export function computeHealOutcome(
  currentHp: number,
  maxHp: number,
  kind: 'medkit' | 'bandage',
): number {
  const cfg = HEAL_CONFIGS[kind];
  if (currentHp <= 0 || currentHp >= maxHp) return currentHp;
  const targetCap = Math.min(maxHp, cfg.capHp);
  if (currentHp >= targetCap) {
    // Allow medkit to top off to maxHp if capHp == maxHp
    return currentHp;
  }
  return Math.min(targetCap, currentHp + cfg.healAmount);
}

/**
 * Realistic human soldier tactical movement speeds (meters/second)
 * Prevents bug-like sprinting/jittering.
 */
export const ENEMY_SPEED_CONFIG = {
  patrolMps: 1.15,
  tacticalAdvanceMps: 2.15,
  tacticalFlankMps: 1.65,
  breacherRushMps: 2.75,
  maxTurnRateRadPerSec: 5.2,
} as const;

export function stepAngleRad(
  currentRad: number,
  targetRad: number,
  maxTurnRateRadPerSec: number,
  dt: number,
): number {
  let diff = ((targetRad - currentRad + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
  const maxStep = Math.max(0, maxTurnRateRadPerSec * dt);
  if (Math.abs(diff) <= maxStep) return targetRad;
  return currentRad + Math.sign(diff) * maxStep;
}

export function createEnemyLootDrop(
  archetype: 'infantry' | 'breacher' | 'sniper' | 'officer',
  roll: number,
): { medkits: number; bandages: number; grenades: number; ammo: number } {
  const r = Math.abs(roll) % 1;
  if (archetype === 'officer') {
    return { medkits: 1, bandages: 1, grenades: 1, ammo: 30 };
  }
  if (archetype === 'breacher') {
    return { medkits: r > 0.35 ? 1 : 0, bandages: 1, grenades: 1, ammo: 25 };
  }
  if (archetype === 'sniper') {
    return { medkits: 1, bandages: 0, grenades: r > 0.45 ? 1 : 0, ammo: 20 };
  }
  return {
    medkits: r > 0.4 ? 1 : 0,
    bandages: r <= 0.4 ? 2 : 1,
    grenades: r > 0.5 ? 1 : 0,
    ammo: 25,
  };
}

export const AIRDROP_INTERVAL_SEC = 60;
export const KNOCKED_BLEEDOUT_SEC = 26;
export const REVIVE_CHANNEL_SEC = 2.4;
export const ARENA_TARGET_KILLS = 20;
export const ARENA_DURATION_SEC = 180;

export function createAirdropSupplyContents(): {
  medkits: number;
  bandages: number;
  grenades: number;
  ammo: number;
  isAirdrop: boolean;
} {
  return {
    medkits: 2,
    bandages: 3,
    grenades: 2,
    ammo: 90,
    isAirdrop: true,
  };
}

export function computeTppCameraPosition(
  playerX: number,
  playerY: number,
  playerZ: number,
  eyeHeight: number,
  yawRad: number,
  pitchRad: number,
  distanceM: number,
  shoulderOffsetM = 0.54,
): { x: number; y: number; z: number } {
  // Forward vector when camera looks along (yawRad, pitchRad)
  const cosPitch = Math.cos(pitchRad);
  const fwdX = -Math.sin(yawRad) * cosPitch;
  const fwdY = Math.sin(pitchRad);
  const fwdZ = -Math.cos(yawRad) * cosPitch;

  // Right vector in XZ plane
  const rightX = Math.cos(yawRad);
  const rightZ = -Math.sin(yawRad);

  const pivotY = playerY + Math.max(0.75, eyeHeight * 0.92);
  return {
    x: playerX + rightX * shoulderOffsetM - fwdX * distanceM,
    y: Math.max(0.35, pivotY - fwdY * distanceM + 0.14),
    z: playerZ + rightZ * shoulderOffsetM - fwdZ * distanceM,
  };
}

export function stepKnockoutBleedout(
  state: 'alive' | 'knocked' | 'dead',
  bleedoutTimerSec: number,
  dt: number,
): { state: 'alive' | 'knocked' | 'dead'; bleedoutTimerSec: number } {
  if (state !== 'knocked') return { state, bleedoutTimerSec };
  const next = bleedoutTimerSec - Math.max(0, dt);
  if (next <= 0) {
    return { state: 'dead', bleedoutTimerSec: 0 };
  }
  return { state: 'knocked', bleedoutTimerSec: next };
}

export function computeArenaMatchOutcome(
  blueKills: number,
  redKills: number,
  targetKills: number,
  timeRemainingSec: number,
): 'ongoing' | 'victory' | 'defeat' {
  if (blueKills >= targetKills) return 'victory';
  if (redKills >= targetKills) return 'defeat';
  if (timeRemainingSec <= 0) {
    return blueKills >= redKills ? 'victory' : 'defeat';
  }
  return 'ongoing';
}

export function computeBagWeightKg(
  medkits: number,
  bandages: number,
  grenades: number,
  totalReserveAmmo: number,
): number {
  const kg = medkits * 1.4 + bandages * 0.35 + grenades * 0.45 + totalReserveAmmo * 0.015;
  return Math.round(kg * 10) / 10;
}


