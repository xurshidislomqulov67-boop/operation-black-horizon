export interface ArchitectureSection {
  id: string;
  title: string;
  subtitle: string;
  formulas?: { name: string; equation: string; explanation: string }[];
  codeLanguage: 'cpp' | 'blueprint' | 'math';
  code: string;
}

export const MODULE_1_UE5_ARCHITECTURE: ArchitectureSection[] = [
  {
    id: 'movement_cpp',
    title: '1. Tactical Movement Component (UE5 C++)',
    subtitle: 'ATacticalCharacter & UTacticalMovementComponent — Walk, Tac-Sprint, Slide, Mantle & Mount',
    formulas: [
      {
        name: 'Exponential Slide Decay',
        equation: 'v(t + Δt) = v(t) · e^(-μ_slide · Δt),   until v ≤ v_crouch (2.4 m/s)',
        explanation:
          'Frame-rate independent exponential friction preserves snappy entry burst (8.4 m/s) and seamless transition into crouched stance.',
      },
      {
        name: 'Tactical Sprint ADS Penalty',
        equation: 'T_ADS_eff = T_ADS_base + 0.55 · T_SprintToFire',
        explanation:
          'Weapon-raised Tactical Sprint increases speed to 6.9 m/s at the cost of a procedural cant-to-sight ADS delay.',
      },
      {
        name: 'Weapon Mount Recoil Reduction',
        equation: 'R_mounted = 0.35 · R_unmounted   (65% Recoil Reduction)',
        explanation:
          'Bracing against cover geometry (sphere-trace forward + lateral 0.85m) locks base translation and scales pitch/yaw kick by 0.35.',
      },
    ],
    codeLanguage: 'cpp',
    code: `// TacticalCharacter.h — Unreal Engine 5.4 C++ Framework
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "TacticalCharacter.generated.h"

UENUM(BlueprintType)
enum class ETacticalStance : uint8
{
    Standing       UMETA(DisplayName = "Standing"),
    Crouched       UMETA(DisplayName = "Crouched"),
    Prone          UMETA(DisplayName = "Prone"),
    Sliding        UMETA(DisplayName = "Tactical Slide"),
    TacticalSprint UMETA(DisplayName = "Tactical Sprint")
};

UCLASS()
class BLACKHORIZON_API ATacticalCharacter : public ACharacter
{
    GENERATED_BODY()

public:
    ATacticalCharacter();

    virtual void Tick(float DeltaTime) override;
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

    UFUNCTION(BlueprintCallable, Category = "Tactical|Movement")
    void SetTacticalStance(ETacticalStance NewStance);

    UFUNCTION(BlueprintCallable, Category = "Tactical|Movement")
    bool TryWeaponMount();

    UFUNCTION(BlueprintCallable, Category = "Tactical|Movement")
    bool TryContextualMantle();

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Tactical|Config")
    float WalkSpeed = 430.f;          // 4.3 m/s (UE units = cm)

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Tactical|Config")
    float TacSprintSpeed = 690.f;     // 6.9 m/s

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Tactical|Config")
    float CrouchSpeed = 250.f;        // 2.5 m/s

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Tactical|Config")
    float ProneSpeed = 135.f;         // 1.35 m/s

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Tactical|Config")
    float SlideInitialSpeed = 840.f;  // 8.4 m/s

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Tactical|Config")
    float SlideFrictionCoeff = 3.6f;

    UPROPERTY(BlueprintReadOnly, Replicated, Category = "Tactical|State")
    ETacticalStance CurrentStance = ETacticalStance::Standing;

    UPROPERTY(BlueprintReadOnly, Replicated, Category = "Tactical|State")
    bool bIsWeaponMounted = false;

    UPROPERTY(BlueprintReadOnly, Category = "Tactical|State")
    bool bNightVisionActive = false;

protected:
    void UpdateCameraEyeHeight(float DeltaTime);
    void UpdateSlidePhysics(float DeltaTime);

private:
    float CurrentSlideSpeed = 0.f;
    FVector SlideDirection = FVector::ZeroVector;
    FVector MountAnchorNormal = FVector::ZeroVector;
};

// TacticalCharacter.cpp
void ATacticalCharacter::UpdateSlidePhysics(float DeltaTime)
{
    if (CurrentStance != ETacticalStance::Sliding) return;

    CurrentSlideSpeed *= FMath::Exp(-SlideFrictionCoeff * DeltaTime);
    AddMovementInput(SlideDirection, CurrentSlideSpeed / WalkSpeed);

    if (CurrentSlideSpeed <= 240.f)
    {
        SetTacticalStance(ETacticalStance::Crouched);
    }
}

bool ATacticalCharacter::TryWeaponMount()
{
    if (bIsWeaponMounted)
    {
        bIsWeaponMounted = false;
        return false;
    }

    FHitResult Hit;
    const FVector Start = GetActorLocation() + FVector(0.f, 0.f, 45.f);
    const FVector End = Start + GetActorForwardVector() * 95.f;
    FCollisionQueryParams Params(SCENE_QUERY_STAT(WeaponMount), false, this);

    if (GetWorld()->SweepSingleByChannel(Hit, Start, End, FQuat::Identity,
        ECC_Visibility, FCollisionShape::MakeSphere(18.f), Params))
    {
        bIsWeaponMounted = true;
        MountAnchorNormal = Hit.ImpactNormal;
        return true;
    }
    return false;
}`,
  },
  {
    id: 'ballistics_cpp',
    title: '2. Ballistics, Penetration & Recoil Spring (UE5 C++)',
    subtitle: 'UWeaponBallisticsComponent — Drop, Drag, Material Penetration & +1 Chamber Reload',
    formulas: [
      {
        name: 'Ballistic Drop with Air Drag',
        equation: 'v_avg = v_0 · (0.5 + 0.5 · e^(-0.0022·d)),   Δy(d) = ½ · g · (d / v_avg)²',
        explanation:
          'Models real-world subsonic/supersonic velocity decay over distance d and gravitational drop.',
      },
      {
        name: 'Caliber Barrier Penetration',
        equation: 'D_exit = D_in · clamp((P_caliber - R_mat · τ) / P_caliber + 0.25, 0.25, 0.88)',
        explanation:
          '5.56x45mm (P = 14mm) punches through Wood (6mm) and Sheet Metal (9.5mm) while Concrete (22mm) stops it.',
      },
      {
        name: 'Second-Order Recoil Spring Recovery',
        equation: 'θ_recoil(t + Δt) = θ_recoil(t) · e^(-k_rec · Δt)',
        explanation:
          'Procedural viewmodel & camera pitch/yaw climb smoothly returns toward sight zero between bursts.',
      },
    ],
    codeLanguage: 'cpp',
    code: `// WeaponBallisticsComponent.h — Unreal Engine 5.4 C++ Framework
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "WeaponBallisticsComponent.generated.h"

USTRUCT(BlueprintType)
struct FBallisticCaliberData
{
    GENERATED_BODY()

    UPROPERTY(EditDefaultsOnly) float MuzzleVelocityCmPerSec = 79000.f; // 790 m/s
    UPROPERTY(EditDefaultsOnly) float BaseDamage = 34.f;
    UPROPERTY(EditDefaultsOnly) float HeadshotMultiplier = 2.35f;
    UPROPERTY(EditDefaultsOnly) float PenetrationPowerMm = 14.f;
    UPROPERTY(EditDefaultsOnly) float RecoilPitchDeg = 1.45f;
    UPROPERTY(EditDefaultsOnly) float RecoilYawDeg = 0.55f;
};

UCLASS(ClassGroup=(Combat), meta=(BlueprintSpawnableComponent))
class BLACKHORIZON_API UWeaponBallisticsComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Ballistics")
    void FireRound(const FVector& MuzzleLoc, const FVector& AimDir, bool bIsMounted, ETacticalStance Stance);

    UFUNCTION(BlueprintCallable, Category = "Ballistics")
    void StartDynamicReload();

    UPROPERTY(EditDefaultsOnly, Category = "Ballistics")
    FBallisticCaliberData Caliber;

    UPROPERTY(BlueprintReadOnly, Category = "Ammo")
    int32 MagAmmo = 30;

    UPROPERTY(BlueprintReadOnly, Category = "Ammo")
    bool bChamberedRound = true; // +1 in chamber

    UPROPERTY(BlueprintReadOnly, Category = "Ammo")
    int32 ReserveAmmo = 150;

private:
    static constexpr float MountRecoilScale = 0.35f; // 65% reduction
    int32 BurstShotIndex = 0;
};

// WeaponBallisticsComponent.cpp
void UWeaponBallisticsComponent::StartDynamicReload()
{
    if (ReserveAmmo <= 0) return;

    // Tactical Reload preserves chambered +1 (1.45s) vs Empty Bolt Rack (2.05s)
    const float ReloadTime = bChamberedRound ? 1.45f : 2.05f;
    // Trigger AnimMontage(bChamberedRound ? TacticalReloadMontage : EmptyReloadMontage)
    BurstShotIndex = 0;
}`,
  },
  {
    id: 'blueprint_graph',
    title: '3. Blueprint & AnimBP Execution Graph',
    subtitle: 'Enhanced Input Action Bindings, Door Breaching State Machine & Procedural IK',
    codeLanguage: 'blueprint',
    code: `[Enhanced Input Mapping Context: IMC_TacticalFPS]
  ├─ IA_Move (Vector2D) ──────────► AddMovementInput (Scale by Stance Speed)
  ├─ IA_TacSprint (Hold/Toggle) ──► If Moving Forward: SetStance(TacticalSprint) + Raise Weapon IK
  ├─ IA_Crouch_Slide (Tap/Hold) ──► Branch(Stance == TacticalSprint)
  │                                  ├─ TRUE  ─► Enter TacticalSlide (8.4 m/s -> Exp Decay -> Crouch)
  │                                  └─ FALSE ─► Toggle Crouch / Prone (Hold 0.35s)
  ├─ IA_MountWeapon [Q] ──────────► SphereTrace(95cm) ─► Lock Anchor & Set RecoilScale = 0.35
  ├─ IA_NVG_Toggle [N] ───────────► FlipFlop ─► Enable PostProcess_NVG_Phosphor + Weapon IR Laser
  └─ IA_BreachDoor [F/G/B] ───────► DoorInterface::Interact(Peek | SilentOpen | SprintBash | C4Charge)

[Animation Blueprint: ABP_Operator_FirstPerson]
  ├─ State Machine: Locomotion (Idle / Walk / TacSprint High-Ready / Crouch / Prone)
  ├─ Layered Blend Per Bone (Spine_02): Weapon Equip / Tactical Reload (+1) / Empty Reload
  ├─ Two-Bone IK (Left Hand): Snap to Underbarrel Foregrip Socket
  └─ Procedural Recoil Spring Node: Apply (RecoilPitch, RecoilYaw, KickbackZ) to WeaponRootBone`,
  },
];
