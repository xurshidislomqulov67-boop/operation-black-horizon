import type {
  ClientToServerMsg,
  MultiplayerRoomState,
  RemotePlayerPose,
  RemoteShotFx,
  ServerToClientMsg,
  TargetKillsOption,
} from './multiplayerProtocol';

export interface DuelClientHandlers {
  onConnectionChange?: (connected: boolean) => void;
  onRoomState?: (room: MultiplayerRoomState) => void;
  onMatchStarted?: (room: MultiplayerRoomState) => void;
  onRemotePose?: (pose: RemotePlayerPose) => void;
  onRemoteShotFx?: (fx: RemoteShotFx) => void;
  onDamageEvent?: (ev: Extract<ServerToClientMsg, { type: 'damage_event' }>) => void;
  onKillEvent?: (ev: Extract<ServerToClientMsg, { type: 'kill_event' }>) => void;
  onMatchOver?: (room: MultiplayerRoomState) => void;
  onError?: (message: string) => void;
}

export class DuelMultiplayerClient {
  private ws: WebSocket | null = null;
  private handlers: DuelClientHandlers;
  private pendingQueue: ClientToServerMsg[] = [];
  private lastPoseSentAtMs = 0;

  constructor(handlers: DuelClientHandlers = {}) {
    this.handlers = handlers;
  }

  public setHandlers(handlers: DuelClientHandlers): void {
    this.handlers = handlers;
  }

  public isConnected(): boolean {
    return Boolean(this.ws && this.ws.readyState === WebSocket.OPEN);
  }

  public connect(): void {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${proto}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    this.ws = ws;

    ws.addEventListener('open', () => {
      this.handlers.onConnectionChange?.(true);
      const queued = this.pendingQueue.splice(0, this.pendingQueue.length);
      for (const msg of queued) {
        this.sendRaw(msg);
      }
    });

    ws.addEventListener('message', (event) => {
      let msg: ServerToClientMsg;
      try {
        msg = JSON.parse(String(event.data)) as ServerToClientMsg;
      } catch {
        return;
      }
      switch (msg.type) {
        case 'room_state':
          this.handlers.onRoomState?.(msg.room);
          break;
        case 'match_started':
          this.handlers.onMatchStarted?.(msg.room);
          break;
        case 'remote_pose':
          this.handlers.onRemotePose?.(msg.pose);
          break;
        case 'remote_shot_fx':
          this.handlers.onRemoteShotFx?.(msg.fx);
          break;
        case 'damage_event':
          this.handlers.onDamageEvent?.(msg);
          break;
        case 'kill_event':
          this.handlers.onKillEvent?.(msg);
          break;
        case 'match_over':
          this.handlers.onMatchOver?.(msg.room);
          break;
        case 'error':
          this.handlers.onError?.(msg.message);
          break;
      }
    });

    ws.addEventListener('close', () => {
      this.handlers.onConnectionChange?.(false);
    });

    ws.addEventListener('error', () => {
      this.handlers.onError?.('Server bilan WebSocket aloqasi uzildi.');
    });
  }

  public disconnect(): void {
    this.pendingQueue = [];
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  private sendRaw(msg: ClientToServerMsg): void {
    if (!this.ws || this.ws.readyState === WebSocket.CLOSED || this.ws.readyState === WebSocket.CLOSING) {
      this.pendingQueue.push(msg);
      this.connect();
      return;
    }
    if (this.ws.readyState === WebSocket.CONNECTING) {
      this.pendingQueue.push(msg);
      return;
    }
    this.ws.send(JSON.stringify(msg));
  }

  public createRoom(playerName: string, targetKills: TargetKillsOption, durationSec: number): void {
    this.sendRaw({ type: 'create_room', playerName, targetKills, durationSec });
  }

  public joinRoom(code: string, playerName: string): void {
    this.sendRaw({ type: 'join_room', code, playerName });
  }

  public updateRoomConfig(targetKills: TargetKillsOption, durationSec: number): void {
    this.sendRaw({ type: 'update_room_config', targetKills, durationSec });
  }

  public startMatch(): void {
    this.sendRaw({ type: 'start_match' });
  }

  public rematch(): void {
    this.sendRaw({ type: 'rematch' });
  }

  public leaveRoom(): void {
    this.sendRaw({ type: 'leave_room' });
  }

  public sendPoseThrottled(pose: Extract<ClientToServerMsg, { type: 'player_state' }>['pose']): void {
    const now = performance.now();
    if (now - this.lastPoseSentAtMs < 32) return; // ~30Hz max
    this.lastPoseSentAtMs = now;
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'player_state', pose }));
    }
  }

  public sendShotFx(
    origin: [number, number, number],
    hitPoint: [number, number, number],
    weaponId: 'mk18_suppressed' | 'p226_suppressed',
  ): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'player_shot_fx',
          origin,
          hitPoint,
          weaponId,
        } satisfies ClientToServerMsg),
      );
    }
  }

  public sendHit(damage: number, headshot: boolean): void {
    this.sendRaw({ type: 'player_hit', damage, headshot });
  }

  public sendHeal(amount: number, capHp: number): void {
    this.sendRaw({ type: 'player_heal', amount, capHp });
  }
}
