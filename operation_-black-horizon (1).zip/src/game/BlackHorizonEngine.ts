import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { TacticalAudioEngine } from './audioEngine';
import {
  MISSION_1_BREACH_DOORS,
  MISSION_1_OBJECTIVES,
  MISSION_1_SPAWNS,
  MISSION_1_TRIGGERS,
} from './mission1Script';
import {
  buildAirdropCrateMesh,
  buildBarracksDetails,
  buildEnemyMesh,
  buildFriendlySoldierMesh,
  buildGrenadeMesh,
  buildLatticeWatchtower,
  buildLobbyPlaneWreck,
  buildLootCrateMesh,
  buildMilitaryTent,
  buildMrapVehicle,
  buildPlayerWeaponGroup,
  buildSatComTower,
  createConcreteTexture,
  createRadialContactShadowTexture,
  createWetAsphaltTextures,
  createWoodCrateTexture,
} from './proceduralAssets';
import {
  AIRDROP_INTERVAL_SEC,
  ARENA_DURATION_SEC,
  ARENA_TARGET_KILLS,
  ENEMY_SPEED_CONFIG,
  HEAL_CONFIGS,
  KNOCKED_BLEEDOUT_SEC,
  REVIVE_CHANNEL_SEC,
  WEAPON_SPECS,
  completeReload,
  computeArenaMatchOutcome,
  computeBagWeightKg,
  computeBallisticDropAndDamage,
  computeEffectiveAdsTimeSec,
  computeExplosionDamage,
  computeHealOutcome,
  computeMaterialPenetration,
  computeShotRecoil,
  computeTppCameraPosition,
  consumeRoundOnFire,
  createAirdropSupplyContents,
  createEnemyLootDrop,
  createInitialWeaponState,
  getEyeHeightForStance,
  getTargetSpeedMps,
  startReload,
  stepAngleRad,
  stepKnockoutBleedout,
  stepRecoilSpring,
  stepSlideVelocity,
} from './tacticalPhysics';
import type { DuelMultiplayerClient } from './multiplayerClient';
import type {
  MultiplayerRoomState,
  RemotePlayerPose,
  RemoteShotFx,
  TargetKillsOption,
} from './multiplayerProtocol';
import {
  DEFAULT_GAME_SETTINGS,
  type AirdropStatusHud,
  type ArenaScoreHud,
  type CameraPerspective,
  type DoorInteractionMode,
  type DuelScoreHud,
  type EnemyArchetype,
  type GameMode,
  type GameSettings,
  type GameState,
  type HudSnapshot,
  type IncomingGrenadeAlert,
  type LootCrateContents,
  type MinimapBlip,
  type NearbyLootHud,
  type RadioCommsLine,
  type RevivePromptHud,
  type SurfaceMaterial,
  type TacticalStance,
  type TeammateStatus,
  type WeaponId,
  type WeaponRuntimeState,
} from './types';

interface AabbCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  maxY: number;
  material: SurfaceMaterial;
  coverMountable?: boolean;
  mesh?: THREE.Object3D;
}

interface DoorActor {
  id: string;
  label: string;
  pivot: THREE.Group;
  doorMesh: THREE.Mesh;
  position: THREE.Vector3;
  baseYaw: number;
  targetOpenAngle: number;
  currentOpenAngle: number;
  isOpen: boolean;
  locked: boolean;
  destroyed: boolean;
  colliderIndex: number;
}

interface EnemyActor {
  id: string;
  callsign: string;
  archetype: EnemyArchetype;
  alertGroup: string;
  root: THREE.Group;
  headMesh: THREE.Mesh;
  torsoMesh: THREE.Mesh;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  armL: THREE.Mesh;
  armR: THREE.Mesh;
  laserLine: THREE.Line | null;
  position: THREE.Vector3;
  homePos: THREE.Vector3;
  patrolPos: THREE.Vector3 | null;
  patrolDir: number;
  aimYaw: number;
  stridePhase: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  koTimer: number;
  alerted: boolean;
  windupTimer: number;
  attackCooldown: number;
  burstRemaining: number;
  burstShotTimer: number;
  flashbangCooldown: number;
  grenadeCooldown: number;
  hitFlashTimer: number;
  strafeSign: number;
  strafeTimer: number;
  respawnTimerSec: number;
}

interface AllyActor {
  id: string;
  callsign: string;
  root: THREE.Group;
  torsoMesh: THREE.Mesh;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  armL: THREE.Mesh;
  armR: THREE.Mesh;
  position: THREE.Vector3;
  homePos: THREE.Vector3;
  aimYaw: number;
  stridePhase: number;
  hp: number;
  maxHp: number;
  state: 'alive' | 'knocked' | 'dead';
  knockedTimerSec: number;
  respawnTimerSec: number;
  fireCooldown: number;
  hitFlashTimer: number;
  helpShoutCooldown: number;
}

interface ActiveGrenade {
  id: string;
  fromPlayer: boolean;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  fuseTimer: number;
}

interface LootCrateActor {
  id: string;
  mesh: THREE.Group;
  position: THREE.Vector3;
  contents: LootCrateContents;
  collected: boolean;
  isAirdrop?: boolean;
  isDescending?: boolean;
  chuteGroup?: THREE.Group;
  smokeTimer?: number;
}

interface PooledParticle {
  active: boolean;
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  scale: number;
  color: THREE.Color;
}

interface TracerBeam {
  mesh: THREE.Mesh;
  life: number;
}

// Pre-allocated scratch math helpers (Zero-GC render loop)
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _mat4 = new THREE.Matrix4();
const _quat = new THREE.Quaternion();
const _scale = new THREE.Vector3();
const _color = new THREE.Color();

export class BlackHorizonEngine {
  private container: HTMLElement;
  private onHudUpdate: (snapshot: HudSnapshot) => void;
  private audio = new TacticalAudioEngine();

  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private isSoftwareGl = false;

  private frameId = 0;
  private lastTimeMs = 0;
  private hudSyncTimer = 0;
  private hitstopTimer = 0;

  // Game & Mission State
  private gameState: GameState = 'title';
  private outcome: 'none' | 'victory' | 'defeat' | 'draw' = 'none';
  private elapsedSec = 0;
  private phaseIndex = 0;
  private stealthAlerted = false;
  private aegisExtracted = false;
  private triggersFired = new Set<string>();
  private commsQueue: RadioCommsLine[] = [];
  private activeComms: RadioCommsLine | null = null;
  private commsTimer = 0;

  // Player Kinematics & Health
  private playerPos = new THREE.Vector3(0, 0, 42);
  private playerVel = new THREE.Vector3();
  private yawRad = 0; // 0 = looking North (-Z)
  private pitchRad = -0.04;
  private stance: TacticalStance = 'standing';
  private eyeHeight = 1.66;
  private slideSpeed = 0;
  private slideDir = new THREE.Vector3(0, 0, -1);
  private verticalVel = 0;
  private isGrounded = true;
  private isMounted = false;
  private canMount = false;
  private mountLockYaw = 0;
  private hp = 100;
  private maxHp = 100;
  private regenDelayTimer = 0;
  private nvgActive = false;
  private nvgBattery = 100;
  private walkBobPhase = 0;
  private footstepAccum = 0;

  // Camera Trauma & Effects
  private trauma = 0;
  private damageFlashAlpha = 0;
  private damageDirRad: number | null = null;
  private hitMarkerTimer = 0;
  private hitMarkerHeadshot = false;
  private flashbangStunTimer = 0;

  // Weapons & Ballistics
  private activeWeaponId: WeaponId = 'mk18_suppressed';
  private weapons: Record<WeaponId, WeaponRuntimeState> = {
    mk18_suppressed: createInitialWeaponState('mk18_suppressed'),
    p226_suppressed: createInitialWeaponState('p226_suppressed'),
  };
  private weaponViewModels!: Record<
    WeaponId,
    { group: THREE.Group; muzzleFlash: THREE.Mesh; laserLine: THREE.Line }
  >;
  private weaponMountPivot = new THREE.Group();
  private adsBlend = 0;
  private isAds = false;
  private recoilPitchDeg = 0;
  private recoilYawDeg = 0;
  private weaponKickZ = 0;
  private muzzleFlashTimer = 0;
  private ammoRevealTimer = 2.5;
  private kills = 0;
  private headshots = 0;
  private shotsFired = 0;
  private shotsHit = 0;
  private breachesCompleted = 0;

  // Input State
  private keys = new Set<string>();
  private justPressed = new Set<string>();
  private mouseFireHeld = false;
  private mouseAdsHeld = false;
  private pointerLocked = false;
  private isDraggingLook = false;
  private lastPointerX = 0;
  private lastPointerY = 0;

  // World Objects & Lighting
  private colliders: AabbCollider[] = [];
  private raycastMeshes: THREE.Object3D[] = [];
  private doors: DoorActor[] = [];
  private enemies: EnemyActor[] = [];
  private floodlightMesh!: THREE.PointLight;
  private floodlightBulb!: THREE.Mesh;
  private transformerBox!: THREE.Mesh;
  private transformerAlive = true;
  private searchlightSpot!: THREE.SpotLight;
  private searchlightPivot = new THREE.Group();
  private radarDishPivot: THREE.Group | null = null;
  private beaconMesh: THREE.Mesh | null = null;
  private bunkerLight!: THREE.PointLight;
  private exfilBeaconLight!: THREE.PointLight;
  private exfilRingMesh!: THREE.Mesh;
  private aegisConsoleMesh!: THREE.Mesh;
  private moonLight!: THREE.DirectionalLight;
  private hemiLight!: THREE.HemisphereLight;
  private nvgLight!: THREE.PointLight;
  private fog!: THREE.FogExp2;

  // Rain & Pooled Particles
  private rainMesh!: THREE.InstancedMesh;
  private rainPositions!: Float32Array;
  private readonly RAIN_COUNT = 380;
  private particleMesh!: THREE.InstancedMesh;
  private particles: PooledParticle[] = [];
  private readonly PARTICLE_CAP = 72;
  private particleCursor = 0;
  private tracers: TracerBeam[] = [];
  private raycaster = new THREE.Raycaster();

  // Stats / Timers / Settings / Inventory / Mode / Squad
  private tourAngle = 0;
  private disposed = false;
  private settings: GameSettings = { ...DEFAULT_GAME_SETTINGS };
  private gameMode: GameMode = 'classic';
  private cameraPerspective: CameraPerspective = 'tpp';
  private grenadeCount = 3;
  private medkitCount = 1;
  private bandageCount = 2;
  private isHealing = false;
  private healKind: 'medkit' | 'bandage' | null = null;
  private healTimer = 0;
  private healDuration = 0;
  private activeGrenades: ActiveGrenade[] = [];
  private lootCrates: LootCrateActor[] = [];
  private crateWoodTex!: THREE.CanvasTexture;
  private contactShadowTex!: THREE.CanvasTexture;
  private grenadeThrowCooldown = 0;

  // Squadmates, Player 3D Avatar, 60s Airdrop & Arena 4v4 State
  private playerAvatar!: ReturnType<typeof buildFriendlySoldierMesh>;
  private allies: AllyActor[] = [];
  private revivingAllyId: string | null = null;
  private reviveTimer = 0;
  private airdropCooldownSec = AIRDROP_INTERVAL_SEC;
  private airdropDropCount = 0;
  private airdropJustDroppedBannerSec = 0;
  private arenaBlueKills = 0;
  private arenaRedKills = 0;
  private arenaTimeRemainingSec = ARENA_DURATION_SEC;
  private playerRespawnInvulnSec = 0;

  // 1v1 Hotspot / Room Multiplayer State & Target Marra (10/20/30/40)
  private selectedTargetKills: TargetKillsOption = 20;
  private selectedDurationSec = 300;
  private duelClient: DuelMultiplayerClient | null = null;
  private duelRoom: MultiplayerRoomState | null = null;
  private duelRespawnSec = 0;
  private remotePoseTarget: RemotePlayerPose | null = null;
  private remoteShotAlertTimer = 0;
  private remoteOpponent!: {
    root: THREE.Group;
    headMesh: THREE.Mesh;
    torsoMesh: THREE.Mesh;
    legL: THREE.Mesh;
    legR: THREE.Mesh;
    armL: THREE.Mesh;
    armR: THREE.Mesh;
    pos: THREE.Vector3;
    yaw: number;
    stridePhase: number;
    hitFlashTimer: number;
  };

  constructor(container: HTMLElement, onHudUpdate: (snapshot: HudSnapshot) => void) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;
    this.initRendererAndScene();
    this.buildEnvironment();
    this.buildWeaponViewmodels();
    this.buildParticlesAndRain();
    this.spawnMissionEntities();
    this.bindEvents();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.lastTimeMs = performance.now();
    this.pushHudSnapshot();
    this.scheduleNextTick();
  }

  private detectSoftwareGl(): boolean {
    try {
      const probe = document.createElement('canvas');
      const gl = probe.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    } catch {
      return true;
    }
  }

  private initRendererAndScene(): void {
    this.isSoftwareGl = this.detectSoftwareGl();
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2),
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x070c13);
    this.fog = new THREE.FogExp2(0x070c13, 0.017);
    this.scene.fog = this.fog;

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    this.camera = new THREE.PerspectiveCamera(72, w / h, 0.08, 220);
    this.camera.rotation.order = 'YXZ';
    this.scene.add(this.camera);

    // Lighting rig: cool slate moonlight + warm/cool HemisphereLight
    this.hemiLight = new THREE.HemisphereLight(0x4b6a8e, 0x16191e, 0.68);
    this.scene.add(this.hemiLight);

    this.moonLight = new THREE.DirectionalLight(0x9bc0e8, 1.35);
    this.moonLight.position.set(-28, 42, 24);
    this.moonLight.castShadow = !this.isSoftwareGl;
    this.moonLight.shadow.mapSize.set(1024, 1024);
    this.moonLight.shadow.camera.near = 2;
    this.moonLight.shadow.camera.far = 110;
    const d = 48;
    this.moonLight.shadow.camera.left = -d;
    this.moonLight.shadow.camera.right = d;
    this.moonLight.shadow.camera.top = d;
    this.moonLight.shadow.camera.bottom = -d;
    this.moonLight.shadow.bias = -0.0005;
    this.moonLight.shadow.normalBias = 0.02;
    this.scene.add(this.moonLight);

    // NVG IR illuminator attached to camera
    this.nvgLight = new THREE.PointLight(0x86efac, 0, 42, 1.4);
    this.camera.add(this.nvgLight);
  }

  private buildEnvironment(): void {
    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    const { map: asphaltMap, roughnessMap: asphaltRough } = createWetAsphaltTextures(maxAniso);
    const concreteTex = createConcreteTexture(maxAniso);

    // Extended outdoor terrain (240x240m) so horizon blends seamlessly into fog
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: asphaltMap,
      roughnessMap: asphaltRough,
      roughness: 0.72,
      metalness: 0.14,
    });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(240, 240), groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);
    this.raycastMeshes.push(ground);

    const concreteMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: concreteTex,
      roughness: 0.85,
      metalness: 0.08,
    });
    const darkMetalMat = new THREE.MeshStandardMaterial({
      color: 0x2a3038,
      roughness: 0.42,
      metalness: 0.72,
    });
    const woodTex = createWoodCrateTexture(maxAniso);
    this.crateWoodTex = woodTex;
    const crateWoodMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: woodTex,
      roughness: 0.86,
      metalness: 0.05,
    });
    const tireMat = new THREE.MeshStandardMaterial({
      color: 0x16181c,
      roughness: 0.9,
      metalness: 0.05,
    });

    const addSolidBox = (
      x: number,
      y: number,
      z: number,
      w: number,
      h: number,
      d: number,
      mat: THREE.Material,
      materialType: SurfaceMaterial,
      coverMountable = false,
    ): THREE.Mesh => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      mesh.position.set(x, y + h / 2, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.userData.surfaceMaterial = materialType;
      this.scene.add(mesh);
      this.raycastMeshes.push(mesh);
      this.colliders.push({
        minX: x - w / 2,
        maxX: x + w / 2,
        minZ: z - d / 2,
        maxZ: z + d / 2,
        maxY: y + h,
        material: materialType,
        coverMountable,
        mesh,
      });
      return mesh;
    };

    // Jagged Faceted Kashgar Mountain Ridges (flat-shaded crags around valley perimeter)
    const cliffMat = new THREE.MeshStandardMaterial({
      color: 0x161d26,
      roughness: 0.94,
      metalness: 0.04,
      flatShading: true,
    });
    const buildMountainRidge = (
      cx: number,
      cz: number,
      width: number,
      depth: number,
      peakHeight: number,
      seedOffset: number,
    ) => {
      const geo = new THREE.PlaneGeometry(width, depth, 14, 14);
      geo.rotateX(-Math.PI / 2);
      const pos = geo.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        const vx = pos.getX(i);
        const vz = pos.getZ(i);
        const edgeFalloff =
          (1 - Math.pow(Math.abs(vx) / (width * 0.52), 2)) *
          (1 - Math.pow(Math.abs(vz) / (depth * 0.52), 2));
        const crag =
          Math.abs(Math.sin(vx * 0.17 + seedOffset) * Math.cos(vz * 0.14 - seedOffset)) +
          0.45 * Math.abs(Math.sin((vx + vz) * 0.31));
        pos.setY(i, Math.max(-0.5, edgeFalloff * peakHeight * (0.45 + 0.55 * crag)));
      }
      geo.computeVertexNormals();
      const mesh = new THREE.Mesh(geo, cliffMat);
      mesh.position.set(cx, 0, cz);
      mesh.receiveShadow = true;
      this.scene.add(mesh);
    };

    buildMountainRidge(-46, 0, 38, 128, 22, 1.3);
    buildMountainRidge(46, 0, 38, 128, 24, 3.7);
    buildMountainRidge(0, -64, 130, 38, 28, 5.1);
    buildMountainRidge(-34, 48, 30, 34, 13, 2.4);
    buildMountainRidge(34, 48, 30, 34, 14, 4.2);

    // Lush Organic Conifer / Spruce Trees + Dense Treeline Silhouette (i_a602dea0 & i_20e1d359)
    const treeCount = 58;
    const trunkGeo = new THREE.CylinderGeometry(0.16, 0.28, 2.0, 6);
    const bushGeoA = new THREE.IcosahedronGeometry(1.55, 1);
    const bushGeoB = new THREE.IcosahedronGeometry(1.25, 1);
    const bushGeoC = new THREE.IcosahedronGeometry(0.95, 1);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x2d2118, roughness: 0.92 });
    const foliageMat = new THREE.MeshStandardMaterial({
      color: 0x23472b,
      roughness: 0.9,
      metalness: 0.02,
      flatShading: true,
    });
    const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
    const clusterAInst = new THREE.InstancedMesh(bushGeoA, foliageMat, treeCount);
    const clusterBInst = new THREE.InstancedMesh(bushGeoB, foliageMat, treeCount);
    const clusterCInst = new THREE.InstancedMesh(bushGeoC, foliageMat, treeCount);

    for (let i = 0; i < treeCount; i++) {
      const isBackRow = i >= 44;
      const side = i % 2 === 0 ? -1 : 1;
      const tx = isBackRow ? -28 + (i - 44) * 4.3 : side * (24 + ((i * 7) % 12));
      const tz = isBackRow ? -42 - (i % 3) * 2.5 : -38 + i * 1.95;
      const s = 0.9 + (i % 5) * 0.11;
      _quat.identity();
      _scale.set(s, s * 1.15, s);

      _v1.set(tx, 1.0 * s, tz);
      _mat4.compose(_v1, _quat, _scale);
      trunkInst.setMatrixAt(i, _mat4);

      _v1.set(tx, 2.4 * s, tz);
      _mat4.compose(_v1, _quat, _scale);
      clusterAInst.setMatrixAt(i, _mat4);

      _v1.set(tx + 0.35 * s, 3.6 * s, tz - 0.25 * s);
      _mat4.compose(_v1, _quat, _scale);
      clusterBInst.setMatrixAt(i, _mat4);

      _v1.set(tx - 0.2 * s, 4.7 * s, tz + 0.2 * s);
      _mat4.compose(_v1, _quat, _scale);
      clusterCInst.setMatrixAt(i, _mat4);

      _color.setHSL(0.35, 0.34, 0.14 + (i % 4) * 0.03);
      clusterAInst.setColorAt(i, _color);
      clusterBInst.setColorAt(i, _color);
      clusterCInst.setColorAt(i, _color);
    }
    trunkInst.computeBoundingSphere();
    clusterAInst.computeBoundingSphere();
    clusterBInst.computeBoundingSphere();
    clusterCInst.computeBoundingSphere();
    this.scene.add(trunkInst, clusterAInst, clusterBInst, clusterCInst);

    // Tall Sat-Com Radar Tower Landmark (North-Center, visible from Insertion Ridge)
    const satCom = buildSatComTower(darkMetalMat, concreteMat);
    satCom.group.position.set(0, 0, -34);
    this.radarDishPivot = satCom.dishPivot;
    this.beaconMesh = satCom.beaconMesh;
    this.scene.add(satCom.group);

    // Phase 0: Military Field Tent at Checkpoint (i_0fffe445.webp) + Jersey Barriers
    const checkpointTent = buildMilitaryTent();
    checkpointTent.position.set(-7.5, 0, 16.5);
    checkpointTent.rotation.y = Math.PI / 2;
    this.scene.add(checkpointTent);
    this.colliders.push({
      minX: -10.5,
      maxX: -4.5,
      minZ: 14.2,
      maxZ: 18.8,
      maxY: 2.8,
      material: 'wood',
    });

    const stagingTent = buildMilitaryTent();
    stagingTent.position.set(13.5, 0, 11.5);
    this.scene.add(stagingTent);
    this.colliders.push({
      minX: 11.2,
      maxX: 15.8,
      minZ: 8.5,
      maxZ: 14.5,
      maxY: 2.8,
      material: 'wood',
    });

    addSolidBox(-3.0, 0, 19.5, 3.4, 1.15, 0.8, concreteMat, 'concrete', true); // Mountable Jersey barrier L
    addSolidBox(3.0, 0, 19.5, 3.4, 1.15, 0.8, concreteMat, 'concrete', true); // Mountable Jersey barrier R
    addSolidBox(-11.5, 0, 15, 2.2, 1.3, 4.2, darkMetalMat, 'sheet_metal', true); // Checkpoint flatbed

    // Perimeter Fence Wings with wide 7m center roadway gate
    addSolidBox(-15, 0, 16, 10, 2.8, 0.5, darkMetalMat, 'sheet_metal');
    addSolidBox(15, 0, 16, 12, 2.8, 0.5, darkMetalMat, 'sheet_metal');

    // Floodlight Tower + Shootable Transformer Box at (5.5, 0, 17)
    addSolidBox(6.2, 0, 17, 0.4, 5.2, 0.4, darkMetalMat, 'sheet_metal');
    this.transformerBox = new THREE.Mesh(
      new THREE.BoxGeometry(0.65, 0.9, 0.45),
      new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.5, metalness: 0.6 }),
    );
    this.transformerBox.position.set(5.75, 1.4, 17);
    this.transformerBox.userData.isTransformer = true;
    this.transformerBox.userData.surfaceMaterial = 'sheet_metal';
    this.scene.add(this.transformerBox);
    this.raycastMeshes.push(this.transformerBox);

    this.floodlightBulb = new THREE.Mesh(
      new THREE.BoxGeometry(0.6, 0.35, 0.35),
      new THREE.MeshBasicMaterial({ color: 0xffd28a }),
    );
    this.floodlightBulb.position.set(5.9, 5.1, 17);
    this.scene.add(this.floodlightBulb);

    this.floodlightMesh = new THREE.PointLight(0xffb454, 14, 24, 1.6);
    this.floodlightMesh.position.set(5.2, 4.9, 17.4);
    this.scene.add(this.floodlightMesh);

    // Phase 1: Desert-Tan MRAP Vehicles & Wood Supply Crates (i_e4bf5904.webp)
    const mrap = buildMrapVehicle(darkMetalMat, tireMat);
    mrap.position.set(2.2, 0, -1.5);
    mrap.rotation.y = -0.35;
    this.scene.add(mrap);
    this.colliders.push({
      minX: 0.4,
      maxX: 4.0,
      minZ: -4.2,
      maxZ: 1.2,
      maxY: 2.6,
      material: 'armor_plate',
      coverMountable: true,
    });
    const mrapProxy = new THREE.Mesh(
      new THREE.BoxGeometry(2.8, 2.3, 5.5),
      new THREE.MeshBasicMaterial({ visible: false }),
    );
    mrapProxy.position.set(2.2, 1.15, -1.5);
    mrapProxy.rotation.y = -0.35;
    mrapProxy.userData.surfaceMaterial = 'armor_plate';
    this.scene.add(mrapProxy);
    this.raycastMeshes.push(mrapProxy);

    const mrap2 = buildMrapVehicle(darkMetalMat, tireMat);
    mrap2.position.set(7.2, 0, 9.5);
    mrap2.rotation.y = 0.25;
    this.scene.add(mrap2);
    this.colliders.push({
      minX: 5.5,
      maxX: 8.9,
      minZ: 6.8,
      maxZ: 12.2,
      maxY: 2.6,
      material: 'armor_plate',
      coverMountable: true,
    });

    addSolidBox(-3.6, 0, 4.5, 1.6, 1.1, 1.6, crateWoodMat, 'wood', true);
    addSolidBox(4.8, 0, -6.5, 1.8, 1.15, 1.4, crateWoodMat, 'wood', true);
    addSolidBox(-8.2, 0, 5.2, 1.5, 1.05, 1.5, crateWoodMat, 'wood', true);
    addSolidBox(-4.2, 0, -8.5, 2.6, 1.15, 0.7, concreteMat, 'concrete', true);

    // Barracks 13 (West Armory Wing, x = -17..-9.5, z = -6..6) with Pitched Roof & Ribbon Windows
    addSolidBox(-13.25, 0, -6, 7.5, 3.8, 0.6, concreteMat, 'concrete');
    addSolidBox(-13.25, 0, 6, 7.5, 3.8, 0.6, concreteMat, 'concrete');
    addSolidBox(-17, 0, 0, 0.6, 3.8, 12.6, concreteMat, 'concrete');
    addSolidBox(-9.5, 0, -2.5, 0.6, 3.8, 7.2, concreteMat, 'concrete');
    addSolidBox(-9.5, 0, 4.4, 0.6, 3.8, 3.2, concreteMat, 'concrete');
    addSolidBox(-9.5, 2.35, 2.0, 0.6, 1.45, 1.7, concreteMat, 'concrete');
    addSolidBox(-13.25, 3.8, 0, 8.2, 0.25, 12.8, concreteMat, 'concrete');
    const barracks13Details = buildBarracksDetails(7.8, 12.6, 3.9, '13', 'east');
    barracks13Details.position.set(-13.25, 0, 0);
    this.scene.add(barracks13Details);

    // Barracks 14 (East Wing, x = 9.5..17, z = -6..6) with Pitched Roof & Stencil "14"
    addSolidBox(13.25, 0, -6, 7.5, 3.8, 0.6, concreteMat, 'concrete');
    addSolidBox(13.25, 0, 6, 7.5, 3.8, 0.6, concreteMat, 'concrete');
    addSolidBox(17, 0, 0, 0.6, 3.8, 12.6, concreteMat, 'concrete');
    addSolidBox(9.5, 0, -3.5, 0.6, 3.8, 5.2, concreteMat, 'concrete');
    addSolidBox(9.5, 0, 3.5, 0.6, 3.8, 5.2, concreteMat, 'concrete');
    addSolidBox(9.5, 2.35, 0, 0.6, 1.45, 1.7, concreteMat, 'concrete');
    addSolidBox(13.25, 3.8, 0, 8.2, 0.25, 12.8, concreteMat, 'concrete');
    const barracks14Details = buildBarracksDetails(7.8, 12.6, 3.9, '14', 'west');
    barracks14Details.position.set(13.25, 0, 0);
    this.scene.add(barracks14Details);

    // 4-Legged Lattice Watchtower at (-18, 0, -14) matching reference (i_9a2a4ebd.webp)
    const watchtower = buildLatticeWatchtower(concreteMat, darkMetalMat);
    watchtower.position.set(-18, 0, -14);
    this.scene.add(watchtower);
    this.colliders.push({
      minX: -19.8,
      maxX: -16.2,
      minZ: -15.8,
      maxZ: -12.2,
      maxY: 4.8,
      material: 'sheet_metal',
    });

    // Crashed Military Cargo Plane Silhouette on right ridge (i_6e8364ca.webp lobby backdrop)
    const planeWreck = buildLobbyPlaneWreck(darkMetalMat);
    planeWreck.position.set(17.5, 0, -14);
    planeWreck.rotation.y = -0.55;
    this.scene.add(planeWreck);

    // Searchlight mounted on Watchtower
    this.searchlightPivot.position.set(-16.5, 6.2, -13.2);
    this.scene.add(this.searchlightPivot);
    this.searchlightSpot = new THREE.SpotLight(0xdbeafe, 24, 42, Math.PI / 7, 0.55, 1.4);
    this.searchlightSpot.position.set(0, 0, 0);
    this.searchlightSpot.target.position.set(0, -6.2, 16);
    this.searchlightPivot.add(this.searchlightSpot);
    this.searchlightPivot.add(this.searchlightSpot.target);

    // Phase 2: Command Bunker (x = -8..8, z = -30..-18) with South Blast Door at (0, 0, -18)
    addSolidBox(-4.6, 0, -18, 7.2, 3.8, 0.7, concreteMat, 'concrete'); // South wall W of door
    addSolidBox(4.6, 0, -18, 7.2, 3.8, 0.7, concreteMat, 'concrete'); // South wall E of door
    addSolidBox(0, 2.45, -18, 2.1, 1.35, 0.7, concreteMat, 'concrete'); // Blast door lintel
    addSolidBox(0, 0, -30, 16.6, 3.8, 0.7, concreteMat, 'concrete'); // North bunker wall
    addSolidBox(-8, 0, -24, 0.7, 3.8, 12.6, concreteMat, 'concrete'); // West bunker wall
    addSolidBox(8, 0, -24, 0.7, 3.8, 8.2, concreteMat, 'concrete'); // East bunker wall (leaves East exit open at z = -20..-18? No, doorway at z=-27..-29!)
    addSolidBox(0, 3.8, -24, 16.8, 0.45, 12.8, concreteMat, 'concrete'); // Bunker ceiling

    // Bunker interior lighting & Aegis Sat-Link Terminal at (0, 0, -26)
    this.bunkerLight = new THREE.PointLight(0xef4444, 7, 16, 1.5);
    this.bunkerLight.position.set(0, 3.1, -24);
    this.scene.add(this.bunkerLight);

    addSolidBox(0, 0, -26.4, 2.2, 1.1, 1.0, darkMetalMat, 'sheet_metal', true);
    this.aegisConsoleMesh = new THREE.Mesh(
      new THREE.BoxGeometry(1.1, 0.75, 0.25),
      new THREE.MeshStandardMaterial({
        color: 0x0ea5e9,
        emissive: 0x0284c7,
        emissiveIntensity: 1.4,
      }),
    );
    this.aegisConsoleMesh.position.set(0, 1.5, -26.4);
    this.scene.add(this.aegisConsoleMesh);

    // Exfil LZ "Specter-Actual" Helipad at (22, 0, -30)
    const pad = new THREE.Mesh(
      new THREE.CylinderGeometry(4.2, 4.4, 0.14, 20),
      concreteMat,
    );
    pad.position.set(22, 0.07, -30);
    pad.receiveShadow = true;
    this.scene.add(pad);

    this.exfilRingMesh = new THREE.Mesh(
      new THREE.RingGeometry(2.6, 2.9, 24),
      new THREE.MeshBasicMaterial({ color: 0x22c55e, side: THREE.DoubleSide }),
    );
    this.exfilRingMesh.rotation.x = -Math.PI / 2;
    this.exfilRingMesh.position.set(22, 0.16, -30);
    this.scene.add(this.exfilRingMesh);

    this.exfilBeaconLight = new THREE.PointLight(0x22c55e, 0, 18, 1.6);
    this.exfilBeaconLight.position.set(22, 1.8, -30);
    this.scene.add(this.exfilBeaconLight);

    // Build Breachable Doors
    const doorMat = new THREE.MeshStandardMaterial({
      color: 0x353c44,
      roughness: 0.45,
      metalness: 0.65,
    });
    for (const spec of MISSION_1_BREACH_DOORS) {
      const pivot = new THREE.Group();
      pivot.position.set(spec.position[0], 0, spec.position[2]);
      pivot.rotation.y = spec.yawRad;

      const doorMesh = new THREE.Mesh(
        new THREE.BoxGeometry(spec.widthM, spec.heightM, 0.14),
        doorMat,
      );
      doorMesh.position.set(spec.widthM / 2 - spec.widthM / 2, spec.heightM / 2, 0);
      // Offset pivot to left hinge edge
      doorMesh.position.set(spec.widthM / 2, spec.heightM / 2, 0);
      pivot.position.x -= Math.cos(spec.yawRad) * (spec.widthM / 2);
      pivot.position.z += Math.sin(spec.yawRad) * (spec.widthM / 2);
      doorMesh.castShadow = true;
      doorMesh.userData.surfaceMaterial = 'sheet_metal';
      pivot.add(doorMesh);
      this.scene.add(pivot);
      this.raycastMeshes.push(doorMesh);

      const colliderIndex = this.colliders.length;
      this.colliders.push({
        minX: spec.position[0] - (Math.abs(Math.cos(spec.yawRad)) * spec.widthM) / 2 - 0.3,
        maxX: spec.position[0] + (Math.abs(Math.cos(spec.yawRad)) * spec.widthM) / 2 + 0.3,
        minZ: spec.position[2] - (Math.abs(Math.sin(spec.yawRad)) * spec.widthM) / 2 - 0.3,
        maxZ: spec.position[2] + (Math.abs(Math.sin(spec.yawRad)) * spec.widthM) / 2 + 0.3,
        maxY: spec.heightM,
        material: 'sheet_metal',
      });

      this.doors.push({
        id: spec.id,
        label: spec.label,
        pivot,
        doorMesh,
        position: new THREE.Vector3(...spec.position),
        baseYaw: spec.yawRad,
        targetOpenAngle: 0,
        currentOpenAngle: 0,
        isOpen: false,
        locked: spec.locked,
        destroyed: false,
        colliderIndex,
      });
    }
  }

  private buildWeaponViewmodels(): void {
    this.camera.add(this.weaponMountPivot);
    this.weaponViewModels = {
      mk18_suppressed: buildPlayerWeaponGroup('mk18_suppressed'),
      p226_suppressed: buildPlayerWeaponGroup('p226_suppressed'),
    };
    this.weaponMountPivot.add(this.weaponViewModels.mk18_suppressed.group);
    this.weaponMountPivot.add(this.weaponViewModels.p226_suppressed.group);
    this.weaponViewModels.p226_suppressed.group.visible = false;
  }

  private buildParticlesAndRain(): void {
    // Pooled Rain Streaks
    const rainGeo = new THREE.BoxGeometry(0.014, 0.65, 0.014);
    const rainMat = new THREE.MeshBasicMaterial({
      color: 0x94a3b8,
      transparent: true,
      opacity: 0.34,
    });
    this.rainMesh = new THREE.InstancedMesh(rainGeo, rainMat, this.RAIN_COUNT);
    this.rainMesh.frustumCulled = false;
    this.rainPositions = new Float32Array(this.RAIN_COUNT * 3);
    for (let i = 0; i < this.RAIN_COUNT; i++) {
      this.rainPositions[i * 3] = (Math.random() - 0.5) * 34;
      this.rainPositions[i * 3 + 1] = Math.random() * 14;
      this.rainPositions[i * 3 + 2] = (Math.random() - 0.5) * 34;
    }
    this.scene.add(this.rainMesh);

    // Pooled Impact/Spark/Blood/Debris Ring Buffer
    const partGeo = new THREE.BoxGeometry(0.08, 0.08, 0.08);
    const partMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    this.particleMesh = new THREE.InstancedMesh(partGeo, partMat, this.PARTICLE_CAP);
    this.particleMesh.frustumCulled = false;
    for (let i = 0; i < this.PARTICLE_CAP; i++) {
      this.particles.push({
        active: false,
        pos: new THREE.Vector3(0, -50, 0),
        vel: new THREE.Vector3(),
        life: 0,
        maxLife: 0.4,
        scale: 0,
        color: new THREE.Color(0xfbbf24),
      });
      _v1.set(0, -50, 0);
      _quat.identity();
      _scale.set(0, 0, 0);
      _mat4.compose(_v1, _quat, _scale);
      this.particleMesh.setMatrixAt(i, _mat4);
    }
    this.scene.add(this.particleMesh);
  }

  private spawnMissionEntities(): void {
    const shadowTex = createRadialContactShadowTexture();
    this.contactShadowTex = shadowTex;
    for (const sp of MISSION_1_SPAWNS) {
      const built = buildEnemyMesh(sp.archetype, shadowTex);
      built.root.position.set(sp.position[0], sp.position[1], sp.position[2]);
      built.root.rotation.y = sp.facingYawRad;
      built.headMesh.userData.enemyId = sp.id;
      built.headMesh.userData.isHead = true;
      built.torsoMesh.userData.enemyId = sp.id;
      built.torsoMesh.userData.isHead = false;

      this.scene.add(built.root);
      this.raycastMeshes.push(built.headMesh, built.torsoMesh);

      const maxHp =
        sp.archetype === 'officer' ? 160 : sp.archetype === 'breacher' ? 115 : 85;

      this.enemies.push({
        id: sp.id,
        callsign: sp.callsign,
        archetype: sp.archetype,
        alertGroup: sp.alertGroup,
        root: built.root,
        headMesh: built.headMesh,
        torsoMesh: built.torsoMesh,
        legL: built.legL,
        legR: built.legR,
        armL: built.armL,
        armR: built.armR,
        laserLine: built.laserLine,
        position: new THREE.Vector3(...sp.position),
        homePos: new THREE.Vector3(...sp.position),
        patrolPos: sp.patrolTarget ? new THREE.Vector3(...sp.patrolTarget) : null,
        patrolDir: 1,
        aimYaw: sp.facingYawRad,
        stridePhase: Math.random() * Math.PI * 2,
        hp: maxHp,
        maxHp,
        alive: true,
        koTimer: 0,
        alerted: false,
        windupTimer: 0,
        attackCooldown: 1.2 + Math.random() * 0.8,
        burstRemaining: 0,
        burstShotTimer: 0,
        flashbangCooldown: 8,
        grenadeCooldown: 9 + Math.random() * 5,
        hitFlashTimer: 0,
        strafeSign: Math.random() > 0.5 ? 1 : -1,
        strafeTimer: 1.5,
        respawnTimerSec: 0,
      });
    }

    // Player 3D Soldier Avatar (Lobby Showcase + 3rd Person TPP)
    this.playerAvatar = buildFriendlySoldierMesh(true, shadowTex);
    this.playerAvatar.root.position.set(0.4, 0, 14.8);
    this.scene.add(this.playerAvatar.root);

    // 3 Allied Squadmates (Classic Squad + Arena 4v4 Blue Team)
    const allyConfigs = [
      { id: 'ALLY_DAGGER', callsign: 'DAGGER-2', offset: new THREE.Vector3(-3.2, 0, 24) },
      { id: 'ALLY_VIPER', callsign: 'VIPER-3', offset: new THREE.Vector3(3.2, 0, 24) },
      { id: 'ALLY_GHOST', callsign: 'GHOST-4', offset: new THREE.Vector3(-5.8, 0, 21) },
    ];
    for (const cfg of allyConfigs) {
      const built = buildFriendlySoldierMesh(false, shadowTex);
      built.root.position.copy(cfg.offset);
      this.scene.add(built.root);
      this.allies.push({
        id: cfg.id,
        callsign: cfg.callsign,
        root: built.root,
        torsoMesh: built.torsoMesh,
        legL: built.legL,
        legR: built.legR,
        armL: built.armL,
        armR: built.armR,
        position: cfg.offset.clone(),
        homePos: cfg.offset.clone(),
        aimYaw: Math.PI,
        stridePhase: Math.random() * Math.PI * 2,
        hp: 100,
        maxHp: 100,
        state: 'alive',
        knockedTimerSec: 0,
        respawnTimerSec: 0,
        fireCooldown: 0.7 + Math.random() * 0.6,
        hitFlashTimer: 0,
        helpShoutCooldown: 0,
      });
    }

    // 1v1 Remote Multiplayer Opponent Mesh (hidden outside duel_1v1)
    const oppBuilt = buildEnemyMesh('officer', shadowTex);
    const rivalPack = new THREE.Mesh(
      new THREE.BoxGeometry(0.32, 0.42, 0.16),
      new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.75 }),
    );
    rivalPack.position.set(0, 1.24, -0.2);
    oppBuilt.root.add(rivalPack);
    oppBuilt.headMesh.userData.isRemoteOpponent = true;
    oppBuilt.headMesh.userData.isHead = true;
    oppBuilt.torsoMesh.userData.isRemoteOpponent = true;
    oppBuilt.torsoMesh.userData.isHead = false;
    oppBuilt.root.visible = false;
    this.scene.add(oppBuilt.root);
    this.raycastMeshes.push(oppBuilt.headMesh, oppBuilt.torsoMesh);
    this.remoteOpponent = {
      root: oppBuilt.root,
      headMesh: oppBuilt.headMesh,
      torsoMesh: oppBuilt.torsoMesh,
      legL: oppBuilt.legL,
      legR: oppBuilt.legR,
      armL: oppBuilt.armL,
      armR: oppBuilt.armR,
      pos: new THREE.Vector3(16, 0, -24),
      yaw: Math.PI,
      stridePhase: 0,
      hitFlashTimer: 0,
    };
  }

  private spawnBurstParticles(
    origin: THREE.Vector3,
    colorHex: number,
    count: number,
    speed: number,
  ): void {
    for (let i = 0; i < count; i++) {
      const p = this.particles[this.particleCursor];
      this.particleCursor = (this.particleCursor + 1) % this.PARTICLE_CAP;
      p.active = true;
      p.pos.copy(origin);
      p.vel.set(
        (Math.random() - 0.5) * speed,
        Math.random() * speed * 0.75 + 0.8,
        (Math.random() - 0.5) * speed,
      );
      p.maxLife = 0.25 + Math.random() * 0.25;
      p.life = p.maxLife;
      p.scale = 0.7 + Math.random() * 0.7;
      p.color.setHex(colorHex);
    }
  }

  public startMission(fromUserGesture = true): void {
    if (fromUserGesture) {
      this.audio.unlock();
    }
    this.resetMissionState();
    this.gameState = 'playing';
    document.body.dataset.state = 'playing';
    this.triggerScriptZone('TRG_01_INSERTION');
    if (fromUserGesture) {
      this.requestPointerLockSafe();
    }
    this.pushHudSnapshot();
  }

  public resumeMission(): void {
    if (this.gameState !== 'paused') return;
    this.audio.unlock();
    this.gameState = 'playing';
    document.body.dataset.state = 'playing';
    this.requestPointerLockSafe();
    this.pushHudSnapshot();
  }

  public pauseMission(): void {
    if (this.gameState !== 'playing') return;
    this.gameState = 'paused';
    document.body.dataset.state = 'paused';
    this.clearHeldInputs();
    document.exitPointerLock?.();
    this.pushHudSnapshot();
  }

  public returnToTitle(): void {
    this.gameState = 'title';
    this.duelRespawnSec = 0;
    document.body.dataset.state = 'title';
    this.clearHeldInputs();
    document.exitPointerLock?.();
    this.pushHudSnapshot();
  }

  public toggleMute(): void {
    this.audio.toggleMute();
    this.pushHudSnapshot();
  }

  public setGameMode(mode: GameMode): void {
    this.gameMode = mode;
    this.pushHudSnapshot();
  }

  public setTargetKills(target: TargetKillsOption): void {
    this.selectedTargetKills = target;
    this.pushHudSnapshot();
  }

  public setMatchDurationSec(sec: number): void {
    this.selectedDurationSec = sec;
    this.pushHudSnapshot();
  }

  public startDuelMatch(room: MultiplayerRoomState, client: DuelMultiplayerClient): void {
    this.audio.unlock();
    this.gameMode = 'duel_1v1';
    this.selectedTargetKills = room.targetKills;
    this.selectedDurationSec = room.durationSec;
    this.duelClient = client;
    this.duelRoom = room;
    this.remotePoseTarget = null;
    this.resetMissionState();
    this.gameState = 'playing';
    document.body.dataset.state = 'playing';
    this.updatePlayerMovementAndStance(0.016);
    this.renderer.render(this.scene, this.camera);
    this.requestPointerLockSafe();
    this.pushHudSnapshot();
  }

  public syncDuelRoomState(room: MultiplayerRoomState): void {
    this.duelRoom = room;
    if (this.gameMode === 'duel_1v1') {
      this.arenaTimeRemainingSec = room.timeRemainingSec;
    }
    this.pushHudSnapshot();
  }

  public applyRemoteOpponentPose(pose: RemotePlayerPose): void {
    this.remotePoseTarget = pose;
  }

  public applyRemoteShotFx(fx: RemoteShotFx): void {
    if (this.gameMode !== 'duel_1v1' || this.gameState !== 'playing') return;
    const origin = new THREE.Vector3(...fx.origin);
    const hitPoint = new THREE.Vector3(...fx.hitPoint);
    this.spawnTracer(origin, hitPoint);
    this.remoteShotAlertTimer = 2.0;
    const dist = origin.distanceTo(this.playerPos);
    this.audio.playEnemyGunshot(dist, fx.weaponId === 'mk18_suppressed');
  }

  public applyDuelDamageEvent(victimSlot: 1 | 2, victimHp: number, _headshot: boolean): void {
    if (this.gameMode !== 'duel_1v1' || this.gameState !== 'playing') return;
    if (victimSlot === this.duelRoom?.mySlot) {
      this.hp = victimHp;
      this.damageFlashAlpha = 0.88;
      this.trauma = Math.min(1, this.trauma + 0.42);
      const dx = this.remoteOpponent.pos.x - this.playerPos.x;
      const dz = this.remoteOpponent.pos.z - this.playerPos.z;
      this.damageDirRad = Math.atan2(dx, -dz) + this.yawRad;
    } else {
      this.remoteOpponent.hitFlashTimer = 0.08;
    }
    this.pushHudSnapshot();
  }

  public applyDuelKillEvent(
    killerSlot: 1 | 2,
    victimSlot: 1 | 2,
    p1Kills: number,
    p2Kills: number,
    respawnDelaySec: number,
  ): void {
    if (this.duelRoom) {
      for (const p of this.duelRoom.players) {
        if (p.slot === 1) p.kills = p1Kills;
        if (p.slot === 2) p.kills = p2Kills;
      }
    }
    if (killerSlot === this.duelRoom?.mySlot) {
      this.kills += 1;
      this.hitstopTimer = 0.04;
      this.audio.playHitMarker(true);
    }
    if (victimSlot === this.duelRoom?.mySlot) {
      this.hp = 0;
      this.duelRespawnSec = respawnDelaySec;
      this.isHealing = false;
      this.healKind = null;
      this.damageFlashAlpha = 0.95;
    } else {
      this.spawnBurstParticles(this.remoteOpponent.pos.clone().setY(1.1), 0x991b1b, 14, 4.5);
    }
    this.pushHudSnapshot();
  }

  public finishDuelMatch(room: MultiplayerRoomState): void {
    this.duelRoom = room;
    if (this.gameState !== 'playing' && this.gameState !== 'paused') return;
    const outcome: 'victory' | 'defeat' | 'draw' =
      room.winnerSlot === 'draw'
        ? 'draw'
        : room.winnerSlot === room.mySlot
          ? 'victory'
          : 'defeat';
    this.finishMission(outcome);
  }

  public setCameraPerspective(persp: CameraPerspective): void {
    this.cameraPerspective = persp;
    if (this.gameState === 'playing') {
      this.playerAvatar.root.visible = persp === 'tpp' && this.duelRespawnSec <= 0;
      this.weaponMountPivot.visible = persp === 'fpp' && this.duelRespawnSec <= 0;
    }
    this.pushHudSnapshot();
  }

  public togglePerspective(): void {
    this.setCameraPerspective(this.cameraPerspective === 'fpp' ? 'tpp' : 'fpp');
  }

  public equipWeapon(id: WeaponId): void {
    if (this.activeWeaponId !== id) {
      this.switchWeapon(id);
    }
  }

  public useBagItem(kind: 'medkit' | 'bandage'): boolean {
    if (this.gameState !== 'playing' || this.isHealing) return false;
    if (kind === 'medkit' && this.medkitCount > 0 && this.hp < this.maxHp) {
      this.isHealing = true;
      this.healKind = 'medkit';
      this.healDuration = HEAL_CONFIGS.medkit.castSec;
      this.healTimer = this.healDuration;
      this.audio.playHealBandage();
      this.pushHudSnapshot();
      return true;
    }
    if (kind === 'bandage' && this.bandageCount > 0 && this.hp < HEAL_CONFIGS.bandage.capHp) {
      this.isHealing = true;
      this.healKind = 'bandage';
      this.healDuration = HEAL_CONFIGS.bandage.castSec;
      this.healTimer = this.healDuration;
      this.audio.playHealBandage();
      this.pushHudSnapshot();
      return true;
    }
    return false;
  }

  public triggerReviveNearby(): boolean {
    if (this.gameState !== 'playing') return false;
    const knocked = this.getNearbyKnockedAlly();
    if (!knocked) return false;
    if (this.revivingAllyId !== knocked.id) {
      this.revivingAllyId = knocked.id;
      this.reviveTimer = REVIVE_CHANNEL_SEC;
      this.isHealing = false;
      this.healKind = null;
      this.audio.playHealBandage();
      this.pushHudSnapshot();
    }
    return true;
  }

  public applySettings(next: GameSettings): void {
    this.settings = { ...next };
    this.audio.setMasterVolume(this.settings.masterVolume);
    if (!this.isAds && this.camera) {
      this.camera.fov = this.settings.fov;
      this.camera.updateProjectionMatrix();
    }
  }

  private requestPointerLockSafe(): void {
    try {
      const el = this.renderer.domElement;
      if (el && el.requestPointerLock) {
        const res = el.requestPointerLock() as unknown as Promise<void> | undefined;
        if (res && typeof res.catch === 'function') {
          res.catch(() => {});
        }
      }
    } catch {
      // Headless or sandboxed iframes may reject pointer lock gracefully
    }
  }

  private resetMissionState(): void {
    this.outcome = 'none';
    this.elapsedSec = 0;
    this.phaseIndex = 0;
    const isArena = this.gameMode === 'arena_4v4';
    const isDuel = this.gameMode === 'duel_1v1';
    const isPvpLike = isArena || isDuel;
    this.stealthAlerted = isPvpLike;

    if (isDuel) {
      const mySlot = this.duelRoom?.mySlot ?? 1;
      if (mySlot === 1) {
        this.playerPos.set(-10, 0, 22);
        this.yawRad = 0;
        this.remoteOpponent.pos.set(4, 0, -14);
        this.remoteOpponent.yaw = Math.PI;
      } else {
        this.playerPos.set(4, 0, -14);
        this.yawRad = Math.PI;
        this.remoteOpponent.pos.set(-10, 0, 22);
        this.remoteOpponent.yaw = 0;
      }
      this.remoteOpponent.root.position.copy(this.remoteOpponent.pos);
      this.remoteOpponent.root.rotation.set(0, this.remoteOpponent.yaw + Math.PI, 0);
      this.remoteOpponent.root.visible = true;
    } else {
      this.playerPos.set(0, 0, isArena ? 24 : 42);
      this.yawRad = 0;
      this.remoteOpponent.root.visible = false;
    }
    this.playerVel.set(0, 0, 0);
    this.pitchRad = -0.04;
    this.stance = 'standing';
    this.eyeHeight = 1.66;
    this.isMounted = false;
    this.hp = 100;
    this.nvgActive = false;
    this.nvgBattery = 100;
    this.trauma = 0;
    this.damageFlashAlpha = 0;
    this.flashbangStunTimer = 0;
    this.kills = 0;
    this.headshots = 0;
    this.shotsFired = 0;
    this.shotsHit = 0;
    this.breachesCompleted = 0;
    this.grenadeCount = 3;
    this.medkitCount = 2;
    this.bandageCount = 3;
    this.isHealing = false;
    this.healKind = null;
    this.healTimer = 0;
    this.healDuration = 0;
    this.grenadeThrowCooldown = 0;

    this.revivingAllyId = null;
    this.reviveTimer = 0;
    this.airdropCooldownSec = AIRDROP_INTERVAL_SEC;
    this.airdropDropCount = 0;
    this.airdropJustDroppedBannerSec = 0;
    this.arenaBlueKills = 0;
    this.arenaRedKills = 0;
    this.arenaTimeRemainingSec = isDuel
      ? this.duelRoom?.durationSec ?? this.selectedDurationSec
      : this.selectedDurationSec || ARENA_DURATION_SEC;
    this.playerRespawnInvulnSec = 0;
    this.duelRespawnSec = 0;
    this.remoteShotAlertTimer = 0;

    // Clear active grenades and loot crates
    for (const g of this.activeGrenades) {
      this.scene.remove(g.mesh);
    }
    this.activeGrenades = [];
    for (const c of this.lootCrates) {
      this.scene.remove(c.mesh);
    }
    this.lootCrates = [];

    this.activeWeaponId = 'mk18_suppressed';
    this.weapons = {
      mk18_suppressed: createInitialWeaponState('mk18_suppressed'),
      p226_suppressed: createInitialWeaponState('p226_suppressed'),
    };
    this.weaponViewModels.mk18_suppressed.group.visible = true;
    this.weaponViewModels.p226_suppressed.group.visible = false;
    this.playerAvatar.root.visible = this.cameraPerspective === 'tpp';
    this.weaponMountPivot.visible = this.cameraPerspective === 'fpp';
    this.applyNvgVisualState(false);

    // Reset Transformer & Floodlight
    this.transformerAlive = true;
    this.transformerBox.visible = true;
    this.floodlightMesh.intensity = 14;
    (this.floodlightBulb.material as THREE.MeshBasicMaterial).color.setHex(0xffd28a);
    this.exfilBeaconLight.intensity = 0;

    // Reset Doors (open courtyard doors in Arena 4v4 & 1v1 Duel for fast PvP flow)
    for (let i = 0; i < this.doors.length; i++) {
      const d = this.doors[i];
      const spec = MISSION_1_BREACH_DOORS[i];
      d.destroyed = false;
      d.doorMesh.visible = true;
      d.isOpen = isPvpLike;
      d.targetOpenAngle = isPvpLike ? Math.PI * 0.5 : 0;
      d.currentOpenAngle = d.targetOpenAngle;
      d.pivot.rotation.y = d.baseYaw + d.currentOpenAngle;
      d.locked = isPvpLike ? false : spec.locked;
      this.colliders[d.colliderIndex].maxY = isPvpLike ? 0 : spec.heightM;
    }

    // Reset Allied Squadmates (hidden in 1v1 Duel)
    const allyBaseZ = isArena ? 22.5 : 39.5;
    const allyOffsets: [number, number][] = [
      [-3.2, allyBaseZ],
      [3.2, allyBaseZ],
      [-5.5, allyBaseZ - 2.0],
    ];
    for (let i = 0; i < this.allies.length; i++) {
      const a = this.allies[i];
      if (isDuel) {
        a.state = 'dead';
        a.hp = 0;
        a.root.visible = false;
        continue;
      }
      const [ax, az] = allyOffsets[i] || [0, allyBaseZ];
      a.position.set(ax, 0, az);
      a.homePos.set(ax, 0, az);
      a.root.position.copy(a.position);
      a.root.rotation.set(0, Math.PI, 0);
      a.root.visible = true;
      a.aimYaw = Math.PI;
      a.hp = 100;
      a.state = 'alive';
      a.knockedTimerSec = 0;
      a.respawnTimerSec = 0;
      a.fireCooldown = 0.6 + i * 0.25;
      a.helpShoutCooldown = 0;
    }

    // Reset Enemies (Disabled in 1v1 Duel; 4 Red fighters in Arena 4v4; full roster in Classic)
    const arenaEnemySpawns: [number, number][] = [
      [-6.5, -11.5],
      [-1.5, -13.5],
      [3.5, -13.5],
      [7.5, -10.5],
    ];
    for (let i = 0; i < this.enemies.length; i++) {
      const sp = MISSION_1_SPAWNS[i];
      const e = this.enemies[i];
      if (isDuel || (isArena && i >= 4)) {
        e.alive = false;
        e.root.visible = false;
        e.hp = 0;
        e.respawnTimerSec = 9999;
        continue;
      }
      e.root.visible = true;
      if (isArena) {
        const [ex, ez] = arenaEnemySpawns[i];
        e.position.set(ex, 0, ez);
        e.homePos.set(ex, 0, ez);
        e.alerted = true;
      } else {
        e.position.set(...sp.position);
        e.homePos.set(...sp.position);
        e.alerted = false;
      }
      e.root.position.copy(e.position);
      e.root.rotation.set(0, sp.facingYawRad, 0);
      e.aimYaw = sp.facingYawRad;
      e.stridePhase = Math.random() * Math.PI * 2;
      e.legL.rotation.x = 0;
      e.legR.rotation.x = 0;
      e.armL.rotation.x = -0.65;
      e.armR.rotation.x = -0.65;
      e.hp = e.maxHp;
      e.alive = true;
      e.koTimer = 0;
      e.windupTimer = 0;
      e.attackCooldown = 1.2 + Math.random() * 0.8;
      e.burstRemaining = 0;
      e.burstShotTimer = 0;
      e.grenadeCooldown = 9 + Math.random() * 5;
      e.strafeTimer = 1.5;
      e.respawnTimerSec = 0;
    }
  }

  private clearHeldInputs(): void {
    this.keys.clear();
    this.justPressed.clear();
    this.mouseFireHeld = false;
    this.mouseAdsHeld = false;
    this.isDraggingLook = false;
  }

  private bindEvents(): void {
    window.addEventListener('resize', this.onResize);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onWindowBlur);
    document.addEventListener('visibilitychange', this.onWindowBlur);
    document.addEventListener('pointerlockchange', this.onPointerLockChange);

    const dom = this.renderer.domElement;
    dom.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
    window.addEventListener('mousemove', this.onMouseMove);
    dom.addEventListener('contextmenu', this.onContextMenu);
  }

  private onContextMenu = (e: MouseEvent): void => {
    e.preventDefault();
  };

  private onResize = (): void => {
    if (this.disposed) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.renderer.render(this.scene, this.camera);
  };

  private onWindowBlur = (): void => {
    this.clearHeldInputs();
  };

  private onPointerLockChange = (): void => {
    this.pointerLocked = document.pointerLockElement === this.renderer.domElement;
    this.pushHudSnapshot();
  };

  private onKeyDown = (e: KeyboardEvent): void => {
    if (e.repeat) return;
    const code = e.code;

    if (this.gameState === 'playing') {
      this.audio.unlock();
      if (code === 'Escape' || code === 'KeyP') {
        e.preventDefault();
        this.pauseMission();
        return;
      }
      if (code === 'KeyM') {
        this.toggleMute();
        return;
      }
      if (code === 'KeyV') {
        this.togglePerspective();
        return;
      }
      this.keys.add(code);
      this.justPressed.add(code);
    } else if (this.gameState === 'paused') {
      if (code === 'Escape' || code === 'KeyP') {
        e.preventDefault();
        this.resumeMission();
      }
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
  };

  private onMouseDown = (e: MouseEvent): void => {
    if (this.gameState !== 'playing') return;
    this.audio.unlock();
    if (!this.pointerLocked) {
      this.requestPointerLockSafe();
      this.isDraggingLook = true;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
    }
    if (e.button === 0) {
      this.mouseFireHeld = true;
      this.justPressed.add('MouseLeft');
    } else if (e.button === 2) {
      this.mouseAdsHeld = true;
    }
  };

  private onMouseUp = (e: MouseEvent): void => {
    if (e.button === 0) this.mouseFireHeld = false;
    if (e.button === 2) this.mouseAdsHeld = false;
    this.isDraggingLook = false;
  };

  private onMouseMove = (e: MouseEvent): void => {
    if (this.gameState !== 'playing') return;
    const baseSens = 0.0022 * this.settings.lookSensitivity;
    const sens = this.isAds ? baseSens * this.settings.adsSensitivity : baseSens;
    let dx = 0;
    let dy = 0;
    if (this.pointerLocked) {
      dx = e.movementX;
      dy = e.movementY;
    } else if (this.isDraggingLook) {
      dx = e.clientX - this.lastPointerX;
      dy = e.clientY - this.lastPointerY;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
    } else {
      return;
    }
    const ySign = this.settings.invertY ? -1 : 1;
    this.yawRad -= dx * sens;
    this.pitchRad = THREE.MathUtils.clamp(this.pitchRad - dy * sens * ySign, -1.35, 1.35);
    if (this.isMounted) {
      // Clamp yaw arc while mounted to ±42°
      const diff = Math.atan2(
        Math.sin(this.yawRad - this.mountLockYaw),
        Math.cos(this.yawRad - this.mountLockYaw),
      );
      const clamped = THREE.MathUtils.clamp(diff, -0.73, 0.73);
      this.yawRad = this.mountLockYaw + clamped;
    }
  };

  private scheduleNextTick(): void {
    if (this.disposed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(() => this.tick());
    } else {
      this.frameId = requestAnimationFrame(() => this.tick());
    }
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick(): void {
    if (this.disposed) return;
    const nowMs = performance.now();
    const rawDt = (nowMs - this.lastTimeMs) / 1000;
    this.lastTimeMs = nowMs;
    const dt = Math.min(Math.max(rawDt, 0.001), 0.05);

    if (this.gameState === 'title') {
      this.updateTitleTour(dt);
    } else if (this.gameState === 'playing') {
      this.updatePlaying(dt);
    }

    this.updateAmbientWorldProps(dt);
    this.updateRain(dt);
    this.updateParticlesAndTracers(dt);
    this.renderer.render(this.scene, this.camera);
    this.justPressed.clear();
    this.scheduleNextTick();
  }

  private updateTitleTour(dt: number): void {
    // PUBG Mobile-style Lobby Backdrop (i_6e8364ca.webp):
    // ACU Soldier Avatar centered in foreground, MRAP & Watchtower on left, Crashed Plane on right.
    this.tourAngle += dt * 0.55;
    this.weaponMountPivot.visible = false;
    this.playerAvatar.root.visible = true;
    this.playerAvatar.root.position.set(0.2, 0, 15.2);
    this.playerAvatar.root.rotation.set(0, 0.24 + Math.sin(this.tourAngle * 0.45) * 0.05, 0);
    this.playerAvatar.legL.rotation.x = 0;
    this.playerAvatar.legR.rotation.x = 0;
    this.playerAvatar.armL.rotation.x = -0.65 + Math.sin(this.tourAngle) * 0.025;
    this.playerAvatar.armR.rotation.x = -0.65 - Math.sin(this.tourAngle) * 0.025;

    for (let i = 0; i < this.allies.length; i++) {
      this.allies[i].root.visible = false;
    }

    this.camera.position.set(
      0.35 + Math.sin(this.tourAngle * 0.3) * 0.28,
      1.38,
      19.2,
    );
    this.camera.lookAt(0.15, 1.15, 11.5);
  }

  private updatePlaying(dt: number): void {
    const isDuel = this.gameMode === 'duel_1v1';
    const isRespawningDuel = isDuel && this.duelRespawnSec > 0;
    this.weaponMountPivot.visible = this.cameraPerspective === 'fpp' && !isRespawningDuel;
    this.playerAvatar.root.visible = this.cameraPerspective === 'tpp' && !isRespawningDuel;

    // Hitstop pauses simulation physics briefly on heavy impact/kill while camera shake still ticks
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      this.trauma = Math.max(0, this.trauma - dt * 1.6);
      return;
    }

    this.elapsedSec += dt;
    if (this.playerRespawnInvulnSec > 0) {
      this.playerRespawnInvulnSec = Math.max(0, this.playerRespawnInvulnSec - dt);
    }
    if (this.remoteShotAlertTimer > 0) {
      this.remoteShotAlertTimer = Math.max(0, this.remoteShotAlertTimer - dt);
    }

    if (isDuel) {
      this.arenaTimeRemainingSec = Math.max(0, this.arenaTimeRemainingSec - dt);
      if (this.duelRespawnSec > 0) {
        this.duelRespawnSec = Math.max(0, this.duelRespawnSec - dt);
        if (this.duelRespawnSec <= 0) {
          const mySlot = this.duelRoom?.mySlot ?? 1;
          this.hp = 100;
          this.playerPos.set(mySlot === 1 ? -10 : 4, 0, mySlot === 1 ? 22 : -14);
          this.playerVel.set(0, 0, 0);
          this.yawRad = mySlot === 1 ? 0 : Math.PI;
          this.weapons.mk18_suppressed = createInitialWeaponState('mk18_suppressed');
          this.weapons.p226_suppressed = createInitialWeaponState('p226_suppressed');
          this.playerRespawnInvulnSec = 1.5;
        }
      }
    }

    this.updateComms(dt);
    this.updateAirdropSchedule(dt);
    if (!isRespawningDuel) {
      this.updatePlayerMovementAndStance(dt);
      this.updateWeaponSystem(dt);
      this.updateHealingAndGrenades(dt);
    }
    if (isDuel) {
      this.updateRemoteOpponent(dt);
      this.duelClient?.sendPoseThrottled({
        x: this.playerPos.x,
        y: this.playerPos.y,
        z: this.playerPos.z,
        yaw: this.yawRad,
        pitch: this.pitchRad,
        stance: this.stance,
        weaponId: this.activeWeaponId,
        isFiring: this.muzzleFlashTimer > 0,
        isReloading: this.weapons[this.activeWeaponId].isReloading,
      });
    } else {
      this.updateAllies(dt);
      this.updateEnemies(dt);
    }
    this.updateInteractions(dt);
    this.updateDoors(dt);
    this.updateLootCrates(dt);
    this.updateTriggersAndObjectives(dt);

    // Slow passive regen only in single-player modes (Aptechka/Bandages handle 1v1 Duel healing)
    if (!isDuel) {
      if (this.regenDelayTimer > 0) {
        this.regenDelayTimer -= dt;
      } else if (this.hp < this.maxHp && this.hp > 35) {
        this.hp = Math.min(this.maxHp, this.hp + dt * 4.5);
      }
    }

    // NVG battery slow drain
    if (this.nvgActive) {
      this.nvgBattery = Math.max(12, this.nvgBattery - dt * 0.45);
    }

    // Decay HUD flash timers
    this.damageFlashAlpha = Math.max(0, this.damageFlashAlpha - dt * 1.4);
    this.hitMarkerTimer = Math.max(0, this.hitMarkerTimer - dt);
    this.flashbangStunTimer = Math.max(0, this.flashbangStunTimer - dt);
    this.ammoRevealTimer = Math.max(0, this.ammoRevealTimer - dt);
    this.trauma = Math.max(0, this.trauma - dt * 1.85);

    this.hudSyncTimer += dt;
    if (this.hudSyncTimer >= 0.1) {
      this.hudSyncTimer = 0;
      this.pushHudSnapshot();
    }
  }

  private updateRemoteOpponent(dt: number): void {
    const opp = this.remoteOpponent;
    if (!opp.root.visible) return;
    if (opp.hitFlashTimer > 0) {
      opp.hitFlashTimer = Math.max(0, opp.hitFlashTimer - dt);
      (opp.torsoMesh.material as THREE.MeshStandardMaterial).emissive.setHex(
        opp.hitFlashTimer > 0 ? 0x991b1b : 0x000000,
      );
    }
    const target = this.remotePoseTarget;
    if (!target) return;
    const prevX = opp.pos.x;
    const prevZ = opp.pos.z;
    opp.pos.x = THREE.MathUtils.damp(opp.pos.x, target.x, 16, dt);
    opp.pos.y = THREE.MathUtils.damp(opp.pos.y, target.y, 16, dt);
    opp.pos.z = THREE.MathUtils.damp(opp.pos.z, target.z, 16, dt);
    opp.yaw = stepAngleRad(opp.yaw, target.yaw, 14, dt);
    opp.root.position.copy(opp.pos);
    opp.root.rotation.set(0, opp.yaw + Math.PI, 0);

    const stanceScaleY =
      target.stance === 'prone' ? 0.35 : target.stance === 'crouched' || target.stance === 'sliding' ? 0.68 : 1.0;
    opp.root.scale.y = THREE.MathUtils.damp(opp.root.scale.y, stanceScaleY, 12, dt);

    const moved = Math.hypot(opp.pos.x - prevX, opp.pos.z - prevZ);
    if (moved / Math.max(0.001, dt) > 0.15) {
      opp.stridePhase += moved * 3.2;
      const swing = Math.sin(opp.stridePhase) * 0.42;
      opp.legL.rotation.x = swing;
      opp.legR.rotation.x = -swing;
      opp.armL.rotation.x = -0.65 + swing * 0.18;
      opp.armR.rotation.x = -0.65 - swing * 0.18;
    } else {
      opp.legL.rotation.x = THREE.MathUtils.damp(opp.legL.rotation.x, 0, 12, dt);
      opp.legR.rotation.x = THREE.MathUtils.damp(opp.legR.rotation.x, 0, 12, dt);
    }
  }

  private updatePlayerMovementAndStance(dt: number): void {
    // Keyboard look fallback (ArrowLeft/ArrowRight)
    if (this.keys.has('ArrowLeft')) this.yawRad += dt * 1.8;
    if (this.keys.has('ArrowRight')) this.yawRad -= dt * 1.8;

    // Toggle NVG [N]
    if (this.justPressed.has('KeyN')) {
      this.nvgActive = !this.nvgActive;
      this.audio.playNvgToggle(this.nvgActive);
      this.applyNvgVisualState(this.nvgActive);
      this.pushHudSnapshot();
    }

    // Check Mountability (near waist-high cover or bunker wall)
    this.canMount = this.checkMountCoverNearby();
    if (this.justPressed.has('KeyQ')) {
      if (this.isMounted) {
        this.isMounted = false;
      } else if (this.canMount) {
        this.isMounted = true;
        this.mountLockYaw = this.yawRad;
        if (this.stance === 'tactical_sprint') this.stance = 'standing';
      }
      this.pushHudSnapshot();
    }

    // Directional Movement Intent
    let fwd = 0;
    let right = 0;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) fwd += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) fwd -= 1;
    if (this.keys.has('KeyD')) right += 1;
    if (this.keys.has('KeyA')) right -= 1;

    if ((Math.abs(fwd) > 0 || Math.abs(right) > 0) && this.isMounted) {
      // Moving breaks weapon mount
      this.isMounted = false;
    }

    // Stance Transitions: Crouch/Slide [C], Prone [Z], Tac-Sprint [ShiftLeft]
    if (this.justPressed.has('KeyC')) {
      if (this.stance === 'tactical_sprint' && fwd > 0) {
        this.stance = 'sliding';
        this.slideSpeed = 8.4;
        this.slideDir.set(-Math.sin(this.yawRad), 0, -Math.cos(this.yawRad)).normalize();
      } else if (this.stance === 'crouched') {
        this.stance = 'standing';
      } else {
        this.stance = 'crouched';
      }
    }
    if (this.justPressed.has('KeyZ')) {
      this.stance = this.stance === 'prone' ? 'standing' : 'prone';
    }

    const wantSprint =
      (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight')) && fwd > 0 && !this.isAds;
    if (this.stance !== 'sliding') {
      if (wantSprint) {
        this.stance = 'tactical_sprint';
      } else if (this.stance === 'tactical_sprint') {
        this.stance = 'standing';
      }
    }

    // Jump / Contextual Mantle [Space]
    if (this.justPressed.has('Space') && this.isGrounded) {
      if (this.stance === 'crouched' || this.stance === 'prone') {
        this.stance = 'standing';
      } else {
        this.verticalVel = 4.6;
        this.isGrounded = false;
      }
    }

    // Compute Horizontal Velocity
    if (this.stance === 'sliding') {
      const slideRes = stepSlideVelocity(this.slideSpeed, dt);
      this.slideSpeed = slideRes.nextSpeedMps;
      this.playerVel.copy(this.slideDir).multiplyScalar(this.slideSpeed);
      if (slideRes.finished) {
        this.stance = 'crouched';
      }
    } else {
      const targetSpeed = getTargetSpeedMps(this.stance, this.isAds, this.isMounted);
      _v1.set(-Math.sin(this.yawRad), 0, -Math.cos(this.yawRad));
      _v2.set(Math.cos(this.yawRad), 0, -Math.sin(this.yawRad));
      _v3.set(0, 0, 0).addScaledVector(_v1, fwd).addScaledVector(_v2, right);
      if (_v3.lengthSq() > 0.001) {
        _v3.normalize().multiplyScalar(targetSpeed);
      }
      const accel = this.isGrounded ? 14 : 5;
      this.playerVel.x = THREE.MathUtils.damp(this.playerVel.x, _v3.x, accel, dt);
      this.playerVel.z = THREE.MathUtils.damp(this.playerVel.z, _v3.z, accel, dt);
    }

    // Integrate & Resolve AABB Collisions (Sliding Axis Separation)
    const nextX = this.playerPos.x + this.playerVel.x * dt;
    if (!this.collidesAt(nextX, this.playerPos.z, 0.42)) {
      this.playerPos.x = THREE.MathUtils.clamp(nextX, -29, 29);
    }
    const nextZ = this.playerPos.z + this.playerVel.z * dt;
    if (!this.collidesAt(this.playerPos.x, nextZ, 0.42)) {
      this.playerPos.z = THREE.MathUtils.clamp(nextZ, -44, 46);
    }

    // Vertical Gravity / Ground
    this.verticalVel -= 14.5 * dt;
    this.playerPos.y += this.verticalVel * dt;
    if (this.playerPos.y <= 0) {
      this.playerPos.y = 0;
      this.verticalVel = 0;
      this.isGrounded = true;
    }

    // Smooth Eye Height & Distance-Synced Head Bob
    const targetEye = getEyeHeightForStance(this.stance);
    this.eyeHeight = THREE.MathUtils.damp(this.eyeHeight, targetEye, 11, dt);

    const horizSpeed = Math.hypot(this.playerVel.x, this.playerVel.z);
    if (this.isGrounded && horizSpeed > 0.4 && this.stance !== 'sliding') {
      this.walkBobPhase += horizSpeed * dt * 2.1;
      this.footstepAccum += horizSpeed * dt;
      const stepStride = this.stance === 'tactical_sprint' ? 2.1 : 1.7;
      if (this.footstepAccum >= stepStride) {
        this.footstepAccum = 0;
        this.audio.playFootstep(this.stance === 'tactical_sprint');
      }
    }

    // Indoor rain audio dampening (Command Bunker)
    const indoor =
      this.playerPos.x > -8 &&
      this.playerPos.x < 8 &&
      this.playerPos.z < -18 &&
      this.playerPos.z > -30;
    this.audio.setRainVolume(indoor);

    // Apply Camera Position (FPP or TPP Over-Shoulder) + Recoil + Trauma Shake
    const bobY = Math.sin(this.walkBobPhase * 2) * (this.isAds ? 0.008 : 0.025);
    const shakeSq = this.trauma * this.trauma;
    const shakePitch = (Math.random() - 0.5) * 0.045 * shakeSq;
    const shakeYaw = (Math.random() - 0.5) * 0.045 * shakeSq;

    if (this.cameraPerspective === 'tpp') {
      // Animate 3D player soldier avatar (ACU camo + backpack)
      this.playerAvatar.root.position.copy(this.playerPos);
      this.playerAvatar.root.rotation.set(0, this.yawRad + Math.PI, 0);
      const stanceScaleY =
        this.stance === 'prone' ? 0.35 : this.stance === 'crouched' || this.stance === 'sliding' ? 0.68 : 1.0;
      this.playerAvatar.root.scale.y = THREE.MathUtils.damp(this.playerAvatar.root.scale.y, stanceScaleY, 12, dt);

      if (horizSpeed > 0.25) {
        const swing = Math.sin(this.walkBobPhase) * 0.45;
        this.playerAvatar.legL.rotation.x = swing;
        this.playerAvatar.legR.rotation.x = -swing;
        this.playerAvatar.armL.rotation.x = -0.65 + swing * 0.18;
        this.playerAvatar.armR.rotation.x = -0.65 - swing * 0.18;
      } else {
        this.playerAvatar.legL.rotation.x = THREE.MathUtils.damp(this.playerAvatar.legL.rotation.x, 0, 12, dt);
        this.playerAvatar.legR.rotation.x = THREE.MathUtils.damp(this.playerAvatar.legR.rotation.x, 0, 12, dt);
        this.playerAvatar.armL.rotation.x = THREE.MathUtils.damp(this.playerAvatar.armL.rotation.x, -0.65, 12, dt);
        this.playerAvatar.armR.rotation.x = THREE.MathUtils.damp(this.playerAvatar.armR.rotation.x, -0.65, 12, dt);
      }

      const desiredDist = THREE.MathUtils.lerp(2.65, 1.38, this.adsBlend);
      let safeDist = desiredDist;
      for (let s = 0.7; s <= desiredDist; s += 0.35) {
        const probe = computeTppCameraPosition(
          this.playerPos.x,
          this.playerPos.y,
          this.playerPos.z,
          this.eyeHeight,
          this.yawRad,
          this.pitchRad,
          s,
          0.54,
        );
        if (this.collidesAt(probe.x, probe.z, 0.26)) {
          safeDist = Math.max(0.65, s - 0.3);
          break;
        }
      }
      const camTpp = computeTppCameraPosition(
        this.playerPos.x,
        this.playerPos.y,
        this.playerPos.z,
        this.eyeHeight,
        this.yawRad,
        this.pitchRad,
        safeDist,
        0.54,
      );
      this.camera.position.set(camTpp.x, camTpp.y + bobY * 0.4, camTpp.z);
    } else {
      this.camera.position.set(
        this.playerPos.x,
        this.playerPos.y + this.eyeHeight + bobY,
        this.playerPos.z,
      );
    }

    this.camera.rotation.set(
      this.pitchRad + THREE.MathUtils.degToRad(this.recoilPitchDeg) + shakePitch,
      this.yawRad + THREE.MathUtils.degToRad(this.recoilYawDeg) + shakeYaw,
      0,
    );
  }

  private collidesAt(x: number, z: number, radius: number): boolean {
    for (const c of this.colliders) {
      if (c.maxY <= 0.25) continue;
      if (
        x + radius > c.minX &&
        x - radius < c.maxX &&
        z + radius > c.minZ &&
        z - radius < c.maxZ
      ) {
        return true;
      }
    }
    return false;
  }

  private checkMountCoverNearby(): boolean {
    const fx = -Math.sin(this.yawRad);
    const fz = -Math.cos(this.yawRad);
    const px = this.playerPos.x + fx * 0.95;
    const pz = this.playerPos.z + fz * 0.95;
    for (const c of this.colliders) {
      if (!c.coverMountable) continue;
      if (px > c.minX - 0.5 && px < c.maxX + 0.5 && pz > c.minZ - 0.5 && pz < c.maxZ + 0.5) {
        return true;
      }
    }
    return false;
  }

  private updateWeaponSystem(dt: number): void {
    // Switch Weapon [1] / [2]
    if (this.justPressed.has('Digit1') && this.activeWeaponId !== 'mk18_suppressed') {
      this.switchWeapon('mk18_suppressed');
    } else if (this.justPressed.has('Digit2') && this.activeWeaponId !== 'p226_suppressed') {
      this.switchWeapon('p226_suppressed');
    }

    let wState = this.weapons[this.activeWeaponId];
    const spec = WEAPON_SPECS[this.activeWeaponId];

    // Cooldowns & Reload Progress
    if (wState.fireCooldown > 0) {
      wState = { ...wState, fireCooldown: Math.max(0, wState.fireCooldown - dt) };
    }
    if (wState.isReloading) {
      const nextTimer = wState.reloadTimer - dt;
      if (nextTimer <= 0) {
        wState = completeReload(wState);
        this.ammoRevealTimer = 2.6;
      } else {
        wState = { ...wState, reloadTimer: nextTimer };
      }
    }

    // Manual Reload [R]
    if (this.justPressed.has('KeyR') && !wState.isReloading) {
      const next = startReload(wState);
      if (next.isReloading) {
        wState = next;
        this.audio.playReloadClick(!wState.chambered);
        this.ammoRevealTimer = 3.0;
      }
    }

    // ADS [Right Mouse or KeyE]
    const wantAds = (this.mouseAdsHeld || this.keys.has('KeyE')) && !wState.isReloading;
    this.isAds = wantAds;
    const adsTime = computeEffectiveAdsTimeSec(
      spec,
      this.stance === 'tactical_sprint',
      this.isMounted,
    );
    const adsRate = 1 / Math.max(0.06, adsTime);
    this.adsBlend = THREE.MathUtils.clamp(
      this.adsBlend + (wantAds ? 1 : -1) * adsRate * dt,
      0,
      1,
    );

    const targetFov = THREE.MathUtils.lerp(
      this.settings.fov,
      Math.max(44, this.settings.fov - 20),
      this.adsBlend,
    );
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov = targetFov;
      this.camera.updateProjectionMatrix();
    }

    // Firing [Left Mouse or KeyK fallback]
    const triggerPulled =
      this.activeWeaponId === 'mk18_suppressed'
        ? this.mouseFireHeld || this.keys.has('KeyK')
        : this.justPressed.has('MouseLeft') || this.justPressed.has('KeyK');

    if (triggerPulled && this.stance !== 'tactical_sprint') {
      if (this.isHealing) {
        this.isHealing = false;
        this.healKind = null;
        this.healTimer = 0;
      }
      const firedRes = consumeRoundOnFire(wState);
      if (firedRes.fired) {
        wState = firedRes.nextState;
        this.executePlayerShot(wState);
      } else if (!wState.isReloading && wState.magAmmo === 0 && !wState.chambered) {
        const autoRel = startReload(wState);
        if (autoRel.isReloading) {
          wState = autoRel;
          this.audio.playReloadClick(true);
        }
      }
    } else if (!triggerPulled) {
      wState = { ...wState, burstIndex: 0 };
    }

    this.weapons[this.activeWeaponId] = wState;

    // Recoil Spring Recovery
    const rec = stepRecoilSpring(this.recoilPitchDeg, this.recoilYawDeg, dt);
    this.recoilPitchDeg = rec.pitchDeg;
    this.recoilYawDeg = rec.yawDeg;
    this.weaponKickZ = THREE.MathUtils.damp(this.weaponKickZ, 0, 18, dt);

    // Muzzle Flash Fade
    const vm = this.weaponViewModels[this.activeWeaponId];
    vm.laserLine.visible = this.nvgActive;
    if (this.muzzleFlashTimer > 0) {
      this.muzzleFlashTimer -= dt;
      (vm.muzzleFlash.material as THREE.MeshBasicMaterial).opacity = Math.max(
        0,
        this.muzzleFlashTimer * 12,
      );
    } else {
      (vm.muzzleFlash.material as THREE.MeshBasicMaterial).opacity = 0;
    }

    // Procedural Viewmodel Pose (Hip -> ADS -> Tactical Sprint High-Ready -> Reload Dip)
    const hipX = 0.22;
    const hipY = -0.21;
    const hipZ = -0.44;
    const adsX = 0.0;
    const adsY = this.activeWeaponId === 'mk18_suppressed' ? -0.104 : -0.052;
    const adsZ = -0.34;

    let vx = THREE.MathUtils.lerp(hipX, adsX, this.adsBlend);
    let vy = THREE.MathUtils.lerp(hipY, adsY, this.adsBlend);
    let vz = THREE.MathUtils.lerp(hipZ, adsZ, this.adsBlend) + this.weaponKickZ;
    let rotX = 0;
    let rotY = 0;
    let rotZ = 0;

    if (this.stance === 'tactical_sprint' && this.adsBlend < 0.15) {
      vx = 0.14;
      vy = -0.15;
      rotX = 0.55;
      rotY = 0.42;
      rotZ = -0.25;
    } else if (wState.isReloading) {
      vy -= 0.12;
      rotX = -0.35;
      rotZ = 0.25;
    } else {
      const swayAmp = this.isAds ? 0.002 : 0.009;
      vx += Math.cos(this.walkBobPhase) * swayAmp;
      vy += Math.abs(Math.sin(this.walkBobPhase)) * swayAmp * 0.8;
    }

    this.weaponMountPivot.position.set(
      THREE.MathUtils.damp(this.weaponMountPivot.position.x, vx, 18, dt),
      THREE.MathUtils.damp(this.weaponMountPivot.position.y, vy, 18, dt),
      THREE.MathUtils.damp(this.weaponMountPivot.position.z, vz, 18, dt),
    );
    this.weaponMountPivot.rotation.set(
      THREE.MathUtils.damp(this.weaponMountPivot.rotation.x, rotX, 14, dt),
      THREE.MathUtils.damp(this.weaponMountPivot.rotation.y, rotY, 14, dt),
      THREE.MathUtils.damp(this.weaponMountPivot.rotation.z, rotZ, 14, dt),
    );
  }

  private switchWeapon(nextId: WeaponId): void {
    this.weaponViewModels[this.activeWeaponId].group.visible = false;
    this.activeWeaponId = nextId;
    this.weaponViewModels[nextId].group.visible = true;
    this.ammoRevealTimer = 2.8;
    this.pushHudSnapshot();
  }

  private executePlayerShot(wState: WeaponRuntimeState): void {
    const spec = WEAPON_SPECS[wState.id];
    this.shotsFired += 1;
    this.ammoRevealTimer = 2.4;
    this.muzzleFlashTimer = 0.05;

    const indoor =
      this.playerPos.x > -8 &&
      this.playerPos.x < 8 &&
      this.playerPos.z < -18 &&
      this.playerPos.z > -30;
    this.audio.playSuppressedShot(spec.caliber, indoor);

    const impulse = computeShotRecoil(spec, wState.burstIndex, this.stance, this.isMounted);
    this.recoilPitchDeg += impulse.pitchDeg;
    this.recoilYawDeg += impulse.yawDeg;
    this.weaponKickZ = Math.min(0.06, this.weaponKickZ + impulse.kickZ);
    this.trauma = Math.min(0.45, this.trauma + 0.11);

    // Compute ray with spread & ballistic drop
    const spreadDeg = THREE.MathUtils.lerp(spec.hipSpreadDeg, spec.adsSpreadDeg, this.adsBlend);
    const spreadRad = THREE.MathUtils.degToRad(spreadDeg * (this.isMounted ? 0.45 : 1));
    const ndcX = (Math.random() - 0.5) * 2 * spreadRad;
    const ndcY = (Math.random() - 0.5) * 2 * spreadRad;

    _v1.set(ndcX, ndcY, -1).normalize().applyQuaternion(this.camera.quaternion);
    this.raycaster.set(this.camera.position, _v1);
    this.raycaster.far = 120;

    const hits = this.raycaster.intersectObjects(this.raycastMeshes, false);
    let endPoint = _v2.copy(this.camera.position).addScaledVector(_v1, 70);
    let damageScale = 1.0;

    for (const hit of hits) {
      endPoint = hit.point;
      const obj = hit.object;

      // Shootable Floodlight Transformer
      if (obj.userData.isTransformer && this.transformerAlive) {
        this.transformerAlive = false;
        this.transformerBox.visible = false;
        this.floodlightMesh.intensity = 0;
        (this.floodlightBulb.material as THREE.MeshBasicMaterial).color.setHex(0x1f2937);
        this.spawnBurstParticles(hit.point, 0xf59e0b, 18, 5.5);
        this.audio.playHitMarker(false);
        this.pushRadioLine({
          id: 'L_LIGHT_OUT',
          speaker: 'DAGGER',
          callsign: 'SPECTER-TWO // DAGGER',
          text: 'Checkpoint floodlight is dark. Good shot—sentries are blind on the east flank.',
          durationSec: 3.8,
        });
        break;
      }

      // Remote 1v1 Duel Opponent Hit
      if (this.gameMode === 'duel_1v1' && obj.userData.isRemoteOpponent) {
        const isHead = Boolean(obj.userData.isHead);
        const { impactDamage } = computeBallisticDropAndDamage(spec, hit.distance, isHead);
        const finalDmg = Math.max(8, Math.round(impactDamage * damageScale));
        this.hitMarkerTimer = 0.14;
        this.hitMarkerHeadshot = isHead;
        this.audio.playHitMarker(isHead);
        this.spawnBurstParticles(hit.point, 0x991b1b, isHead ? 12 : 7, 3.8);
        this.shotsHit += 1;
        if (isHead) this.headshots += 1;
        this.duelClient?.sendHit(finalDmg, isHead);
        break;
      }

      // Enemy Hit
      const enemyId = obj.userData.enemyId as string | undefined;
      if (enemyId) {
        const enemy = this.enemies.find((e) => e.id === enemyId);
        if (enemy && enemy.alive) {
          const isHead = Boolean(obj.userData.isHead);
          const { impactDamage } = computeBallisticDropAndDamage(spec, hit.distance, isHead);
          const finalDmg = Math.round(impactDamage * damageScale);
          this.damageEnemy(enemy, finalDmg, isHead, hit.point);
          this.shotsHit += 1;
          break;
        }
      }

      // World Material Penetration Check
      const mat = (obj.userData.surfaceMaterial as SurfaceMaterial | undefined) || 'concrete';
      this.spawnBurstParticles(
        hit.point,
        mat === 'sheet_metal' ? 0xfbbf24 : 0x94a3b8,
        5,
        3.5,
      );
      const pen = computeMaterialPenetration(spec, mat);
      if (!pen.penetrated) {
        break;
      }
      damageScale *= pen.damageMultiplier;
    }

    this.spawnTracer(this.camera.position, endPoint);
    if (this.gameMode === 'duel_1v1') {
      this.duelClient?.sendShotFx(
        [this.camera.position.x, this.camera.position.y, this.camera.position.z],
        [endPoint.x, endPoint.y, endPoint.z],
        this.activeWeaponId,
      );
    }
  }

  private damageEnemy(
    enemy: EnemyActor,
    amount: number,
    isHeadshot: boolean,
    hitPos: THREE.Vector3,
  ): void {
    enemy.hp -= amount;
    enemy.hitFlashTimer = 0.06;
    this.hitMarkerTimer = 0.14;
    this.hitMarkerHeadshot = isHeadshot;
    this.audio.playHitMarker(isHeadshot);
    this.spawnBurstParticles(hitPos, 0x991b1b, isHeadshot ? 12 : 7, 3.8);

    // Alert nearby squadmates if loud or enemy survives
    if (enemy.hp > 0) {
      this.alertGroup(enemy.alertGroup);
    }

    if (enemy.hp <= 0) {
      enemy.alive = false;
      enemy.koTimer = 0.35;
      enemy.burstRemaining = 0;
      if (enemy.laserLine) enemy.laserLine.visible = false;
      this.kills += 1;
      if (isHeadshot) this.headshots += 1;
      if (this.gameMode === 'arena_4v4') {
        this.arenaBlueKills += 1;
        enemy.respawnTimerSec = 3.5;
      }
      this.hitstopTimer = 0.038;
      this.spawnLootCrate(enemy.position, enemy.archetype);
      this.pushHudSnapshot();
    }
  }

  private spawnLootCrate(pos: THREE.Vector3, archetype: EnemyArchetype): void {
    const mesh = buildLootCrateMesh(this.crateWoodTex, this.contactShadowTex);
    mesh.position.set(pos.x, 0, pos.z);
    mesh.rotation.y = Math.random() * Math.PI * 2;
    this.scene.add(mesh);

    const contents = createEnemyLootDrop(archetype, Math.random());
    this.lootCrates.push({
      id: `CRATE_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      mesh,
      position: new THREE.Vector3(pos.x, 0, pos.z),
      contents,
      collected: false,
    });
  }

  private updateAirdropSchedule(dt: number): void {
    if (this.airdropJustDroppedBannerSec > 0) {
      this.airdropJustDroppedBannerSec = Math.max(0, this.airdropJustDroppedBannerSec - dt);
    }
    this.airdropCooldownSec -= dt;
    if (this.airdropCooldownSec <= 0) {
      this.airdropCooldownSec = AIRDROP_INTERVAL_SEC;
      this.spawnAirdropCrate();
    }
  }

  private spawnAirdropCrate(): void {
    const dropSpots: [number, number][] = [
      [0, 6.5],
      [-5.2, -2.5],
      [5.2, -9.5],
      [-4.0, 12.5],
    ];
    const [dx, dz] = dropSpots[this.airdropDropCount % dropSpots.length];
    this.airdropDropCount += 1;

    const built = buildAirdropCrateMesh(this.contactShadowTex);
    built.root.position.set(dx, 22, dz);
    this.scene.add(built.root);

    this.lootCrates.push({
      id: `AIRDROP_${this.airdropDropCount}_${Date.now()}`,
      mesh: built.root,
      position: new THREE.Vector3(dx, 0, dz),
      contents: createAirdropSupplyContents(),
      collected: false,
      isAirdrop: true,
      isDescending: true,
      chuteGroup: built.chuteGroup,
      smokeTimer: 0.4,
    });

    this.airdropJustDroppedBannerSec = 5.5;
    this.audio.playAirdropHorn();
    this.pushRadioLine({
      id: `DROP_${this.airdropDropCount}`,
      speaker: 'IRIS',
      callsign: 'OVERLORD // AIRDROP',
      text: 'Supply Drop incoming! Aptechka and heavy ammo crate parachuting into the courtyard.',
      durationSec: 4.5,
    });
    this.pushHudSnapshot();
  }

  private updateLootCrates(dt: number): void {
    const t = performance.now() * 0.004;
    for (const c of this.lootCrates) {
      if (c.collected) continue;
      if (c.isAirdrop) {
        if (c.isDescending) {
          c.mesh.position.y = Math.max(0, c.mesh.position.y - dt * 5.2);
          c.mesh.rotation.y += dt * 0.35;
          if (c.mesh.position.y <= 0.01) {
            c.mesh.position.y = 0;
            c.isDescending = false;
            if (c.chuteGroup) c.chuteGroup.visible = false;
            this.spawnBurstParticles(c.position.clone().setY(0.5), 0xef4444, 14, 4.5);
          }
        } else {
          // Red signal smoke plume from landed PUBG Airdrop
          c.smokeTimer = (c.smokeTimer ?? 0) - dt;
          if (c.smokeTimer <= 0) {
            c.smokeTimer = 0.65;
            this.spawnBurstParticles(c.position.clone().setY(1.15), 0xdc2626, 2, 1.8);
          }
        }
      } else {
        c.mesh.position.y = Math.sin(t + c.position.x) * 0.012 + 0.012;
      }
    }
  }

  private updateHealingAndGrenades(dt: number): void {
    // 1. Aptechka / Bandage Healing [H] / [4] / [5]
    if (this.grenadeThrowCooldown > 0) {
      this.grenadeThrowCooldown = Math.max(0, this.grenadeThrowCooldown - dt);
    }

    if (
      (this.justPressed.has('KeyH') || this.justPressed.has('Digit4')) &&
      !this.isHealing &&
      this.hp < this.maxHp &&
      this.medkitCount > 0
    ) {
      this.isHealing = true;
      this.healKind = 'medkit';
      this.healDuration = HEAL_CONFIGS.medkit.castSec;
      this.healTimer = this.healDuration;
      this.audio.playHealBandage();
      this.pushHudSnapshot();
    } else if (
      this.justPressed.has('Digit5') &&
      !this.isHealing &&
      this.hp < HEAL_CONFIGS.bandage.capHp &&
      this.bandageCount > 0
    ) {
      this.isHealing = true;
      this.healKind = 'bandage';
      this.healDuration = HEAL_CONFIGS.bandage.castSec;
      this.healTimer = this.healDuration;
      this.audio.playHealBandage();
      this.pushHudSnapshot();
    }

    if (this.isHealing && this.healKind) {
      if (this.stance === 'tactical_sprint') {
        this.isHealing = false;
        this.healKind = null;
        this.healTimer = 0;
      } else {
        this.healTimer -= dt;
        if (this.healTimer <= 0) {
          const nextHp = computeHealOutcome(this.hp, this.maxHp, this.healKind);
          const healCfg = HEAL_CONFIGS[this.healKind];
          this.hp = nextHp;
          if (this.gameMode === 'duel_1v1') {
            this.duelClient?.sendHeal(healCfg.healAmount, healCfg.capHp);
          }
          if (this.healKind === 'medkit') {
            this.medkitCount = Math.max(0, this.medkitCount - 1);
          } else {
            this.bandageCount = Math.max(0, this.bandageCount - 1);
          }
          this.isHealing = false;
          this.healKind = null;
          this.healTimer = 0;
          this.audio.playLootPickup();
          this.pushHudSnapshot();
        }
      }
    }

    // 2. Player Throw Frag Grenade [G] or [3]
    if (
      (this.justPressed.has('KeyG') || this.justPressed.has('Digit3')) &&
      this.grenadeCount > 0 &&
      this.grenadeThrowCooldown <= 0
    ) {
      this.grenadeCount -= 1;
      this.grenadeThrowCooldown = 0.7;
      this.isHealing = false;
      this.healKind = null;
      this.audio.playGrenadePinPull();

      const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion).normalize();
      const startPos = this.camera.position.clone().addScaledVector(forward, 0.55);
      startPos.y -= 0.1;
      const throwVel = forward.multiplyScalar(15.5);
      throwVel.y += 4.2;

      this.spawnActiveGrenade(startPos, throwVel, true, 1.85);
      this.pushHudSnapshot();
    }

    // 3. Step Active Grenades (Ballistic Arc + Floor/Wall Bounce + Detonation)
    for (let i = this.activeGrenades.length - 1; i >= 0; i--) {
      const g = this.activeGrenades[i];
      g.fuseTimer -= dt;
      g.vel.y -= 15.5 * dt;

      const nx = g.pos.x + g.vel.x * dt;
      if (this.collidesAt(nx, g.pos.z, 0.16)) {
        g.vel.x *= -0.45;
        this.audio.playGrenadeBounce();
      } else {
        g.pos.x = nx;
      }

      const nz = g.pos.z + g.vel.z * dt;
      if (this.collidesAt(g.pos.x, nz, 0.16)) {
        g.vel.z *= -0.45;
        this.audio.playGrenadeBounce();
      } else {
        g.pos.z = nz;
      }

      g.pos.y += g.vel.y * dt;
      if (g.pos.y <= 0.08) {
        g.pos.y = 0.08;
        if (Math.abs(g.vel.y) > 1.2) {
          g.vel.y = Math.abs(g.vel.y) * 0.42;
          g.vel.x *= 0.68;
          g.vel.z *= 0.68;
          this.audio.playGrenadeBounce();
        } else {
          g.vel.y = 0;
          g.vel.x *= 0.85;
          g.vel.z *= 0.85;
        }
      }

      g.mesh.position.copy(g.pos);
      if (g.vel.lengthSq() > 0.2) {
        g.mesh.rotation.x += dt * 7;
        g.mesh.rotation.z += dt * 5;
      }

      if (g.fuseTimer <= 0) {
        this.detonateGrenade(g);
        this.scene.remove(g.mesh);
        this.activeGrenades.splice(i, 1);
      }
    }
  }

  private spawnActiveGrenade(
    pos: THREE.Vector3,
    vel: THREE.Vector3,
    fromPlayer: boolean,
    fuseSec: number,
  ): void {
    const mesh = buildGrenadeMesh();
    mesh.position.copy(pos);
    this.scene.add(mesh);
    this.activeGrenades.push({
      id: `GREN_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      fromPlayer,
      mesh,
      pos: pos.clone(),
      vel: vel.clone(),
      fuseTimer: fuseSec,
    });
  }

  private detonateGrenade(g: ActiveGrenade): void {
    const distToPlayer = g.pos.distanceTo(this.playerPos);
    this.audio.playGrenadeExplosion(distToPlayer);

    // Visceral fireball, embers & smoke burst
    this.spawnBurstParticles(g.pos, 0xf97316, 18, 9.5);
    this.spawnBurstParticles(g.pos, 0xfacc15, 10, 7.0);
    this.spawnBurstParticles(g.pos, 0x52525b, 10, 4.5);

    const proximityTrauma = Math.max(0.15, 1.0 - distToPlayer / 16);
    this.trauma = Math.min(1.0, this.trauma + proximityTrauma * 0.85);
    if (distToPlayer < 10) {
      this.hitstopTimer = 0.045;
    }

    // Blast damage to enemies (or remote 1v1 opponent)
    if (this.gameMode === 'duel_1v1' && g.fromPlayer) {
      const d = g.pos.distanceTo(this.remoteOpponent.pos);
      const dmg = computeExplosionDamage(d, 110, 7.5);
      if (dmg > 0) {
        this.hitMarkerTimer = 0.14;
        this.audio.playHitMarker(false);
        this.duelClient?.sendHit(dmg, false);
      }
    }
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const d = g.pos.distanceTo(e.position);
      const dmg = computeExplosionDamage(d, 165, 8.0);
      if (dmg > 0) {
        this.damageEnemy(e, dmg, false, e.position.clone().setY(1.1));
      } else if (d < 22) {
        this.alertGroup(e.alertGroup);
      }
    }

    // Blast shatters nearby doors
    for (const d of this.doors) {
      if (!d.destroyed && g.pos.distanceTo(d.position) < 4.2) {
        d.destroyed = true;
        d.doorMesh.visible = false;
        this.colliders[d.colliderIndex].maxY = 0;
        this.breachesCompleted += 1;
      }
    }

    // Blast damage to player (reduced if crouched/prone behind distance)
    const playerDmg = computeExplosionDamage(distToPlayer, g.fromPlayer ? 75 : 88, 6.8);
    if (playerDmg > 0) {
      this.applyPlayerDamage(playerDmg, g.pos);
    }

    this.stealthAlerted = true;
    this.pushHudSnapshot();
  }

  private spawnTracer(start: THREE.Vector3, end: THREE.Vector3): void {
    const dist = start.distanceTo(end);
    if (dist < 0.5) return;
    const geo = new THREE.CylinderGeometry(0.008, 0.008, dist, 4);
    geo.rotateX(Math.PI / 2);
    const mat = new THREE.MeshBasicMaterial({
      color: this.nvgActive ? 0x86efac : 0xfef08a,
      transparent: true,
      opacity: 0.45,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(start).lerp(end, 0.5);
    mesh.lookAt(end);
    this.scene.add(mesh);
    this.tracers.push({ mesh, life: 0.065 });
  }

  private getNearbyLootCrate(): LootCrateActor | null {
    let best: LootCrateActor | null = null;
    let bestDist = 2.95;
    for (const c of this.lootCrates) {
      if (c.collected || c.isDescending) continue;
      const d = Math.hypot(c.position.x - this.playerPos.x, c.position.z - this.playerPos.z);
      if (d < bestDist) {
        bestDist = d;
        best = c;
      }
    }
    return best;
  }

  private getNearbyKnockedAlly(): AllyActor | null {
    let best: AllyActor | null = null;
    let bestDist = 3.5;
    for (const a of this.allies) {
      if (a.state !== 'knocked') continue;
      const d = Math.hypot(a.position.x - this.playerPos.x, a.position.z - this.playerPos.z);
      if (d < bestDist) {
        bestDist = d;
        best = a;
      }
    }
    return best;
  }

  private getNearbyInteractable(): {
    type: 'door' | 'aegis' | 'loot' | 'revive';
    door?: DoorActor;
    crate?: LootCrateActor;
    ally?: AllyActor;
    prompt: string;
  } | null {
    // Priority 1: Revive Knocked Squadmate ("HELP!")
    const knocked = this.getNearbyKnockedAlly();
    if (knocked) {
      return {
        type: 'revive',
        ally: knocked,
        prompt: `[F] KO'TARISH / REVIVE ${knocked.callsign} ("HELP!")`,
      };
    }
    // Priority 2: Aegis Console (Classic mode)
    if (
      this.gameMode === 'classic' &&
      !this.aegisExtracted &&
      this.playerPos.distanceTo(this.aegisConsoleMesh.position) < 3.1
    ) {
      return { type: 'aegis', prompt: '[F] EXTRACT PROJECT AEGIS SAT-LINK DRIVE' };
    }
    // Priority 3: Enemy Death Loot Crate / PUBG Airdrop
    const crate = this.getNearbyLootCrate();
    if (crate) {
      const parts: string[] = [];
      if (crate.contents.medkits > 0) parts.push(`+${crate.contents.medkits} APTECHKA`);
      if (crate.contents.bandages > 0) parts.push(`+${crate.contents.bandages} BANDAGE`);
      if (crate.contents.grenades > 0) parts.push(`+${crate.contents.grenades} FRAG`);
      if (crate.contents.ammo > 0) parts.push(`+${crate.contents.ammo} AMMO`);
      const prefix = crate.isAirdrop ? 'AIRDROP' : 'LOOT CRATE';
      return {
        type: 'loot',
        crate,
        prompt: `[F] ${prefix} (${parts.join(' · ')})`,
      };
    }
    // Priority 4: Doors
    for (const d of this.doors) {
      if (d.destroyed) continue;
      if (this.playerPos.distanceTo(d.position) < 2.8) {
        if (d.locked) {
          return {
            type: 'door',
            door: d,
            prompt: `[B] PLANT BREACH CHARGE · ${d.label} (LOCKED)`,
          };
        }
        return {
          type: 'door',
          door: d,
          prompt: d.isOpen
            ? `[F] CLOSE ${d.label}`
            : `[F] OPEN / BASH · [B] BREACH CHARGE`,
        };
      }
    }
    return null;
  }

  private updateInteractions(dt: number): void {
    // Handle ongoing Revive channel
    if (this.revivingAllyId) {
      const ally = this.allies.find((a) => a.id === this.revivingAllyId);
      const dist = ally
        ? Math.hypot(ally.position.x - this.playerPos.x, ally.position.z - this.playerPos.z)
        : 999;
      if (!ally || ally.state !== 'knocked' || dist > 3.9 || this.stance === 'tactical_sprint') {
        this.revivingAllyId = null;
        this.reviveTimer = 0;
      } else {
        this.reviveTimer -= dt;
        if (this.reviveTimer <= 0) {
          ally.state = 'alive';
          ally.hp = 65;
          ally.knockedTimerSec = 0;
          ally.root.rotation.x = 0;
          ally.root.position.y = 0;
          this.revivingAllyId = null;
          this.reviveTimer = 0;
          this.audio.playReviveComplete();
          this.pushRadioLine({
            id: `REVIVED_${ally.id}_${Date.now()}`,
            speaker: 'DAGGER',
            callsign: ally.callsign,
            text: 'Back in the fight! Thanks for the pickup, Lead!',
            durationSec: 3.0,
          });
          this.pushHudSnapshot();
        }
      }
    }

    const near = this.getNearbyInteractable();
    if (!near) return;

    if (near.type === 'revive' && near.ally && this.justPressed.has('KeyF')) {
      this.triggerReviveNearby();
      return;
    }

    if (near.type === 'aegis' && this.justPressed.has('KeyF')) {
      this.aegisExtracted = true;
      (this.aegisConsoleMesh.material as THREE.MeshStandardMaterial).emissive.setHex(0x22c55e);
      this.phaseIndex = 3;
      this.exfilBeaconLight.intensity = 16;
      this.audio.playRadioSquelch();
      this.triggerScriptZone('TRG_05_EXFIL');
      this.alertGroup('qrf');
      this.pushHudSnapshot();
      return;
    }

    if (near.type === 'loot' && near.crate && this.justPressed.has('KeyF')) {
      const c = near.crate;
      c.collected = true;
      this.scene.remove(c.mesh);
      this.medkitCount += c.contents.medkits;
      this.bandageCount += c.contents.bandages;
      this.grenadeCount += c.contents.grenades;
      const curWeapon = this.weapons[this.activeWeaponId];
      const spec = WEAPON_SPECS[this.activeWeaponId];
      this.weapons[this.activeWeaponId] = {
        ...curWeapon,
        reserveAmmo: Math.min(spec.reserveMax + 120, curWeapon.reserveAmmo + c.contents.ammo),
      };
      this.ammoRevealTimer = 2.5;
      this.audio.playLootPickup();
      this.pushHudSnapshot();
      return;
    }

    if (near.type === 'door' && near.door) {
      if (this.justPressed.has('KeyB')) {
        this.interactDoor(near.door, 'breach_charge');
      } else if (this.justPressed.has('KeyF') && !near.door.locked) {
        this.interactDoor(
          near.door,
          this.stance === 'tactical_sprint' ? 'bash' : 'silent_open',
        );
      }
    }
  }

  private interactDoor(door: DoorActor, mode: DoorInteractionMode): void {
    if (mode === 'breach_charge') {
      door.destroyed = true;
      door.doorMesh.visible = false;
      this.colliders[door.colliderIndex].maxY = 0;
      this.breachesCompleted += 1;
      this.trauma = Math.min(1, this.trauma + 0.65);
      this.hitstopTimer = 0.055;
      this.audio.playDoorBreach(true);
      this.spawnBurstParticles(door.position.clone().setY(1.2), 0xf97316, 24, 7.5);
      this.alertGroup('bunker');
      this.alertGroup('courtyard');
      this.stealthAlerted = true;
    } else if (mode === 'bash') {
      door.isOpen = true;
      door.targetOpenAngle = Math.PI * 0.56;
      this.colliders[door.colliderIndex].maxY = 0;
      this.breachesCompleted += 1;
      this.trauma = Math.min(1, this.trauma + 0.25);
      this.audio.playDoorBreach(false);
      this.alertGroup('courtyard');
    } else {
      door.isOpen = !door.isOpen;
      door.targetOpenAngle = door.isOpen ? Math.PI * 0.48 : 0;
      this.colliders[door.colliderIndex].maxY = door.isOpen ? 0 : 2.35;
      this.audio.playReloadClick(false);
    }
    this.pushHudSnapshot();
  }

  private updateDoors(dt: number): void {
    for (const d of this.doors) {
      if (d.destroyed) continue;
      d.currentOpenAngle = THREE.MathUtils.damp(
        d.currentOpenAngle,
        d.targetOpenAngle,
        9,
        dt,
      );
      d.pivot.rotation.y = d.baseYaw + d.currentOpenAngle;
    }
  }

  private alertGroup(group: string): void {
    for (const e of this.enemies) {
      if (e.alertGroup === group && e.alive) {
        e.alerted = true;
      }
    }
  }

  private updateAllies(dt: number): void {
    const isArena = this.gameMode === 'arena_4v4';
    for (let i = 0; i < this.allies.length; i++) {
      const a = this.allies[i];
      if (a.state === 'dead') {
        if (isArena) {
          a.respawnTimerSec -= dt;
          if (a.respawnTimerSec <= 0) {
            a.state = 'alive';
            a.hp = 100;
            a.position.copy(a.homePos);
            a.root.position.copy(a.position);
            a.root.rotation.set(0, Math.PI, 0);
            a.root.visible = true;
          }
        }
        continue;
      }

      if (a.state === 'knocked') {
        // Kneeling downed pose + "HELP!" bleedout countdown
        a.root.rotation.x = THREE.MathUtils.damp(a.root.rotation.x, -0.55, 8, dt);
        a.root.position.y = THREE.MathUtils.damp(a.root.position.y, -0.35, 8, dt);
        a.helpShoutCooldown -= dt;
        if (a.helpShoutCooldown <= 0) {
          a.helpShoutCooldown = 8.0;
          this.audio.playAllyHelpCallout();
        }
        // Pause bleedout while player is actively reviving
        if (this.revivingAllyId !== a.id) {
          const step = stepKnockoutBleedout(a.state, a.knockedTimerSec, dt);
          a.knockedTimerSec = step.bleedoutTimerSec;
          if (step.state === 'dead') {
            a.state = 'dead';
            a.root.rotation.x = -Math.PI / 2;
            a.root.position.y = 0;
            if (isArena) {
              this.arenaRedKills += 1;
              a.respawnTimerSec = 3.5;
            }
          }
        }
        continue;
      }

      // Alive ally: follow formation offset or engage visible enemies
      const prevX = a.position.x;
      const prevZ = a.position.z;
      if (a.hitFlashTimer > 0) {
        a.hitFlashTimer -= dt;
        (a.torsoMesh.material as THREE.MeshStandardMaterial).emissive.setHex(
          a.hitFlashTimer > 0 ? 0xffffff : 0x000000,
        );
      }

      // Find nearest alive alerted enemy (or any enemy in Arena 4v4)
      let targetEnemy: EnemyActor | null = null;
      let bestDist = 30;
      for (const e of this.enemies) {
        if (!e.alive) continue;
        if (!isArena && !e.alerted) continue;
        const d = a.position.distanceTo(e.position);
        if (d < bestDist) {
          bestDist = d;
          targetEnemy = e;
        }
      }

      const formOffsetX = i === 0 ? -3.2 : i === 1 ? 3.2 : -5.0;
      const formOffsetZ = i === 2 ? -1.5 : 2.2;
      const goalX = THREE.MathUtils.clamp(this.playerPos.x + formOffsetX, -26, 26);
      const goalZ = THREE.MathUtils.clamp(this.playerPos.z + formOffsetZ, -34, 42);
      const dxGoal = goalX - a.position.x;
      const dzGoal = goalZ - a.position.z;
      const distGoal = Math.hypot(dxGoal, dzGoal);

      if (distGoal > 2.2) {
        const step = dt * 2.45;
        const nx = a.position.x + (dxGoal / distGoal) * step;
        const nz = a.position.z + (dzGoal / distGoal) * step;
        if (!this.collidesAt(nx, a.position.z, 0.44)) a.position.x = nx;
        if (!this.collidesAt(a.position.x, nz, 0.44)) a.position.z = nz;
        a.root.position.copy(a.position);
      }

      if (targetEnemy) {
        const toE = _v1.subVectors(targetEnemy.position, a.position).setY(0);
        if (toE.lengthSq() > 0.01) {
          a.aimYaw = stepAngleRad(
            a.aimYaw,
            Math.atan2(toE.x, toE.z),
            ENEMY_SPEED_CONFIG.maxTurnRateRadPerSec,
            dt,
          );
          a.root.rotation.y = a.aimYaw;
        }
        a.fireCooldown -= dt;
        if (a.fireCooldown <= 0 && bestDist < 28) {
          a.fireCooldown = 0.85 + Math.random() * 0.55;
          const orig = _v2.copy(a.position).setY(1.35);
          const tgt = _v3.copy(targetEnemy.position).setY(1.25);
          this.spawnTracer(orig, tgt);
          this.audio.playSuppressedShot('5.56x45mm', false);
          if (Math.random() < 0.45) {
            this.damageEnemy(targetEnemy, 18, false, tgt);
          }
        }
      } else if (distGoal > 0.5) {
        a.aimYaw = stepAngleRad(
          a.aimYaw,
          Math.atan2(dxGoal, dzGoal),
          ENEMY_SPEED_CONFIG.maxTurnRateRadPerSec,
          dt,
        );
        a.root.rotation.y = a.aimYaw;
      }

      // Stride animation
      const moved = Math.hypot(a.position.x - prevX, a.position.z - prevZ);
      const spd = moved / Math.max(0.001, dt);
      if (spd > 0.15) {
        a.stridePhase += moved * 3.2;
        const sw = Math.sin(a.stridePhase) * 0.4;
        a.legL.rotation.x = sw;
        a.legR.rotation.x = -sw;
        a.armL.rotation.x = -0.65 + sw * 0.16;
        a.armR.rotation.x = -0.65 - sw * 0.16;
      } else {
        a.legL.rotation.x = THREE.MathUtils.damp(a.legL.rotation.x, 0, 12, dt);
        a.legR.rotation.x = THREE.MathUtils.damp(a.legR.rotation.x, 0, 12, dt);
      }
    }
  }

  private damageAlly(ally: AllyActor, dmg: number): void {
    if (ally.state !== 'alive') return;
    ally.hp -= dmg;
    ally.hitFlashTimer = 0.08;
    if (ally.hp <= 0) {
      ally.hp = 0;
      ally.state = 'knocked';
      ally.knockedTimerSec = KNOCKED_BLEEDOUT_SEC;
      ally.helpShoutCooldown = 6.0;
      this.audio.playAllyHelpCallout();
      this.pushRadioLine({
        id: `HELP_${ally.id}_${Date.now()}`,
        speaker: 'DAGGER',
        callsign: ally.callsign,
        text: 'HELP! I am downed—get over here and revive me!',
        durationSec: 4.2,
      });
      this.pushHudSnapshot();
    }
  }

  private updateEnemies(dt: number): void {
    const isArena = this.gameMode === 'arena_4v4';
    let activeAttackers = 0;
    for (const e of this.enemies) {
      if (e.alive && e.alerted && (e.windupTimer > 0 || e.burstRemaining > 0)) {
        activeAttackers += 1;
      }
    }

    for (let idx = 0; idx < this.enemies.length; idx++) {
      const e = this.enemies[idx];
      if (!e.alive) {
        if (isArena && idx < 4) {
          e.respawnTimerSec -= dt;
          if (e.respawnTimerSec <= 0) {
            e.alive = true;
            e.hp = e.maxHp;
            e.position.copy(e.homePos);
            e.root.position.copy(e.position);
            e.root.rotation.set(0, 0, 0);
            e.alerted = true;
          }
        } else if (e.koTimer > 0) {
          e.koTimer = Math.max(0, e.koTimer - dt);
          e.root.rotation.x = THREE.MathUtils.damp(e.root.rotation.x, -Math.PI / 2, 12, dt);
        }
        continue;
      }

      // Hit flash decay
      if (e.hitFlashTimer > 0) {
        e.hitFlashTimer -= dt;
        (e.torsoMesh.material as THREE.MeshStandardMaterial).emissive.setHex(
          e.hitFlashTimer > 0 ? 0xffffff : 0x000000,
        );
      }

      const prevX = e.position.x;
      const prevZ = e.position.z;
      const distToPlayer = e.position.distanceTo(this.playerPos);

      // Detection Check
      if (!e.alerted) {
        const detectRange = this.transformerAlive && this.phaseIndex === 0 ? 15 : 10;
        const stanceStealthMod =
          this.stance === 'prone' ? 0.55 : this.stance === 'crouched' ? 0.78 : 1.0;
        if (distToPlayer < detectRange * stanceStealthMod && this.hasLineOfSight(e)) {
          e.alerted = true;
          this.stealthAlerted = true;
        } else if (e.patrolPos) {
          // Calm Patrol at natural human pace (1.15 m/s)
          const target = e.patrolDir > 0 ? e.patrolPos : e.homePos;
          _v1.subVectors(target, e.position).setY(0);
          if (_v1.length() < 0.45) {
            e.patrolDir *= -1;
          } else {
            _v1.normalize();
            const nx = e.position.x + _v1.x * dt * ENEMY_SPEED_CONFIG.patrolMps;
            const nz = e.position.z + _v1.z * dt * ENEMY_SPEED_CONFIG.patrolMps;
            if (!this.collidesAt(nx, nz, 0.45)) {
              e.position.set(nx, e.position.y, nz);
            } else {
              e.patrolDir *= -1;
            }
            e.root.position.copy(e.position);
            e.aimYaw = stepAngleRad(
              e.aimYaw,
              Math.atan2(_v1.x, _v1.z),
              ENEMY_SPEED_CONFIG.maxTurnRateRadPerSec,
              dt,
            );
            e.root.rotation.y = e.aimYaw;
            this.animateEnemyStride(e, prevX, prevZ, dt);
          }
          continue;
        } else {
          this.animateEnemyStride(e, prevX, prevZ, dt);
          continue;
        }
      }

      // Smoothly turn to face player
      _v1.subVectors(this.playerPos, e.position).setY(0);
      const flatDist = _v1.length();
      if (flatDist > 0.05) {
        _v1.normalize();
        const desiredYaw = Math.atan2(_v1.x, _v1.z);
        e.aimYaw = stepAngleRad(
          e.aimYaw,
          desiredYaw,
          ENEMY_SPEED_CONFIG.maxTurnRateRadPerSec,
          dt,
        );
        e.root.rotation.y = e.aimYaw;
      }

      // Distinct Tactical Movement Policies by Archetype (Normal Grounded Speeds, Axis-Separated Collision)
      const los = this.hasLineOfSight(e);
      if (e.archetype === 'breacher') {
        // Policy 1: Tactical Shotgun Breacher closing to 6.5m + Flashbang
        if (flatDist > 6.5) {
          const step = dt * ENEMY_SPEED_CONFIG.breacherRushMps;
          const nx = e.position.x + _v1.x * step;
          const nz = e.position.z + _v1.z * step;
          if (!this.collidesAt(nx, e.position.z, 0.48)) e.position.x = nx;
          if (!this.collidesAt(e.position.x, nz, 0.48)) e.position.z = nz;
          e.root.position.copy(e.position);
        }
        e.flashbangCooldown -= dt;
        if (los && flatDist < 12 && flatDist > 5 && e.flashbangCooldown <= 0) {
          e.flashbangCooldown = 14;
          this.flashbangStunTimer = 1.6;
          this.audio.triggerFlashbangMuffle();
          this.trauma = Math.min(1, this.trauma + 0.45);
        }
      } else if (e.archetype === 'sniper') {
        // Policy 2: Stationary Elevated Marksman with IR Laser Telegraph
        if (e.laserLine) e.laserLine.visible = true;
      } else {
        // Policy 3: Tactical Infantry / Officer Coordinated Advance & Cooldown-Damped Flanking
        e.strafeTimer -= dt;
        if (flatDist > 16) {
          const step = dt * ENEMY_SPEED_CONFIG.tacticalAdvanceMps;
          const nx = e.position.x + _v1.x * step;
          const nz = e.position.z + _v1.z * step;
          if (!this.collidesAt(nx, e.position.z, 0.48)) e.position.x = nx;
          if (!this.collidesAt(e.position.x, nz, 0.48)) e.position.z = nz;
        } else if (flatDist > 7.5 && los) {
          _v2.set(-_v1.z * e.strafeSign, 0, _v1.x * e.strafeSign);
          const step = dt * ENEMY_SPEED_CONFIG.tacticalFlankMps;
          const nextX = e.position.x + _v2.x * step;
          const nextZ = e.position.z + _v2.z * step;
          if (!this.collidesAt(nextX, nextZ, 0.55)) {
            e.position.set(nextX, e.position.y, nextZ);
          } else if (e.strafeTimer <= 0) {
            e.strafeSign *= -1;
            e.strafeTimer = 1.4;
          }
        }
        e.root.position.copy(e.position);
      }

      // Animate legs & arms smoothly based on actual distance traveled
      this.animateEnemyStride(e, prevX, prevZ, dt);

      // Tactical Enemy Grenade Toss (Infantry / Officer pressure player behind cover)
      if (e.archetype === 'infantry' || e.archetype === 'officer') {
        e.grenadeCooldown -= dt;
        if (
          e.grenadeCooldown <= 0 &&
          flatDist > 8 &&
          flatDist < 22 &&
          this.activeGrenades.length < 2
        ) {
          e.grenadeCooldown = 14 + Math.random() * 6;
          const startPos = e.position.clone().setY(1.55);
          const toPlayer = _v3.subVectors(this.playerPos, e.position);
          const dist = Math.max(4, toPlayer.length());
          const flightT = THREE.MathUtils.clamp(dist / 12, 0.75, 1.5);
          const throwVel = new THREE.Vector3(
            toPlayer.x / flightT,
            0.5 * 15.5 * flightT - 1.2 / flightT,
            toPlayer.z / flightT,
          );
          this.spawnActiveGrenade(startPos, throwVel, false, 2.65);
        }
      }

      // Attack Token Pool + Telegraph Windup + Multi-Round Tactical Bursts
      if (e.burstRemaining > 0) {
        e.burstShotTimer -= dt;
        if (e.burstShotTimer <= 0) {
          this.fireEnemyWeapon(e, distToPlayer);
          e.burstRemaining -= 1;
          e.burstShotTimer = 0.13;
          if (e.burstRemaining <= 0) {
            e.attackCooldown = e.archetype === 'sniper' ? 2.8 : 1.7 + Math.random() * 0.8;
          }
        }
      } else {
        e.attackCooldown -= dt;
        if (los && distToPlayer < 40 && e.attackCooldown <= 0) {
          if (e.windupTimer <= 0 && activeAttackers < 3) {
            e.windupTimer = e.archetype === 'sniper' ? 0.72 : 0.42;
            activeAttackers += 1;
          }
        }

        if (e.windupTimer > 0) {
          e.windupTimer -= dt;
          if (e.windupTimer <= 0) {
            e.burstRemaining = e.archetype === 'sniper' ? 1 : e.archetype === 'breacher' ? 2 : 3;
            e.burstShotTimer = 0;
          }
        }
      }
    }
  }

  private animateEnemyStride(
    e: EnemyActor,
    prevX: number,
    prevZ: number,
    dt: number,
  ): void {
    const moved = Math.hypot(e.position.x - prevX, e.position.z - prevZ);
    const speed = moved / Math.max(0.001, dt);
    if (speed > 0.15) {
      e.stridePhase += moved * 3.2;
      const swing = Math.sin(e.stridePhase) * 0.42;
      e.legL.rotation.x = swing;
      e.legR.rotation.x = -swing;
      e.armL.rotation.x = -0.65 + swing * 0.18;
      e.armR.rotation.x = -0.65 - swing * 0.18;
    } else {
      e.legL.rotation.x = THREE.MathUtils.damp(e.legL.rotation.x, 0, 12, dt);
      e.legR.rotation.x = THREE.MathUtils.damp(e.legR.rotation.x, 0, 12, dt);
      e.armL.rotation.x = THREE.MathUtils.damp(e.armL.rotation.x, -0.65, 12, dt);
      e.armR.rotation.x = THREE.MathUtils.damp(e.armR.rotation.x, -0.65, 12, dt);
    }
  }

  private hasLineOfSight(e: EnemyActor): boolean {
    _v1.copy(e.position).setY(e.position.y + 1.45);
    _v2.copy(this.camera.position).sub(_v1);
    const dist = _v2.length();
    if (dist < 0.5) return true;
    _v2.normalize();
    this.raycaster.set(_v1, _v2);
    this.raycaster.far = dist - 0.35;
    const hits = this.raycaster.intersectObjects(this.raycastMeshes, false);
    for (const h of hits) {
      if (!h.object.userData.enemyId) return false;
    }
    return true;
  }

  private fireEnemyWeapon(e: EnemyActor, distM: number): void {
    const heavy = e.archetype === 'breacher' || e.archetype === 'sniper';
    this.audio.playEnemyGunshot(distM, heavy);
    if (e.archetype === 'sniper') {
      this.audio.playSupersonicCrack();
    }

    const origin = _v1.copy(e.position).setY(e.position.y + 1.35);
    // Enemy fires at player OR nearest alive squadmate (so allies get knocked and ask for "HELP!")
    let closestAlly: AllyActor | null = null;
    let closestAllyDist = distM;
    for (const a of this.allies) {
      if (a.state !== 'alive') continue;
      const ad = e.position.distanceTo(a.position);
      if (ad < closestAllyDist) {
        closestAllyDist = ad;
        closestAlly = a;
      }
    }

    if (closestAlly && Math.random() < 0.55) {
      const targetPos = _v2.copy(closestAlly.position).setY(1.25);
      this.spawnTracer(origin, targetPos);
      if (Math.random() < 0.65) {
        const dmg = e.archetype === 'sniper' ? 35 : e.archetype === 'breacher' ? 28 : 19;
        this.damageAlly(closestAlly, dmg);
      }
      return;
    }

    const target = _v2.copy(this.camera.position);
    target.x += (Math.random() - 0.5) * 0.8;
    target.y += (Math.random() - 0.5) * 0.6;
    this.spawnTracer(origin, target);

    // Hit probability scales inversely with distance and stance profile
    const stanceProfile = this.stance === 'prone' ? 0.55 : this.stance === 'crouched' ? 0.78 : 1.0;
    const hitChance =
      (e.archetype === 'sniper' ? 0.72 : 0.52) *
      stanceProfile *
      Math.max(0.25, 1 - distM / 55);

    if (Math.random() < hitChance) {
      const dmg = e.archetype === 'sniper' ? 32 : e.archetype === 'breacher' ? 22 : 12;
      this.applyPlayerDamage(dmg, e.position);
    }
  }

  private applyPlayerDamage(dmg: number, sourcePos: THREE.Vector3): void {
    if (this.gameMode === 'duel_1v1') return;
    if (this.hp <= 0 || this.gameState !== 'playing' || this.playerRespawnInvulnSec > 0) return;
    this.hp = Math.max(0, this.hp - dmg);
    this.regenDelayTimer = 4.2;
    this.damageFlashAlpha = 0.85;
    this.trauma = Math.min(1, this.trauma + 0.42);

    // Relative bearing of attacker for directional damage arc
    const dx = sourcePos.x - this.playerPos.x;
    const dz = sourcePos.z - this.playerPos.z;
    const worldAngle = Math.atan2(dx, -dz);
    this.damageDirRad = worldAngle + this.yawRad;

    if (this.hp <= 0) {
      if (this.gameMode === 'arena_4v4') {
        this.arenaRedKills += 1;
        const arenaRes = computeArenaMatchOutcome(
          this.arenaBlueKills,
          this.arenaRedKills,
          this.selectedTargetKills,
          this.arenaTimeRemainingSec,
        );
        if (arenaRes !== 'ongoing') {
          this.finishMission(arenaRes);
        } else {
          // Respawn operator in Arena 4v4 TDM
          this.hp = 100;
          this.playerPos.set(0, 0, 24);
          this.playerVel.set(0, 0, 0);
          this.yawRad = 0;
          this.playerRespawnInvulnSec = 2.5;
          this.pushHudSnapshot();
        }
      } else {
        this.finishMission('defeat');
      }
    } else {
      this.pushHudSnapshot();
    }
  }

  private updateTriggersAndObjectives(dt: number): void {
    if (this.gameMode === 'duel_1v1') {
      return;
    }
    if (this.gameMode === 'arena_4v4') {
      this.arenaTimeRemainingSec = Math.max(0, this.arenaTimeRemainingSec - dt);
      const outcome = computeArenaMatchOutcome(
        this.arenaBlueKills,
        this.arenaRedKills,
        this.selectedTargetKills,
        this.arenaTimeRemainingSec,
      );
      if (outcome !== 'ongoing') {
        this.finishMission(outcome);
      }
      return;
    }

    for (const trg of MISSION_1_TRIGGERS) {
      if (this.triggersFired.has(trg.id)) continue;
      const dist = Math.hypot(
        this.playerPos.x - trg.position[0],
        this.playerPos.z - trg.position[2],
      );
      if (dist <= trg.radiusM) {
        this.triggerScriptZone(trg.id);
      }
    }

    // Advance Mission Phase naturally
    if (this.phaseIndex === 0 && this.playerPos.z < 12) {
      this.phaseIndex = 1;
    }
    if (this.phaseIndex === 1 && this.playerPos.z < -17.5 && Math.abs(this.playerPos.x) < 8) {
      this.phaseIndex = 2;
    }
    // Exfil Victory Check
    if (
      this.aegisExtracted &&
      Math.hypot(this.playerPos.x - 22, this.playerPos.z + 30) < 4.5
    ) {
      this.finishMission('victory');
    }
  }

  private triggerScriptZone(id: string): void {
    if (this.triggersFired.has(id)) return;
    this.triggersFired.add(id);
    const trg = MISSION_1_TRIGGERS.find((t) => t.id === id);
    if (!trg) return;
    for (const line of trg.commsSequence) {
      this.pushRadioLine(line);
    }
  }

  private pushRadioLine(line: RadioCommsLine): void {
    this.commsQueue.push(line);
    if (!this.activeComms) {
      this.advanceCommsQueue();
    }
  }

  private advanceCommsQueue(): void {
    const next = this.commsQueue.shift() || null;
    this.activeComms = next;
    this.commsTimer = next ? next.durationSec : 0;
    if (next) {
      this.audio.playRadioSquelch();
    }
    this.pushHudSnapshot();
  }

  private updateComms(dt: number): void {
    if (!this.activeComms) return;
    this.commsTimer -= dt;
    if (this.commsTimer <= 0) {
      this.advanceCommsQueue();
    }
  }

  private finishMission(outcome: 'victory' | 'defeat' | 'draw'): void {
    this.outcome = outcome;
    this.gameState = 'gameover';
    document.body.dataset.state = 'gameover';
    this.clearHeldInputs();
    document.exitPointerLock?.();
    this.pushHudSnapshot();
  }

  private applyNvgVisualState(active: boolean): void {
    if (active) {
      this.renderer.toneMappingExposure = 1.95;
      this.scene.background = new THREE.Color(0x061b12);
      this.fog.color.setHex(0x061b12);
      this.fog.density = 0.011;
      this.hemiLight.intensity = 1.35;
      this.nvgLight.intensity = 16;
    } else {
      this.renderer.toneMappingExposure = 1.15;
      this.scene.background = new THREE.Color(0x070c13);
      this.fog.color.setHex(0x070c13);
      this.fog.density = 0.017;
      this.hemiLight.intensity = 0.68;
      this.nvgLight.intensity = 0;
    }
  }

  private updateAmbientWorldProps(dt: number): void {
    if (this.radarDishPivot) {
      this.radarDishPivot.rotation.y += dt * 0.65;
    }
    if (this.beaconMesh) {
      const pulse = Math.sin(performance.now() * 0.005) > 0.2;
      (this.beaconMesh.material as THREE.MeshBasicMaterial).color.setHex(
        pulse ? 0xff2d20 : 0x450a0a,
      );
    }
    this.searchlightPivot.rotation.y = Math.sin(performance.now() * 0.0007) * 0.65;
    if (this.aegisExtracted) {
      this.exfilRingMesh.rotation.z += dt * 1.4;
      this.exfilBeaconLight.intensity = 10 + Math.sin(performance.now() * 0.012) * 8;
    }
  }

  private updateRain(dt: number): void {
    const cx = this.camera.position.x;
    const cz = this.camera.position.z;
    for (let i = 0; i < this.RAIN_COUNT; i++) {
      const idx = i * 3;
      this.rainPositions[idx + 1] -= dt * 19;
      if (this.rainPositions[idx + 1] < 0) {
        this.rainPositions[idx] = cx + (Math.random() - 0.5) * 32;
        this.rainPositions[idx + 1] = 11 + Math.random() * 4;
        this.rainPositions[idx + 2] = cz + (Math.random() - 0.5) * 32;
      }
      _v1.set(
        this.rainPositions[idx],
        this.rainPositions[idx + 1],
        this.rainPositions[idx + 2],
      );
      _quat.identity();
      _scale.set(1, 1, 1);
      _mat4.compose(_v1, _quat, _scale);
      this.rainMesh.setMatrixAt(i, _mat4);
    }
    this.rainMesh.instanceMatrix.needsUpdate = true;
  }

  private updateParticlesAndTracers(dt: number): void {
    let anyParticle = false;
    for (let i = 0; i < this.PARTICLE_CAP; i++) {
      const p = this.particles[i];
      if (!p.active) continue;
      anyParticle = true;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        _v1.set(0, -50, 0);
        _scale.set(0, 0, 0);
      } else {
        p.vel.y -= 12 * dt;
        p.pos.addScaledVector(p.vel, dt);
        const s = p.scale * (p.life / p.maxLife);
        _v1.copy(p.pos);
        _scale.set(s, s, s);
      }
      _quat.identity();
      _mat4.compose(_v1, _quat, _scale);
      this.particleMesh.setMatrixAt(i, _mat4);
      this.particleMesh.setColorAt(i, p.color);
    }
    if (anyParticle) {
      this.particleMesh.instanceMatrix.needsUpdate = true;
      if (this.particleMesh.instanceColor) {
        this.particleMesh.instanceColor.needsUpdate = true;
      }
    }

    for (let i = this.tracers.length - 1; i >= 0; i--) {
      const t = this.tracers[i];
      t.life -= dt;
      if (t.life <= 0) {
        this.scene.remove(t.mesh);
        t.mesh.geometry.dispose();
        (t.mesh.material as THREE.Material).dispose();
        this.tracers.splice(i, 1);
      }
    }
  }

  private pushHudSnapshot(): void {
    const wState = this.weapons[this.activeWeaponId];
    const spec = WEAPON_SPECS[this.activeWeaponId];
    const obj = MISSION_1_OBJECTIVES[this.phaseIndex] || MISSION_1_OBJECTIVES[0];

    const dx = obj.targetPosition[0] - this.playerPos.x;
    const dz = obj.targetPosition[2] - this.playerPos.z;
    const objectiveDistanceM = Math.round(Math.hypot(dx, dz));
    const objWorldDeg = (THREE.MathUtils.radToDeg(Math.atan2(dx, -dz)) + 360) % 360;
    const headingDeg = (THREE.MathUtils.radToDeg(-this.yawRad) + 360) % 360;
    const near = this.getNearbyInteractable();

    const nearCrate = this.getNearbyLootCrate();
    const nearbyLoot: NearbyLootHud | null = nearCrate
      ? {
          crateId: nearCrate.id,
          distanceM: Math.round(
            Math.hypot(
              nearCrate.position.x - this.playerPos.x,
              nearCrate.position.z - this.playerPos.z,
            ),
          ),
          contents: { ...nearCrate.contents },
        }
      : null;

    // Nearest dangerous grenade alert
    let incomingGrenade: IncomingGrenadeAlert | null = null;
    let closestGDist = 11.5;
    for (const g of this.activeGrenades) {
      const gd = g.pos.distanceTo(this.playerPos);
      if (gd < closestGDist) {
        closestGDist = gd;
        const gdx = g.pos.x - this.playerPos.x;
        const gdz = g.pos.z - this.playerPos.z;
        incomingGrenade = {
          distanceM: Math.round(gd * 10) / 10,
          bearingRad: Math.atan2(gdx, -gdz) + this.yawRad,
          fuseRemainingSec: Math.max(0, Math.round(g.fuseTimer * 10) / 10),
        };
      }
    }

    // Minimap blips (rotated into player-heading-up coordinates in HUD)
    const minimapBlips: MinimapBlip[] = [];
    if (this.gameMode === 'classic') {
      minimapBlips.push({ x: dx, z: dz, kind: 'objective' });
    }
    for (const a of this.allies) {
      if (a.state === 'dead') continue;
      const ax = a.position.x - this.playerPos.x;
      const az = a.position.z - this.playerPos.z;
      if (Math.hypot(ax, az) < 42) {
        minimapBlips.push({
          x: ax,
          z: az,
          kind: a.state === 'knocked' ? 'ally_knocked' : 'ally',
        });
      }
    }
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const ex = e.position.x - this.playerPos.x;
      const ez = e.position.z - this.playerPos.z;
      if (Math.hypot(ex, ez) < 40 && (e.alerted || Math.hypot(ex, ez) < 22)) {
        minimapBlips.push({ x: ex, z: ez, kind: 'enemy' });
      }
    }
    if (this.gameMode === 'duel_1v1' && this.remoteOpponent.root.visible) {
      const rx = this.remoteOpponent.pos.x - this.playerPos.x;
      const rz = this.remoteOpponent.pos.z - this.playerPos.z;
      const rDist = Math.hypot(rx, rz);
      if (rDist < 42 && (this.remoteShotAlertTimer > 0 || rDist < 18)) {
        minimapBlips.push({ x: rx, z: rz, kind: 'enemy' });
      }
    }
    let activeDropCount = 0;
    let nearestDropDistanceM: number | null = null;
    for (const c of this.lootCrates) {
      if (c.collected) continue;
      const cx = c.position.x - this.playerPos.x;
      const cz = c.position.z - this.playerPos.z;
      const distC = Math.hypot(cx, cz);
      if (c.isAirdrop) {
        activeDropCount += 1;
        if (nearestDropDistanceM === null || distC < nearestDropDistanceM) {
          nearestDropDistanceM = Math.round(distC);
        }
      }
      if (distC < 44) {
        minimapBlips.push({ x: cx, z: cz, kind: c.isAirdrop ? 'airdrop' : 'loot' });
      }
    }
    for (const g of this.activeGrenades) {
      const gx = g.pos.x - this.playerPos.x;
      const gz = g.pos.z - this.playerPos.z;
      if (Math.hypot(gx, gz) < 40) {
        minimapBlips.push({ x: gx, z: gz, kind: 'grenade' });
      }
    }

    const teammates: TeammateStatus[] =
      this.gameMode === 'duel_1v1'
        ? []
        : this.allies.map((a) => ({
            id: a.id,
            callsign: a.callsign,
            hp: Math.round(a.hp),
            maxHp: a.maxHp,
            state: a.state,
            knockedTimerSec: Math.round(a.knockedTimerSec),
            distanceM: Math.round(
              Math.hypot(a.position.x - this.playerPos.x, a.position.z - this.playerPos.z),
            ),
          }));

    const knockedAlly = this.getNearbyKnockedAlly();
    const nearbyKnockedAlly: RevivePromptHud | null = knockedAlly
      ? {
          allyId: knockedAlly.id,
          callsign: knockedAlly.callsign,
          isReviving: this.revivingAllyId === knockedAlly.id,
          progress:
            this.revivingAllyId === knockedAlly.id
              ? Math.max(0, Math.min(1, 1 - this.reviveTimer / REVIVE_CHANNEL_SEC))
              : 0,
          bleedoutSec: Math.round(knockedAlly.knockedTimerSec),
        }
      : null;

    const airdropStatus: AirdropStatusHud = {
      nextDropInSec: Math.ceil(this.airdropCooldownSec),
      activeDropCount,
      nearestDropDistanceM,
      justDroppedBannerSec: this.airdropJustDroppedBannerSec,
    };

    const arenaScore: ArenaScoreHud | null =
      this.gameMode === 'arena_4v4'
        ? {
            blueKills: this.arenaBlueKills,
            redKills: this.arenaRedKills,
            targetKills: this.selectedTargetKills,
            timeRemainingSec: Math.ceil(this.arenaTimeRemainingSec),
          }
        : null;

    let duelScore: DuelScoreHud | null = null;
    if (this.gameMode === 'duel_1v1') {
      const mySlot = this.duelRoom?.mySlot ?? 1;
      const me = this.duelRoom?.players.find((p) => p.slot === mySlot);
      const opp = this.duelRoom?.players.find((p) => p.slot !== mySlot);
      duelScore = {
        roomCode: this.duelRoom?.code ?? '----',
        myName: me?.name ?? 'YOU',
        opponentName: opp?.name ?? "DO'ST",
        myKills: me?.kills ?? this.kills,
        opponentKills: opp?.kills ?? 0,
        targetKills: this.duelRoom?.targetKills ?? this.selectedTargetKills,
        timeRemainingSec: Math.ceil(this.arenaTimeRemainingSec),
        opponentConnected: Boolean(opp?.connected),
      };
    }

    const healProgress =
      this.isHealing && this.healDuration > 0
        ? Math.max(0, Math.min(1, 1 - this.healTimer / this.healDuration))
        : 0;

    const mk18Res = this.weapons.mk18_suppressed.reserveAmmo;
    const p226Res = this.weapons.p226_suppressed.reserveAmmo;

    this.onHudUpdate({
      gameState: this.gameState,
      gameMode: this.gameMode,
      cameraPerspective: this.cameraPerspective,
      outcome: this.outcome,
      hp: Math.round(this.hp),
      maxHp: this.maxHp,
      stance: this.stance,
      isMounted: this.isMounted,
      canMount: this.canMount,
      isAds: this.isAds,
      nvgActive: this.nvgActive,
      nvgBattery: Math.round(this.nvgBattery),
      weaponId: this.activeWeaponId,
      weaponName: spec.name,
      magAmmo: wState.magAmmo,
      chambered: wState.chambered,
      reserveAmmo: wState.reserveAmmo,
      mk18ReserveAmmo: mk18Res,
      p226ReserveAmmo: p226Res,
      isReloading: wState.isReloading,
      ammoRevealTimer: this.ammoRevealTimer,
      grenadeCount: this.grenadeCount,
      medkitCount: this.medkitCount,
      bandageCount: this.bandageCount,
      bagWeightKg: computeBagWeightKg(
        this.medkitCount,
        this.bandageCount,
        this.grenadeCount,
        mk18Res + p226Res,
      ),
      bagMaxKg: 35,
      isHealing: this.isHealing,
      healKind: this.healKind,
      healProgress,
      nearbyLoot,
      incomingGrenade,
      teammates,
      nearbyKnockedAlly,
      airdropStatus,
      arenaScore,
      duelScore,
      respawnCountdownSec: Math.ceil(this.duelRespawnSec),
      minimapBlips,
      headingDeg: Math.round(headingDeg),
      objectiveLabel:
        this.gameMode === 'duel_1v1'
          ? `1v1 DUEL · MARRA ${duelScore?.targetKills ?? this.selectedTargetKills}`
          : this.gameMode === 'arena_4v4'
            ? 'ARENA 4V4 TEAM DEATHMATCH'
            : obj.title,
      objectiveDistanceM,
      objectiveBearingDeg: Math.round(objWorldDeg),
      phaseIndex: this.phaseIndex,
      totalPhases: MISSION_1_OBJECTIVES.length,
      activeComms: this.activeComms,
      interactPrompt: near ? near.prompt : null,
      damageFlashAlpha: this.damageFlashAlpha,
      damageDirRad: this.damageDirRad,
      hitMarkerTimer: this.hitMarkerTimer,
      hitMarkerHeadshot: this.hitMarkerHeadshot,
      flashbangStunTimer: this.flashbangStunTimer,
      pointerLocked: this.pointerLocked,
      isMuted: this.audio.isMuted(),
      elapsedSec: this.elapsedSec,
      kills: this.kills,
      headshots: this.headshots,
      shotsFired: this.shotsFired,
      shotsHit: this.shotsHit,
      stealthAlerted: this.stealthAlerted,
      breachesCompleted: this.breachesCompleted,
    });
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onWindowBlur);
    document.removeEventListener('visibilitychange', this.onWindowBlur);
    document.removeEventListener('pointerlockchange', this.onPointerLockChange);
    window.removeEventListener('mouseup', this.onMouseUp);
    window.removeEventListener('mousemove', this.onMouseMove);

    this.audio.dispose();
    this.scene.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const m = obj as THREE.Mesh;
        m.geometry?.dispose();
        if (Array.isArray(m.material)) m.material.forEach((mt) => mt.dispose());
        else m.material?.dispose();
      }
    });
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
