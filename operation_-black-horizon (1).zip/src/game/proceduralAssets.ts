import * as THREE from 'three';
import type { EnemyArchetype, WeaponId } from './types';

function createCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

export function createWetAsphaltTextures(maxAnisotropy: number): {
  map: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
} {
  const [albedoC, aCtx] = createCanvas(256, 256);
  aCtx.fillStyle = '#181c21';
  aCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 4200; i++) {
    const x = (i * 73 + Math.floor(i / 256) * 19) % 256;
    const y = (i * 137) % 256;
    const shade = 18 + ((i * 7) % 18);
    aCtx.fillStyle = `rgb(${shade},${shade + 3},${shade + 6})`;
    aCtx.fillRect(x, y, 2, 2);
  }
  aCtx.fillStyle = 'rgba(8, 11, 15, 0.28)';
  aCtx.fillRect(44, 0, 24, 256);
  aCtx.fillRect(184, 0, 24, 256);

  const map = new THREE.CanvasTexture(albedoC);
  map.colorSpace = THREE.SRGBColorSpace;
  map.wrapS = map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(14, 14);
  map.anisotropy = maxAnisotropy;

  const [roughC, rCtx] = createCanvas(256, 256);
  rCtx.fillStyle = '#8e8e8e';
  rCtx.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 4) {
    for (let x = 0; x < 256; x += 4) {
      const n =
        Math.sin((x / 256) * Math.PI * 4) * Math.cos((y / 256) * Math.PI * 2) +
        0.5 * Math.sin(((x + y) / 256) * Math.PI * 6);
      const val = Math.max(48, Math.min(185, Math.round(125 + n * 42)));
      rCtx.fillStyle = `rgb(${val},${val},${val})`;
      rCtx.fillRect(x, y, 4, 4);
    }
  }

  const roughnessMap = new THREE.CanvasTexture(roughC);
  roughnessMap.wrapS = roughnessMap.wrapT = THREE.RepeatWrapping;
  roughnessMap.repeat.set(8, 8);
  roughnessMap.anisotropy = maxAnisotropy;

  return { map, roughnessMap };
}

export function createConcreteTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = createCanvas(256, 256);
  ctx.fillStyle = '#737980';
  ctx.fillRect(0, 0, 256, 256);
  ctx.strokeStyle = '#535961';
  ctx.lineWidth = 2;
  for (let y = 0; y < 256; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(256, y);
    ctx.stroke();
  }
  for (let i = 0; i < 2400; i++) {
    const x = (i * 59) % 256;
    const y = (i * 113) % 256;
    const v = 95 + (i % 34);
    ctx.fillStyle = `rgb(${v},${v + 2},${v + 4})`;
    ctx.fillRect(x, y, 2, 2);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createWoodCrateTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const [c, ctx] = createCanvas(128, 128);
  ctx.fillStyle = '#9c7c54';
  ctx.fillRect(0, 0, 128, 128);
  ctx.strokeStyle = '#6f5333';
  ctx.lineWidth = 6;
  ctx.strokeRect(4, 4, 120, 120);
  ctx.beginPath();
  ctx.moveTo(6, 6);
  ctx.lineTo(122, 122);
  ctx.stroke();
  for (let y = 16; y < 120; y += 22) {
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(6, y);
    ctx.lineTo(122, y);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createBarracksNumberTexture(num: string): THREE.CanvasTexture {
  const [c, ctx] = createCanvas(128, 128);
  ctx.fillStyle = '#bfc5cc';
  ctx.fillRect(0, 0, 128, 128);
  ctx.fillStyle = '#24292f';
  ctx.font = 'bold 76px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(num, 64, 68);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Digital ACU Camouflage texture matching reference soldier uniform (i_c3d8d8ab.webp)
 */
export function createDigitalCamoTexture(): THREE.CanvasTexture {
  const [c, ctx] = createCanvas(128, 128);
  ctx.fillStyle = '#696e68';
  ctx.fillRect(0, 0, 128, 128);
  const palette = ['#484d47', '#898e84', '#5b6156', '#333834', '#9aa094'];
  for (let i = 0; i < 420; i++) {
    const px = ((i * 37) % 32) * 4;
    const py = ((i * 61) % 32) * 4;
    const w = 4 + (i % 3) * 4;
    const h = 4 + ((i + 1) % 2) * 4;
    ctx.fillStyle = palette[i % palette.length];
    ctx.fillRect(px, py, w, h);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  return tex;
}

/**
 * Faceted cobalt-blue / violet / obsidian crystalline finish matching reference pistol (91d91935ef514fc790d148807d477741_dfff079f.jpg)
 */
export function createCrystalPistolTexture(): THREE.CanvasTexture {
  const [c, ctx] = createCanvas(256, 128);
  ctx.fillStyle = '#14151b';
  ctx.fillRect(0, 0, 256, 128);
  const shards = [
    { pts: [[0, 20], [72, 0], [110, 64], [30, 88]], color: '#1d4ed8' },
    { pts: [[68, 4], [154, 18], [130, 92], [80, 62]], color: '#4338ca' },
    { pts: [[148, 8], [238, 0], [210, 74], [128, 56]], color: '#7e22ce' },
    { pts: [[18, 72], [116, 54], [94, 128], [0, 120]], color: '#2563eb' },
    { pts: [[110, 68], [210, 52], [250, 124], [140, 128]], color: '#6d28d9' },
  ];
  for (const s of shards) {
    ctx.fillStyle = s.color;
    ctx.globalAlpha = 0.72;
    ctx.beginPath();
    ctx.moveTo(s.pts[0][0], s.pts[0][1]);
    for (let i = 1; i < s.pts.length; i++) ctx.lineTo(s.pts[i][0], s.pts[i][1]);
    ctx.closePath();
    ctx.fill();
  }
  // Sharp pink/magenta crystal highlight streaks
  ctx.globalAlpha = 0.9;
  ctx.strokeStyle = '#d946ef';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(24, 34);
  ctx.lineTo(95, 58);
  ctx.lineTo(175, 22);
  ctx.lineTo(242, 74);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createRadialContactShadowTexture(): THREE.CanvasTexture {
  const [c, ctx] = createCanvas(128, 128);
  const grad = ctx.createRadialGradient(64, 64, 8, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0,0,0,0.68)');
  grad.addColorStop(0.55, 'rgba(0,0,0,0.3)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Detailed First-Person Weapon Models matching user references:
 * - mk18_suppressed: Quad-rail M4/MK18 with ELCAN/ACOG + piggyback red dot, FDE skeletal stock, curved PMAG, angled foregrip + taclight, suppressor (png-transparent-firearm...)
 * - p226_suppressed: Crystal blue-violet suppressed USP-S / P226 tactical pistol (91d91935ef514fc790d148807d477741_dfff079f.jpg)
 */
export function buildPlayerWeaponGroup(weaponId: WeaponId): {
  group: THREE.Group;
  muzzleFlash: THREE.Mesh;
  laserLine: THREE.Line;
} {
  const group = new THREE.Group();

  const gunMetalMat = new THREE.MeshStandardMaterial({
    color: 0x1e2228,
    metalness: 0.84,
    roughness: 0.32,
  });
  const fdePolymerMat = new THREE.MeshStandardMaterial({
    color: 0x7a7263, // FDE tan/olive-grey matching reference stock & PMAG
    metalness: 0.14,
    roughness: 0.76,
  });
  const darkPolymerMat = new THREE.MeshStandardMaterial({
    color: 0x26292e,
    metalness: 0.15,
    roughness: 0.72,
  });
  const suppressorMat = new THREE.MeshStandardMaterial({
    color: 0x16181c,
    metalness: 0.75,
    roughness: 0.42,
  });
  const opticGlassMat = new THREE.MeshBasicMaterial({
    color: 0x1e3a5f,
    transparent: true,
    opacity: 0.24,
    depthWrite: false,
  });

  if (weaponId === 'mk18_suppressed') {
    // 1. Upper & Lower Receiver + Trigger Guard
    const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.052, 0.078, 0.25), gunMetalMat);
    group.add(receiver);

    const triggerGuard = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.028, 0.065), gunMetalMat);
    triggerGuard.position.set(0, -0.052, 0.02);
    group.add(triggerGuard);

    // 2. Quad-Rail Handguard with Ribbed Picatinny Rails
    const handguard = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.054, 0.28), gunMetalMat);
    handguard.position.set(0, 0.012, -0.265);
    group.add(handguard);

    for (let r = 0; r < 6; r++) {
      const rib = new THREE.Mesh(new THREE.BoxGeometry(0.056, 0.014, 0.014), darkPolymerMat);
      rib.position.set(0, 0.012, -0.15 - r * 0.042);
      group.add(rib);
    }

    // 3. Front A-Frame Sight Post + Barrel + Suppressor
    const frontPost = new THREE.Mesh(new THREE.BoxGeometry(0.014, 0.052, 0.022), gunMetalMat);
    frontPost.position.set(0, 0.06, -0.37);
    group.add(frontPost);

    const barrel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.011, 0.011, 0.14, 12),
      gunMetalMat,
    );
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.014, -0.45);
    group.add(barrel);

    const suppressor = new THREE.Mesh(
      new THREE.CylinderGeometry(0.021, 0.021, 0.18, 16),
      suppressorMat,
    );
    suppressor.rotation.x = Math.PI / 2;
    suppressor.position.set(0, 0.014, -0.58);
    group.add(suppressor);

    // 4. ELCAN / ACOG Cylindrical Scope + Open Piggyback Micro Red-Dot Reflex Sight
    const scopeMount = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.018, 0.11), gunMetalMat);
    scopeMount.position.set(0, 0.047, -0.02);
    group.add(scopeMount);

    const scopeTube = new THREE.Mesh(
      new THREE.CylinderGeometry(0.022, 0.024, 0.14, 14),
      gunMetalMat,
    );
    scopeTube.rotation.x = Math.PI / 2;
    scopeTube.position.set(0, 0.072, -0.02);
    group.add(scopeTube);

    // Piggyback Micro Reflex Window on top of ELCAN
    const reflexL = new THREE.Mesh(new THREE.BoxGeometry(0.005, 0.024, 0.042), gunMetalMat);
    reflexL.position.set(-0.015, 0.104, -0.01);
    group.add(reflexL);
    const reflexR = new THREE.Mesh(new THREE.BoxGeometry(0.005, 0.024, 0.042), gunMetalMat);
    reflexR.position.set(0.015, 0.104, -0.01);
    group.add(reflexR);
    const reflexTop = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.005, 0.042), gunMetalMat);
    reflexTop.position.set(0, 0.118, -0.01);
    group.add(reflexTop);

    const opticLens = new THREE.Mesh(new THREE.PlaneGeometry(0.026, 0.022), opticGlassMat);
    opticLens.position.set(0, 0.104, -0.01);
    group.add(opticLens);

    const reticleDot = new THREE.Mesh(
      new THREE.RingGeometry(0.002, 0.0032, 16),
      new THREE.MeshBasicMaterial({ color: 0xff3b30, side: THREE.DoubleSide }),
    );
    reticleDot.position.set(0, 0.104, -0.009);
    group.add(reticleDot);

    // 5. PEQ-15 Laser Module on front top rail
    const peq = new THREE.Mesh(new THREE.BoxGeometry(0.044, 0.026, 0.08), darkPolymerMat);
    peq.position.set(0.012, 0.052, -0.29);
    group.add(peq);

    // 6. Angled Tactical Foregrip + Weapon Flashlight (matching reference underbarrel)
    const foregrip = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.095, 0.044), fdePolymerMat);
    foregrip.position.set(0, -0.068, -0.22);
    foregrip.rotation.x = 0.25;
    group.add(foregrip);

    const tacLight = new THREE.Mesh(
      new THREE.CylinderGeometry(0.015, 0.017, 0.095, 12),
      fdePolymerMat,
    );
    tacLight.rotation.x = Math.PI / 2;
    tacLight.position.set(0, -0.028, -0.29);
    group.add(tacLight);

    // 7. Curved FDE PMAG + Textured Pistol Grip
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.155, 0.062), fdePolymerMat);
    mag.position.set(0, -0.11, -0.055);
    mag.rotation.x = -0.2;
    group.add(mag);

    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.1, 0.044), darkPolymerMat);
    grip.position.set(0, -0.078, 0.085);
    grip.rotation.x = 0.3;
    group.add(grip);

    // 8. Skeletal FDE CTR Buttstock (Buffer Tube + Angled Struts + Buttpad)
    const bufferTube = new THREE.Mesh(
      new THREE.CylinderGeometry(0.018, 0.018, 0.2, 10),
      gunMetalMat,
    );
    bufferTube.rotation.x = Math.PI / 2;
    bufferTube.position.set(0, 0.012, 0.21);
    group.add(bufferTube);

    const buttpad = new THREE.Mesh(new THREE.BoxGeometry(0.042, 0.125, 0.028), fdePolymerMat);
    buttpad.position.set(0, -0.025, 0.3);
    buttpad.rotation.x = 0.12;
    group.add(buttpad);

    const stockStrut = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.024, 0.17), fdePolymerMat);
    stockStrut.position.set(0, -0.055, 0.22);
    stockStrut.rotation.x = -0.35;
    group.add(stockStrut);
  } else {
    // Faceted Crystal Blue/Violet Suppressed Pistol (91d91935ef514fc790d148807d477741_dfff079f.jpg)
    const crystalTex = createCrystalPistolTexture();
    const crystalMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: crystalTex,
      metalness: 0.85,
      roughness: 0.22,
    });

    // Machined Slide with crystal finish
    const slide = new THREE.Mesh(new THREE.BoxGeometry(0.038, 0.044, 0.22), crystalMat);
    slide.position.set(0, 0.024, -0.04);
    group.add(slide);

    // Polymer Frame & Trigger Guard
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.028, 0.19), darkPolymerMat);
    frame.position.set(0, -0.01, -0.03);
    group.add(frame);

    const trigGuard = new THREE.Mesh(new THREE.BoxGeometry(0.014, 0.034, 0.055), darkPolymerMat);
    trigGuard.position.set(0, -0.036, 0.0);
    group.add(trigGuard);

    // Ribbed Tactical Grip
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.11, 0.048), darkPolymerMat);
    grip.position.set(0, -0.072, 0.05);
    grip.rotation.x = 0.24;
    group.add(grip);

    // Long Two-Stage Suppressor with Crystal Finish
    const suppressor = new THREE.Mesh(
      new THREE.CylinderGeometry(0.021, 0.02, 0.21, 16),
      crystalMat,
    );
    suppressor.rotation.x = Math.PI / 2;
    suppressor.position.set(0, 0.022, -0.255);
    group.add(suppressor);

    // Front & Rear Suppressor-Height Iron Sights
    const rearSight = new THREE.Mesh(new THREE.BoxGeometry(0.022, 0.014, 0.016), gunMetalMat);
    rearSight.position.set(0, 0.052, 0.05);
    group.add(rearSight);

    const frontSight = new THREE.Mesh(
      new THREE.BoxGeometry(0.006, 0.014, 0.014),
      new THREE.MeshStandardMaterial({ color: 0x22c55e, emissive: 0x16a34a, emissiveIntensity: 1.5 }),
    );
    frontSight.position.set(0, 0.052, -0.13);
    group.add(frontSight);
  }

  // Muzzle flash sprite mesh
  const muzzleFlash = new THREE.Mesh(
    new THREE.SphereGeometry(0.045, 8, 8),
    new THREE.MeshBasicMaterial({
      color: 0xffb347,
      transparent: true,
      opacity: 0,
      depthWrite: false,
    }),
  );
  muzzleFlash.position.set(0, 0.015, weaponId === 'mk18_suppressed' ? -0.68 : -0.37);
  group.add(muzzleFlash);

  // IR Laser beam (visible when NVGs active)
  const laserGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(0.02, 0.048, -0.34),
    new THREE.Vector3(0.0, 0.02, -32.0),
  ]);
  const laserLine = new THREE.Line(
    laserGeo,
    new THREE.LineBasicMaterial({
      color: 0x4ade80,
      transparent: true,
      opacity: 0.55,
    }),
  );
  laserLine.visible = false;
  group.add(laserLine);

  return { group, muzzleFlash, laserLine };
}

/**
 * Tactical Combat Soldier matching reference image (i_c3d8d8ab.webp):
 * Digital ACU camo uniform, tan MOLLE vest with 3 mag pouches, ACH helmet with NVG shroud,
 * articulated arms holding carbine rifle across chest.
 */
let _sharedCamoTex: THREE.CanvasTexture | null = null;
export function buildEnemyMesh(
  archetype: EnemyArchetype,
  contactShadowTex: THREE.CanvasTexture,
): {
  root: THREE.Group;
  headMesh: THREE.Mesh;
  torsoMesh: THREE.Mesh;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  armL: THREE.Mesh;
  armR: THREE.Mesh;
  laserLine: THREE.Line | null;
} {
  const root = new THREE.Group();
  if (!_sharedCamoTex) {
    _sharedCamoTex = createDigitalCamoTexture();
  }

  const camoTint =
    archetype === 'sniper'
      ? 0xa3b899
      : archetype === 'breacher'
        ? 0x8e96a0
        : archetype === 'officer'
          ? 0xb89696
          : 0xffffff;

  const acuMat = new THREE.MeshStandardMaterial({
    color: camoTint,
    map: _sharedCamoTex,
    roughness: 0.85,
    metalness: 0.05,
  });
  const tanVestMat = new THREE.MeshStandardMaterial({
    color: archetype === 'breacher' ? 0x3b4048 : 0xa39276, // Coyote tan MOLLE plate carrier
    roughness: 0.72,
    metalness: 0.12,
  });
  const skinMat = new THREE.MeshStandardMaterial({
    color: 0xc99c7c,
    roughness: 0.65,
    metalness: 0.02,
  });
  const gloveMat = new THREE.MeshStandardMaterial({
    color: 0x5c584a,
    roughness: 0.75,
    metalness: 0.08,
  });
  const metalMat = new THREE.MeshStandardMaterial({
    color: 0x1a1d22,
    roughness: 0.3,
    metalness: 0.85,
  });

  // Contact shadow disc
  const shadowDisc = new THREE.Mesh(
    new THREE.CircleGeometry(0.65, 16),
    new THREE.MeshBasicMaterial({
      map: contactShadowTex,
      transparent: true,
      opacity: 0.48,
      depthWrite: false,
    }),
  );
  shadowDisc.rotation.x = -Math.PI / 2;
  shadowDisc.position.y = 0.02;
  root.add(shadowDisc);

  // Legs + Combat Boots
  const legGeo = new THREE.BoxGeometry(0.18, 0.78, 0.21);
  const legL = new THREE.Mesh(legGeo, acuMat);
  legL.position.set(-0.13, 0.48, 0);
  legL.castShadow = true;
  root.add(legL);

  const legR = new THREE.Mesh(legGeo, acuMat);
  legR.position.set(0.13, 0.48, 0);
  legR.castShadow = true;
  root.add(legR);

  const bootGeo = new THREE.BoxGeometry(0.19, 0.16, 0.27);
  const bootL = new THREE.Mesh(bootGeo, tanVestMat);
  bootL.position.set(-0.13, 0.08, 0.03);
  root.add(bootL);
  const bootR = new THREE.Mesh(bootGeo, tanVestMat);
  bootR.position.set(0.13, 0.08, 0.03);
  root.add(bootR);

  // Torso (ACU) + Coyote Tan MOLLE Plate Carrier + 3 Front Mag Pouches + Combat Belt
  const torsoMesh = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.62, 0.28), acuMat);
  torsoMesh.position.set(0, 1.18, 0);
  torsoMesh.castShadow = true;
  root.add(torsoMesh);

  const plateCarrier = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.46, 0.34), tanVestMat);
  plateCarrier.position.set(0, 1.22, 0.01);
  plateCarrier.castShadow = true;
  root.add(plateCarrier);

  for (let m = -1; m <= 1; m++) {
    const pouch = new THREE.Mesh(new THREE.BoxGeometry(0.095, 0.16, 0.06), tanVestMat);
    pouch.position.set(m * 0.12, 1.12, 0.19);
    root.add(pouch);
  }

  const belt = new THREE.Mesh(new THREE.BoxGeometry(0.47, 0.08, 0.31), tanVestMat);
  belt.position.set(0, 0.9, 0);
  root.add(belt);

  // Articulated Arms + Gloved Hands Holding Rifle
  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.44, 0.15), acuMat);
  armL.position.set(-0.28, 1.24, 0.12);
  armL.rotation.x = -0.65;
  armL.rotation.z = -0.25;
  root.add(armL);

  const armR = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.44, 0.15), acuMat);
  armR.position.set(0.28, 1.24, 0.12);
  armR.rotation.x = -0.65;
  armR.rotation.z = 0.25;
  root.add(armR);

  const handL = new THREE.Mesh(new THREE.SphereGeometry(0.065, 8, 8), gloveMat);
  handL.position.set(-0.12, 1.16, 0.32);
  root.add(handL);
  const handR = new THREE.Mesh(new THREE.SphereGeometry(0.065, 8, 8), gloveMat);
  handR.position.set(0.14, 1.18, 0.28);
  root.add(handR);

  // Head + ACH Tactical Helmet with ACU Camo Cover & Black NVG Shroud
  const headMesh = new THREE.Mesh(new THREE.SphereGeometry(0.135, 12, 12), skinMat);
  headMesh.position.set(0, 1.63, 0);
  headMesh.castShadow = true;
  root.add(headMesh);

  const helmet = new THREE.Mesh(
    new THREE.SphereGeometry(0.168, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.58),
    acuMat,
  );
  helmet.position.set(0, 1.65, 0);
  root.add(helmet);

  const nvgMount = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.075, 0.04), metalMat);
  nvgMount.position.set(0, 1.71, 0.155);
  root.add(nvgMount);

  // Archetype Accents
  if (archetype === 'breacher') {
    const visor = new THREE.Mesh(
      new THREE.BoxGeometry(0.26, 0.11, 0.12),
      new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.15, metalness: 0.8 }),
    );
    visor.position.set(0, 1.63, 0.13);
    root.add(visor);
  } else if (archetype === 'sniper') {
    const hood = new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.34, 8), acuMat);
    hood.position.set(0, 1.73, -0.03);
    root.add(hood);
  } else if (archetype === 'officer') {
    const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.45, 6), metalMat);
    antenna.position.set(-0.22, 1.62, -0.14);
    root.add(antenna);
  }

  // Carbine Rifle held across chest/forward (matching reference i_c3d8d8ab.webp)
  const gunLen = archetype === 'sniper' ? 0.96 : archetype === 'breacher' ? 0.68 : 0.72;
  const gun = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.09, gunLen), metalMat);
  gun.position.set(0.04, 1.2, 0.34);
  gun.rotation.y = -0.38;
  root.add(gun);

  const gunMag = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.13, 0.055), metalMat);
  gunMag.position.set(0.02, 1.11, 0.35);
  gunMag.rotation.y = -0.38;
  root.add(gunMag);

  let laserLine: THREE.Line | null = null;
  if (archetype === 'sniper') {
    const pts = [new THREE.Vector3(0.08, 1.24, 0.68), new THREE.Vector3(0, 1.1, 35)];
    laserLine = new THREE.Line(
      new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.48 }),
    );
    root.add(laserLine);
  }

  return { root, headMesh, torsoMesh, legL, legR, armL, armR, laserLine };
}

/**
 * 4-Legged Steel Lattice Military Watchtower matching reference (i_9a2a4ebd.webp):
 * Concrete base apron, 4 columns + X cross-braces, external staircase + handrails,
 * cantilevered observation balcony with railings, parapet walls, and canopy roof.
 */
export function buildLatticeWatchtower(
  concreteMat: THREE.Material,
  steelMat: THREE.Material,
): THREE.Group {
  const g = new THREE.Group();
  const towerFrameMat = new THREE.MeshStandardMaterial({
    color: 0x4b5563,
    roughness: 0.55,
    metalness: 0.45,
  });

  // 1. Concrete Base Slab & Stair Landing Apron
  const pad = new THREE.Mesh(new THREE.BoxGeometry(4.0, 0.2, 4.0), concreteMat);
  pad.position.set(0, 0.1, 0);
  pad.receiveShadow = true;
  g.add(pad);

  // 2. 4 Corner Structural Columns (height 4.8m to deck, plus 2.3m roof posts)
  const colGeo = new THREE.BoxGeometry(0.22, 4.8, 0.22);
  const corners: [number, number][] = [
    [-1.55, -1.55],
    [1.55, -1.55],
    [-1.55, 1.55],
    [1.55, 1.55],
  ];
  for (const [cx, cz] of corners) {
    const col = new THREE.Mesh(colGeo, towerFrameMat);
    col.position.set(cx, 2.4, cz);
    col.castShadow = true;
    g.add(col);
  }

  // Horizontal Deck Frame & Cross-Braces (2 vertical bays)
  const beamGeo = new THREE.BoxGeometry(3.2, 0.14, 0.14);
  for (const by of [1.6, 3.2, 4.7]) {
    const bFront = new THREE.Mesh(beamGeo, towerFrameMat);
    bFront.position.set(0, by, 1.55);
    const bBack = new THREE.Mesh(beamGeo, towerFrameMat);
    bBack.position.set(0, by, -1.55);
    g.add(bFront, bBack);

    const bLeft = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 3.2), towerFrameMat);
    bLeft.position.set(-1.55, by, 0);
    const bRight = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 3.2), towerFrameMat);
    bRight.position.set(1.55, by, 0);
    g.add(bLeft, bRight);
  }

  // Diagonal X-Bracing Struts
  const diagGeo = new THREE.BoxGeometry(0.1, 3.55, 0.1);
  for (const sideZ of [-1.55, 1.55]) {
    const d1 = new THREE.Mesh(diagGeo, towerFrameMat);
    d1.position.set(0, 2.4, sideZ);
    d1.rotation.z = 0.62;
    const d2 = new THREE.Mesh(diagGeo, towerFrameMat);
    d2.position.set(0, 2.4, sideZ);
    d2.rotation.z = -0.62;
    g.add(d1, d2);
  }

  // 3. External Staircase along +X side leading up to deck
  for (let s = 0; s < 12; s++) {
    const tread = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.08, 0.28), steelMat);
    tread.position.set(2.15, 0.38 + s * 0.38, -1.6 + s * 0.3);
    g.add(tread);
  }
  const stairRail = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 4.5), towerFrameMat);
  stairRail.position.set(2.55, 2.95, 0.05);
  stairRail.rotation.x = -0.82;
  g.add(stairRail);

  // 4. Main Observation Deck (y = 4.8m) + Cantilevered Balcony Catwalk (+Z side)
  const deck = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.2, 5.2), concreteMat);
  deck.position.set(0, 4.75, 0.7);
  deck.castShadow = true;
  deck.receiveShadow = true;
  g.add(deck);

  // Guardrails & Half-Height Sniper Parapet
  const frontParapet = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.95, 0.18), towerFrameMat);
  frontParapet.position.set(0, 5.3, 1.65);
  g.add(frontParapet);

  const balconyRailFront = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.08, 0.08), towerFrameMat);
  balconyRailFront.position.set(0, 5.75, 3.25);
  g.add(balconyRailFront);
  for (const rx of [-1.7, -0.55, 0.55, 1.7]) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.95, 0.08), towerFrameMat);
    post.position.set(rx, 5.3, 3.25);
    g.add(post);
  }

  // 5. Roof Posts & Beveled Canopy Roof
  for (const [cx, cz] of corners) {
    const rPost = new THREE.Mesh(new THREE.BoxGeometry(0.16, 2.3, 0.16), towerFrameMat);
    rPost.position.set(cx, 5.95, cz);
    g.add(rPost);
  }
  const roof = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 2.7, 0.65, 4), towerFrameMat);
  roof.rotation.y = Math.PI / 4;
  roof.position.set(0, 7.3, 0);
  roof.castShadow = true;
  g.add(roof);

  return g;
}

/**
 * Olive-Teal Military Command / Field Tent matching reference (i_0fffe445.webp):
 * Pitched canvas roof & walls, front doorway vestibule, side windows, diagonal tension guy-ropes.
 */
export function buildMilitaryTent(): THREE.Group {
  const g = new THREE.Group();
  const tentRoofMat = new THREE.MeshStandardMaterial({
    color: 0x3b625d,
    roughness: 0.88,
    metalness: 0.04,
  });
  const tentDarkMat = new THREE.MeshStandardMaterial({
    color: 0x162b28,
    roughness: 0.92,
    metalness: 0.02,
  });
  const ropeMat = new THREE.MeshBasicMaterial({ color: 0x262a2e });

  // Lower Canvas Side Walls
  const sideWallL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.85, 5.6), tentRoofMat);
  sideWallL.position.set(-1.95, 0.92, 0);
  sideWallL.castShadow = true;
  const sideWallR = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.85, 5.6), tentRoofMat);
  sideWallR.position.set(1.95, 0.92, 0);
  sideWallR.castShadow = true;
  const backWall = new THREE.Mesh(new THREE.BoxGeometry(3.9, 1.85, 0.14), tentDarkMat);
  backWall.position.set(0, 0.92, -2.75);
  g.add(sideWallL, sideWallR, backWall);

  // Dark Interior Groundsheet & Front Vestibule Frame
  const frontLeft = new THREE.Mesh(new THREE.BoxGeometry(1.25, 1.85, 0.14), tentDarkMat);
  frontLeft.position.set(-1.32, 0.92, 2.75);
  const frontRight = new THREE.Mesh(new THREE.BoxGeometry(1.25, 1.85, 0.14), tentDarkMat);
  frontRight.position.set(1.32, 0.92, 2.75);
  g.add(frontLeft, frontRight);

  // Pitched Gable Roof (ExtrudeGeometry triangle prism)
  const gableShape = new THREE.Shape();
  gableShape.moveTo(-2.1, 0);
  gableShape.lineTo(2.1, 0);
  gableShape.lineTo(0, 1.25);
  gableShape.closePath();
  const roofGeo = new THREE.ExtrudeGeometry(gableShape, { depth: 5.8, bevelEnabled: false });
  roofGeo.translate(0, 0, -2.9);
  const roofMesh = new THREE.Mesh(roofGeo, tentRoofMat);
  roofMesh.position.set(0, 1.84, 0);
  roofMesh.castShadow = true;
  g.add(roofMesh);

  // Side Canvas Windows
  for (const wz of [-1.6, 0, 1.6]) {
    const win = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.55, 0.65), tentDarkMat);
    win.position.set(1.98, 1.2, wz);
    g.add(win);
  }

  // Diagonal Tension Guy-Ropes staked into ground
  const ropeGeo = new THREE.CylinderGeometry(0.014, 0.014, 2.3, 5);
  for (const rz of [-2.4, -0.8, 0.8, 2.4]) {
    const ropeL = new THREE.Mesh(ropeGeo, ropeMat);
    ropeL.position.set(-2.65, 0.9, rz);
    ropeL.rotation.z = -0.62;
    const ropeR = new THREE.Mesh(ropeGeo, ropeMat);
    ropeR.position.set(2.65, 0.9, rz);
    ropeR.rotation.z = 0.62;
    g.add(ropeL, ropeR);
  }

  return g;
}

/**
 * Pitched Gable Roof + Number Stencil Plate ("13" / "14") + Ribbon Windows for Barracks (i_e4bf5904.webp)
 */
export function buildBarracksDetails(
  width: number,
  depth: number,
  wallHeight: number,
  numberLabel: string,
  doorSide: 'east' | 'west',
): THREE.Group {
  const g = new THREE.Group();
  const roofMat = new THREE.MeshStandardMaterial({
    color: 0x3b424c,
    roughness: 0.72,
    metalness: 0.25,
  });
  const windowMat = new THREE.MeshStandardMaterial({
    color: 0x16222e,
    roughness: 0.15,
    metalness: 0.75,
  });

  // Overhanging Pitched Gable Roof (ridge along Z)
  const hw = width / 2 + 0.45;
  const shape = new THREE.Shape();
  shape.moveTo(-hw, 0);
  shape.lineTo(hw, 0);
  shape.lineTo(0, 1.65);
  shape.closePath();
  const roofGeo = new THREE.ExtrudeGeometry(shape, { depth: depth + 0.8, bevelEnabled: false });
  roofGeo.translate(0, 0, -(depth + 0.8) / 2);
  const roof = new THREE.Mesh(roofGeo, roofMat);
  roof.position.set(0, wallHeight, 0);
  roof.castShadow = true;
  g.add(roof);

  // Horizontal Ribbon Windows along Courtyard-facing wall
  const winX = doorSide === 'east' ? width / 2 + 0.04 : -width / 2 - 0.04;
  for (const wz of [-4.2, -1.8, 4.2]) {
    const win = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.7, 1.35), windowMat);
    win.position.set(winX, 2.25, wz);
    g.add(win);
  }

  // Barracks Number Stencil Sign ("13" or "14") on South Gable End
  const numTex = createBarracksNumberTexture(numberLabel);
  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(1.8, 1.8),
    new THREE.MeshStandardMaterial({ color: 0xffffff, map: numTex, roughness: 0.8 }),
  );
  sign.position.set(doorSide === 'east' ? 1.8 : -1.8, 2.1, depth / 2 + 0.05);
  g.add(sign);

  return g;
}

/**
 * Desert-Tan Tactical 4x4 MRAP / Tiger Armored Vehicle matching reference (i_e4bf5904.webp)
 */
export function buildMrapVehicle(_metalMat: THREE.Material, tireMat: THREE.Material): THREE.Group {
  const g = new THREE.Group();
  const tanArmorMat = new THREE.MeshStandardMaterial({
    color: 0x9b896a, // Desert tan armor hull matching i_e4bf5904.webp
    roughness: 0.62,
    metalness: 0.25,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x2a2d30,
    roughness: 0.55,
    metalness: 0.6,
  });

  const hull = new THREE.Mesh(new THREE.BoxGeometry(2.45, 1.25, 5.2), tanArmorMat);
  hull.position.set(0, 1.22, 0);
  hull.castShadow = true;
  hull.receiveShadow = true;
  g.add(hull);

  const cab = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.78, 2.9), tanArmorMat);
  cab.position.set(0, 2.15, -0.2);
  cab.castShadow = true;
  g.add(cab);

  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x162430,
    roughness: 0.12,
    metalness: 0.65,
  });
  const windshield = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.48, 0.14), glassMat);
  windshield.position.set(0, 2.18, 1.25);
  windshield.rotation.x = -0.22;
  g.add(windshield);

  const sideWinL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.42, 1.8), glassMat);
  sideWinL.position.set(-1.14, 2.18, -0.15);
  const sideWinR = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.42, 1.8), glassMat);
  sideWinR.position.set(1.14, 2.18, -0.15);
  g.add(sideWinL, sideWinR);

  const turretRing = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.62, 0.28, 12), trimMat);
  turretRing.position.set(0, 2.66, -0.35);
  g.add(turretRing);

  const bumper = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.34, 0.4), trimMat);
  bumper.position.set(0, 0.75, 2.65);
  g.add(bumper);

  // 4 Heavy Off-Road Wheels
  const wheelGeo = new THREE.CylinderGeometry(0.56, 0.56, 0.44, 16);
  wheelGeo.rotateZ(Math.PI / 2);
  const wheelOffsets: [number, number][] = [
    [-1.26, 1.65],
    [1.26, 1.65],
    [-1.26, -1.65],
    [1.26, -1.65],
  ];
  for (const [wx, wz] of wheelOffsets) {
    const wheel = new THREE.Mesh(wheelGeo, tireMat);
    wheel.position.set(wx, 0.56, wz);
    wheel.castShadow = true;
    g.add(wheel);
  }

  return g;
}

/**
 * Composite Tall Sat-Com Radar Tower Landmark (visible from Insertion Ridge)
 */
export function buildSatComTower(steelMat: THREE.Material, accentMat: THREE.Material): {
  group: THREE.Group;
  dishPivot: THREE.Group;
  beaconMesh: THREE.Mesh;
} {
  const group = new THREE.Group();

  const plinth = new THREE.Mesh(new THREE.BoxGeometry(3.8, 1.2, 3.8), accentMat);
  plinth.position.set(0, 0.6, 0);
  plinth.castShadow = true;
  plinth.receiveShadow = true;
  group.add(plinth);

  const legGeo = new THREE.CylinderGeometry(0.12, 0.18, 14.5, 8);
  const legPos: [number, number][] = [
    [-1.1, -1.1],
    [1.1, -1.1],
    [-1.1, 1.1],
    [1.1, 1.1],
  ];
  for (const [lx, lz] of legPos) {
    const leg = new THREE.Mesh(legGeo, steelMat);
    leg.position.set(lx * 0.72, 8.2, lz * 0.72);
    leg.rotation.z = lx * 0.055;
    leg.rotation.x = -lz * 0.055;
    leg.castShadow = true;
    group.add(leg);
  }

  const platform = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 0.28, 12), steelMat);
  platform.position.set(0, 14.6, 0);
  group.add(platform);

  const dishPivot = new THREE.Group();
  dishPivot.position.set(0, 15.8, 0);

  const dish = new THREE.Mesh(
    new THREE.SphereGeometry(1.6, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.42),
    new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.38,
      metalness: 0.65,
      side: THREE.DoubleSide,
    }),
  );
  dish.rotation.x = Math.PI * 0.65;
  dishPivot.add(dish);

  const feedHorn = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 1.1, 8), steelMat);
  feedHorn.position.set(0, 0.25, 0.85);
  feedHorn.rotation.x = Math.PI / 2;
  dishPivot.add(feedHorn);
  group.add(dishPivot);

  const beaconMesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.18, 10, 10),
    new THREE.MeshBasicMaterial({ color: 0xff2d20 }),
  );
  beaconMesh.position.set(0, 17.5, 0);
  group.add(beaconMesh);

  return { group, dishPivot, beaconMesh };
}

/**
 * Pineapple Frag Grenade (Mk2/F1) matching reference (49ad719e1b2cc71dd7ab16523379c8d3_92b53ea5.jpg):
 * Segmented olive-drab cast iron body, yellow safety band, silver fuse housing, curved lever spoon & pull ring.
 */
export function buildGrenadeMesh(): THREE.Group {
  const g = new THREE.Group();

  const oliveBodyMat = new THREE.MeshStandardMaterial({
    color: 0x4b5336,
    roughness: 0.62,
    metalness: 0.35,
  });
  const bandMat = new THREE.MeshStandardMaterial({
    color: 0xeab308,
    roughness: 0.5,
    metalness: 0.15,
  });
  const fuseMetalMat = new THREE.MeshStandardMaterial({
    color: 0x9ca3af,
    roughness: 0.28,
    metalness: 0.85,
  });
  const spoonMat = new THREE.MeshStandardMaterial({
    color: 0x374151,
    roughness: 0.42,
    metalness: 0.75,
  });

  // 1. Ribbed Pineapple Body (layered ellipsoid + fragmentation bands)
  const core = new THREE.Mesh(new THREE.SphereGeometry(0.058, 12, 10), oliveBodyMat);
  core.scale.set(0.88, 1.32, 0.88);
  core.position.set(0, 0.06, 0);
  g.add(core);

  for (const ry of [0.025, 0.06, 0.095]) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.048, 0.008, 6, 10), oliveBodyMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(0, ry, 0);
    g.add(ring);
  }

  // 2. Yellow Explosive Collar Band
  const yellowBand = new THREE.Mesh(
    new THREE.CylinderGeometry(0.026, 0.032, 0.014, 12),
    bandMat,
  );
  yellowBand.position.set(0, 0.132, 0);
  g.add(yellowBand);

  // 3. Silver Fuse Assembly & Spoon Lever + Pull Ring
  const fuseHead = new THREE.Mesh(
    new THREE.CylinderGeometry(0.022, 0.022, 0.035, 12),
    fuseMetalMat,
  );
  fuseHead.position.set(0, 0.155, 0);
  g.add(fuseHead);

  const spoon = new THREE.Mesh(new THREE.BoxGeometry(0.014, 0.11, 0.008), spoonMat);
  spoon.position.set(0.045, 0.095, 0);
  spoon.rotation.z = -0.15;
  g.add(spoon);

  const pullRing = new THREE.Mesh(new THREE.TorusGeometry(0.022, 0.0035, 6, 16), fuseMetalMat);
  pullRing.position.set(0.032, 0.152, 0.015);
  g.add(pullRing);

  return g;
}

/**
 * Weathered Military Supply / Loot Crate matching reference (i_9cb58588.webp):
 * Wooden plank body with overhanging lid, dark iron vertical straps, corner brackets, and front latches.
 */
export function buildLootCrateMesh(
  woodTex: THREE.CanvasTexture,
  contactShadowTex: THREE.CanvasTexture,
): THREE.Group {
  const g = new THREE.Group();

  const woodMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: woodTex,
    roughness: 0.85,
    metalness: 0.05,
  });
  const ironMat = new THREE.MeshStandardMaterial({
    color: 0x2b3036,
    roughness: 0.45,
    metalness: 0.72,
  });
  const beaconStripMat = new THREE.MeshStandardMaterial({
    color: 0x34d399,
    emissive: 0x10b981,
    emissiveIntensity: 0.9,
    roughness: 0.3,
  });

  // Ground contact shadow
  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(0.68, 16),
    new THREE.MeshBasicMaterial({
      map: contactShadowTex,
      transparent: true,
      opacity: 0.5,
      depthWrite: false,
    }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.018;
  g.add(shadow);

  // Main wooden crate body (0.76 x 0.38 x 0.52)
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.76, 0.36, 0.52), woodMat);
  body.position.set(0, 0.19, 0);
  body.castShadow = true;
  body.receiveShadow = true;
  g.add(body);

  // Overhanging wooden lid
  const lid = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.06, 0.56), woodMat);
  lid.position.set(0, 0.4, 0);
  lid.castShadow = true;
  g.add(lid);

  // Two dark iron reinforcement straps wrapping crate & top cross-battens
  for (const sx of [-0.24, 0.24]) {
    const strap = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.43, 0.57), ironMat);
    strap.position.set(sx, 0.22, 0);
    g.add(strap);

    const latch = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.08, 0.03), ironMat);
    latch.position.set(sx * 0.72, 0.34, 0.285);
    g.add(latch);
  }

  // Subtle tactical glow strip on top so loot crates stay visible in Kashgar night rain
  const glowTag = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.018, 0.06), beaconStripMat);
  glowTag.position.set(0, 0.435, 0);
  g.add(glowTag);

  return g;
}

/**
 * PUBG-Style Red & Blue Airdrop Supply Crate matching reference (pubg_box_5f08a978.png):
 * Corrugated red steel body, bright cyan-blue draped tarp lid with hanging corner flaps,
 * twin black cargo straps with silver buckles, red flare beacon, and parachute canopy.
 */
export function buildAirdropCrateMesh(contactShadowTex: THREE.CanvasTexture): {
  root: THREE.Group;
  chuteGroup: THREE.Group;
  flareMesh: THREE.Mesh;
} {
  const root = new THREE.Group();

  const redCrateMat = new THREE.MeshStandardMaterial({
    color: 0xb91c1c,
    roughness: 0.48,
    metalness: 0.42,
  });
  const blueTarpMat = new THREE.MeshStandardMaterial({
    color: 0x0284c7,
    roughness: 0.58,
    metalness: 0.08,
  });
  const strapMat = new THREE.MeshStandardMaterial({
    color: 0x18181b,
    roughness: 0.72,
    metalness: 0.15,
  });
  const buckleMat = new THREE.MeshStandardMaterial({
    color: 0xd4d4d8,
    roughness: 0.28,
    metalness: 0.85,
  });

  // Ground contact shadow
  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(1.15, 16),
    new THREE.MeshBasicMaterial({
      map: contactShadowTex,
      transparent: true,
      opacity: 0.58,
      depthWrite: false,
    }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.02;
  root.add(shadow);

  // Corrugated red body (1.1 x 0.92 x 1.1)
  const body = new THREE.Mesh(new THREE.BoxGeometry(1.08, 0.88, 1.08), redCrateMat);
  body.position.set(0, 0.45, 0);
  body.castShadow = true;
  body.receiveShadow = true;
  root.add(body);

  // Vertical corrugated metal ribs on all sides
  for (let r = -0.4; r <= 0.41; r += 0.2) {
    const ribF = new THREE.Mesh(new THREE.BoxGeometry(0.055, 0.84, 1.12), redCrateMat);
    ribF.position.set(r, 0.45, 0);
    const ribS = new THREE.Mesh(new THREE.BoxGeometry(1.12, 0.84, 0.055), redCrateMat);
    ribS.position.set(0, 0.45, r);
    root.add(ribF, ribS);
  }

  // Draped cyan-blue tarp top + hanging side flaps (pubg_box_5f08a978.png)
  const tarpTop = new THREE.Mesh(new THREE.BoxGeometry(1.18, 0.16, 1.18), blueTarpMat);
  tarpTop.position.set(0, 0.94, 0);
  tarpTop.castShadow = true;
  root.add(tarpTop);

  const flapF = new THREE.Mesh(new THREE.BoxGeometry(1.14, 0.24, 0.08), blueTarpMat);
  flapF.position.set(0, 0.82, 0.57);
  flapF.rotation.x = -0.14;
  const flapB = new THREE.Mesh(new THREE.BoxGeometry(1.14, 0.24, 0.08), blueTarpMat);
  flapB.position.set(0, 0.82, -0.57);
  flapB.rotation.x = 0.14;
  const flapL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.26, 1.14), blueTarpMat);
  flapL.position.set(-0.57, 0.81, 0);
  flapL.rotation.z = 0.12;
  const flapR = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.26, 1.14), blueTarpMat);
  flapR.position.set(0.57, 0.81, 0);
  flapR.rotation.z = -0.12;
  root.add(flapF, flapB, flapL, flapR);

  // Twin black cargo straps wrapping top and front/back + silver buckles
  for (const sx of [-0.3, 0.3]) {
    const strap = new THREE.Mesh(new THREE.BoxGeometry(0.11, 1.04, 1.21), strapMat);
    strap.position.set(sx, 0.52, 0);
    root.add(strap);

    const buckleF = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.04), buckleMat);
    buckleF.position.set(sx, 0.54, 0.61);
    const buckleB = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.04), buckleMat);
    buckleB.position.set(sx, 0.54, -0.61);
    root.add(buckleF, buckleB);
  }

  // Glowing red smoke flare canister on lid
  const flareMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.09, 0.11, 0.18, 10),
    new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xdc2626,
      emissiveIntensity: 2.2,
    }),
  );
  flareMesh.position.set(0, 1.08, 0);
  root.add(flareMesh);

  // Collapsible Parachute Canopy + Suspension Cords
  const chuteGroup = new THREE.Group();
  const canopy = new THREE.Mesh(
    new THREE.SphereGeometry(2.1, 14, 8, 0, Math.PI * 2, 0, Math.PI * 0.48),
    new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.7,
      side: THREE.DoubleSide,
    }),
  );
  canopy.position.set(0, 3.8, 0);
  chuteGroup.add(canopy);

  const cordMat = new THREE.MeshBasicMaterial({ color: 0x94a3b8 });
  for (const [cx, cz] of [
    [-0.5, -0.5],
    [0.5, -0.5],
    [-0.5, 0.5],
    [0.5, 0.5],
  ]) {
    const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 3.4, 4), cordMat);
    cord.position.set(cx * 1.1, 2.55, cz * 1.1);
    cord.rotation.z = -cx * 0.35;
    cord.rotation.x = cz * 0.35;
    chuteGroup.add(cord);
  }
  root.add(chuteGroup);

  return { root, chuteGroup, flareMesh };
}

/**
 * Friendly / Player ACU Soldier Avatar matching reference (i_c3d8d8ab.webp) + Tactical Backpack ("Sumka")
 */
export function buildFriendlySoldierMesh(
  isPlayer: boolean,
  contactShadowTex: THREE.CanvasTexture,
): {
  root: THREE.Group;
  headMesh: THREE.Mesh;
  torsoMesh: THREE.Mesh;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  armL: THREE.Mesh;
  armR: THREE.Mesh;
  backpackMesh: THREE.Mesh;
} {
  const built = buildEnemyMesh('infantry', contactShadowTex);
  const { root, headMesh, torsoMesh, legL, legR, armL, armR } = built;

  // Add Tactical Level-3 Backpack ("Sumka") on back
  const bagMat = new THREE.MeshStandardMaterial({
    color: isPlayer ? 0x3f4d3a : 0x3b4d5e,
    roughness: 0.78,
    metalness: 0.1,
  });
  const backpackMesh = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.48, 0.2), bagMat);
  backpackMesh.position.set(0, 1.2, -0.23);
  backpackMesh.castShadow = true;
  root.add(backpackMesh);

  // Squad Identifier Patch (Emerald for Player, Cyan-Blue for Squadmates)
  const patchMat = new THREE.MeshStandardMaterial({
    color: isPlayer ? 0x10b981 : 0x38bdf8,
    emissive: isPlayer ? 0x059669 : 0x0284c7,
    emissiveIntensity: 0.85,
  });
  const patchL = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.1, 0.08), patchMat);
  patchL.position.set(-0.27, 1.38, 0);
  const patchR = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.1, 0.08), patchMat);
  patchR.position.set(0.27, 1.38, 0);
  root.add(patchL, patchR);

  return { root, headMesh, torsoMesh, legL, legR, armL, armR, backpackMesh };
}

/**
 * Crashed Military Cargo Plane Silhouette for PUBG-Style Lobby Backdrop (i_6e8364ca.webp right side)
 */
export function buildLobbyPlaneWreck(metalMat: THREE.Material): THREE.Group {
  const g = new THREE.Group();
  const fuselage = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.45, 11.5, 10), metalMat);
  fuselage.rotation.z = Math.PI / 2 - 0.16;
  fuselage.position.set(0, 1.25, 0);
  g.add(fuselage);

  const wing = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.2, 11.0), metalMat);
  wing.position.set(0.5, 2.2, 0.8);
  wing.rotation.x = 0.12;
  wing.rotation.y = 0.25;
  g.add(wing);

  const tailFin = new THREE.Mesh(new THREE.BoxGeometry(2.2, 2.8, 0.22), metalMat);
  tailFin.position.set(-4.8, 2.9, 0);
  tailFin.rotation.z = 0.28;
  g.add(tailFin);

  return g;
}


