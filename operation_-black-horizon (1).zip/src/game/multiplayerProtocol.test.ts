import assert from 'node:assert/strict';
import test from 'node:test';
import {
  buildInviteUrl,
  isValidTargetKills,
  normalizeRoomCode,
  resolveDuelWinner,
} from './multiplayerProtocol.ts';

test('target kills marra accepts only 10, 20, 30, or 40', () => {
  assert.equal(isValidTargetKills(10), true);
  assert.equal(isValidTargetKills(20), true);
  assert.equal(isValidTargetKills(30), true);
  assert.equal(isValidTargetKills(40), true);
  assert.equal(isValidTargetKills(15), false);
  assert.equal(isValidTargetKills(0), false);
});

test('room code normalization strips symbols and uppercases', () => {
  assert.equal(normalizeRoomCode(' b h 4 2 ! '), 'BH42');
  assert.equal(normalizeRoomCode('ab12cd99'), 'AB12CD');
});

test('buildInviteUrl constructs hotspot-ready join link cleanly', () => {
  assert.equal(
    buildInviteUrl('http://192.168.43.1:3000/', 'bh42'),
    'http://192.168.43.1:3000/?room=BH42',
  );
});

test('resolveDuelWinner resolves target marra and timeout draw/win accurately', () => {
  assert.equal(resolveDuelWinner(9, 8, 10, 120), null);
  assert.equal(resolveDuelWinner(10, 8, 10, 120), 1);
  assert.equal(resolveDuelWinner(14, 30, 30, 50), 2);
  assert.equal(resolveDuelWinner(22, 22, 40, 0), 'draw');
  assert.equal(resolveDuelWinner(25, 21, 40, 0), 1);
});
