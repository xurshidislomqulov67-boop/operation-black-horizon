import React, { useEffect, useState } from 'react';
import { Backpack, Eye, Pause, Volume2, VolumeX } from 'lucide-react';
import type { HudSnapshot } from '../game/types';
import { loadCutoutSpriteUrl } from '../utils/cutoutSprite';

interface TacticalHudProps {
  hud: HudSnapshot;
  onToggleMute: () => void;
  onPause: () => void;
  onOpenSettings: () => void;
  onTogglePerspective: () => void;
  onReviveAlly: () => void;
  onOpenBag: () => void;
}

const CARDINALS: { deg: number; label: string }[] = [
  { deg: 0, label: 'N' },
  { deg: 45, label: 'NE' },
  { deg: 90, label: 'E' },
  { deg: 135, label: 'SE' },
  { deg: 180, label: 'S' },
  { deg: 225, label: 'SW' },
  { deg: 270, label: 'W' },
  { deg: 315, label: 'NW' },
];

function signedAngleDiff(targetDeg: number, currentDeg: number): number {
  let diff = ((targetDeg - currentDeg + 540) % 360) - 180;
  if (diff < -180) diff += 180;
  return diff;
}

function formatClock(sec: number): string {
  const s = Math.max(0, Math.ceil(sec));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}:${String(rem).padStart(2, '0')}`;
}

/**
 * Custom SVG icon matching the pineapple frag grenade reference (49ad719e...)
 */
const FragGrenadeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
    <rect x="9" y="2" width="6" height="4" rx="1" fill="#9ca3af" stroke="#18181b" strokeWidth="1" />
    <circle cx="16.5" cy="5.5" r="2.2" stroke="#d4d4d8" strokeWidth="1.4" />
    <rect x="8.5" y="6" width="7" height="2" fill="#eab308" />
    <ellipse cx="12" cy="14.5" rx="5.5" ry="6.8" fill="#5b6640" stroke="#18181b" strokeWidth="1.3" />
    <path d="M7.5 12H16.5M7 15H17M8.5 18H15.5M12 8.5V20.5" stroke="#2f3620" strokeWidth="1.1" />
  </svg>
);

/**
 * Custom SVG icon matching PUBG Mobile First Aid Kit ("Aptechka")
 */
const AptechkaIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
    <path d="M9 5V3.5C9 3 9.4 2.5 10 2.5H14C14.6 2.5 15 3 15 3.5V5" stroke="#d4d4d8" strokeWidth="1.5" />
    <rect x="3.5" y="5.5" width="17" height="14" rx="2" fill="#e7e5e4" stroke="#18181b" strokeWidth="1.4" />
    <rect x="10.5" y="8.5" width="3" height="8" rx="0.5" fill="#dc2626" />
    <rect x="8" y="11" width="8" height="3" rx="0.5" fill="#dc2626" />
  </svg>
);

export const TacticalHud: React.FC<TacticalHudProps> = ({
  hud,
  onToggleMute,
  onPause,
  onOpenSettings,
  onTogglePerspective,
  onReviveAlly,
  onOpenBag,
}) => {
  const [airdropIconUrl, setAirdropIconUrl] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    void loadCutoutSpriteUrl('/assets/aistudio/pubg_box_5f08a978.png', {
      maxChroma: 26,
      minLuma: 125,
    }).then((url) => {
      if (alive) setAirdropIconUrl(url);
    });
    return () => {
      alive = false;
    };
  }, []);

  const healthRatio = Math.max(0, Math.min(1, hud.hp / hud.maxHp));
  const lowHpBloodAlpha = healthRatio < 0.72 ? (0.72 - healthRatio) * 0.95 : 0;
  const bloodAlpha = Math.min(0.88, Math.max(lowHpBloodAlpha, hud.damageFlashAlpha * 0.65));
  const showAmmo = hud.ammoRevealTimer > 0 || hud.isReloading || hud.magAmmo <= 5;
  const totalLoaded = hud.magAmmo + (hud.chambered ? 1 : 0);

  // Heading radians to rotate world blips so forward is always UP on minimap
  const headingRad = (hud.headingDeg * Math.PI) / 180;
  const cosH = Math.cos(headingRad);
  const sinH = Math.sin(headingRad);

  return (
    <div className="fixed inset-0 z-10 pointer-events-none select-none overflow-hidden">
      {/* NVG Quad-Tube Phosphor Vignette (No backdrop-filter!) */}
      {hud.nvgActive && (
        <div
          className="fixed inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(circle at 50% 50%, rgba(34, 197, 94, 0.08) 0%, rgba(16, 185, 129, 0.14) 55%, rgba(2, 12, 6, 0.82) 92%)',
          }}
        />
      )}

      {/* Blood Vignette */}
      {bloodAlpha > 0.01 && (
        <div
          className="fixed inset-0 pointer-events-none transition-opacity duration-150"
          style={{
            opacity: bloodAlpha,
            background:
              'radial-gradient(circle at 50% 50%, rgba(127, 29, 29, 0) 42%, rgba(153, 27, 27, 0.55) 78%, rgba(69, 10, 10, 0.92) 100%)',
          }}
        />
      )}

      {/* Flashbang Stun Whiteout */}
      {hud.flashbangStunTimer > 0 && (
        <div
          className="fixed inset-0 pointer-events-none bg-stone-100"
          style={{ opacity: Math.min(0.85, hud.flashbangStunTimer * 0.55) }}
        />
      )}

      {/* Directional Damage Indicator Arc */}
      {hud.damageFlashAlpha > 0.05 && hud.damageDirRad !== null && (
        <div
          className="fixed left-1/2 top-1/2 w-56 h-56 -ml-28 -mt-28 pointer-events-none"
          style={{
            transform: `rotate(${hud.damageDirRad}rad)`,
            opacity: hud.damageFlashAlpha,
          }}
        >
          <svg viewBox="0 0 100 100" className="w-full h-full">
            <path
              d="M 28 14 Q 50 4 72 14"
              fill="none"
              stroke="#ef4444"
              strokeWidth="4.5"
              strokeLinecap="round"
            />
          </svg>
        </div>
      )}

      {/* TOP-CENTER: 1v1 Duel Scoreboard OR Arena 4v4 Scoreboard OR Bearing Compass + 60s Airdrop Timer */}
      <div className="fixed top-4 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5">
        {hud.duelScore ? (
          <div
            data-testid="duel-scoreboard"
            className="flex items-center gap-3 px-4 py-1.5 bg-neutral-950/90 border border-amber-400/70 font-mono uppercase"
          >
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-emerald-400 font-bold truncate max-w-24">
                {hud.duelScore.myName}
              </span>
              <span className="text-lg font-black text-emerald-300 tabular-nums">
                {hud.duelScore.myKills}
              </span>
            </div>
            <div className="flex flex-col items-center px-2.5 border-x border-stone-700/80">
              <span className="text-[11px] font-bold text-stone-100 tabular-nums">
                {formatClock(hud.duelScore.timeRemainingSec)}
              </span>
              <span className="text-[9px] text-amber-300 font-bold">
                MARRA {hud.duelScore.targetKills} · #{hud.duelScore.roomCode}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-lg font-black text-red-400 tabular-nums">
                {hud.duelScore.opponentKills}
              </span>
              <span className="text-[10px] text-red-400 font-bold truncate max-w-24">
                {hud.duelScore.opponentName}
              </span>
            </div>
          </div>
        ) : hud.arenaScore ? (
          <div
            data-testid="arena-scoreboard"
            className="flex items-center gap-3 px-4 py-1.5 bg-neutral-950/88 border border-stone-600/80 font-mono uppercase"
          >
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-sky-400 font-bold">BLUE</span>
              <span className="text-lg font-black text-sky-300 tabular-nums">
                {hud.arenaScore.blueKills}
              </span>
            </div>
            <div className="flex flex-col items-center px-2 border-x border-stone-700/80">
              <span className="text-[11px] font-bold text-stone-100 tabular-nums">
                {formatClock(hud.arenaScore.timeRemainingSec)}
              </span>
              <span className="text-[9px] text-stone-400">
                MARRA {hud.arenaScore.targetKills}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-lg font-black text-red-400 tabular-nums">
                {hud.arenaScore.redKills}
              </span>
              <span className="text-[10px] text-red-400 font-bold">RED</span>
            </div>
          </div>
        ) : (
          <div className="relative w-80 h-8 overflow-hidden border-b border-stone-500/40 bg-neutral-950/60">
            <div className="absolute left-1/2 top-0 w-px h-2 bg-emerald-400 -translate-x-1/2" />
            {CARDINALS.map((c) => {
              const diff = signedAngleDiff(c.deg, hud.headingDeg);
              if (Math.abs(diff) > 65) return null;
              const leftPct = 50 + (diff / 65) * 48;
              return (
                <span
                  key={c.label}
                  className="absolute top-2 -translate-x-1/2 text-[11px] font-mono font-bold text-stone-200 hud-text-shadow tabular-nums"
                  style={{ left: `${leftPct}%` }}
                >
                  {c.label}
                </span>
              );
            })}
            {(() => {
              const diff = signedAngleDiff(hud.objectiveBearingDeg, hud.headingDeg);
              const clamped = Math.max(-62, Math.min(62, diff));
              const leftPct = 50 + (clamped / 65) * 48;
              return (
                <div
                  className="absolute bottom-0.5 -translate-x-1/2 flex items-center gap-1"
                  style={{ left: `${leftPct}%` }}
                >
                  <span className="inline-block w-2 h-2 rotate-45 bg-amber-400 border border-neutral-950" />
                </div>
              );
            })()}
          </div>
        )}

        <div className="flex items-center gap-3 text-[11px] font-mono tracking-wider uppercase hud-text-shadow">
          <div className="flex items-center gap-1.5 text-stone-200">
            <span className="w-2 h-2 rotate-45 bg-amber-400 inline-block" />
            <span>{hud.objectiveLabel}</span>
            <span className="text-amber-300 tabular-nums">{hud.objectiveDistanceM}M</span>
          </div>
          <span className="text-stone-600">|</span>
          <div
            data-testid="airdrop-timer"
            className={`px-2 py-0.5 border font-bold tabular-nums ${
              hud.airdropStatus.activeDropCount > 0
                ? 'bg-red-950/85 border-sky-400 text-sky-300'
                : 'bg-neutral-950/80 border-stone-700 text-stone-300'
            }`}
          >
            {hud.airdropStatus.activeDropCount > 0 && hud.airdropStatus.nearestDropDistanceM !== null
              ? `AIRDROP ${hud.airdropStatus.nearestDropDistanceM}M · NEXT ${formatClock(hud.airdropStatus.nextDropInSec)}`
              : `AIRDROP IN ${formatClock(hud.airdropStatus.nextDropInSec)}`}
          </div>
        </div>

        {/* 60s Supply Airdrop Inbound Notification */}
        {hud.airdropStatus.justDroppedBannerSec > 0 && (
          <div className="mt-1 flex items-center gap-2.5 px-3.5 py-1.5 bg-neutral-950/92 border border-sky-400 text-sky-200 font-mono text-xs uppercase">
            {airdropIconUrl && (
              <img src={airdropIconUrl} alt="" className="w-6 h-6 object-contain" />
            )}
            <span className="font-bold text-amber-300">SUPPLY AIRDROP INBOUND</span>
            <span className="text-stone-300">APTECHKA &amp; O&apos;QDON DROPPED</span>
          </div>
        )}
      </div>

      {/* TOP-LEFT: 4-Squad Status (with HELP! Alerts) + Compact NVG / Stance / Camera */}
      <div className="fixed top-4 left-5 flex flex-col gap-2">
        {hud.teammates.length > 0 && (
          <div data-testid="squad-panel" className="flex flex-col gap-1 w-52">
            {hud.teammates.map((ally, idx) => {
              const allyHpPct = Math.max(0, Math.min(100, Math.round((ally.hp / ally.maxHp) * 100)));
              const isKnocked = ally.state === 'knocked';
              const isDead = ally.state === 'dead';
              return (
                <div
                  key={ally.id}
                  className={`px-2 py-1 border font-mono text-[10px] uppercase ${
                    isKnocked
                      ? 'bg-red-950/90 border-red-400 text-red-100 animate-pulse'
                      : isDead
                        ? 'bg-neutral-950/60 border-stone-800 text-stone-500'
                        : 'bg-neutral-950/80 border-stone-700/80 text-stone-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 font-bold">
                      <span
                        className={`inline-block w-2 h-2 rounded-full ${
                          isKnocked
                            ? 'bg-red-400'
                            : isDead
                              ? 'bg-stone-600'
                              : 'bg-sky-400'
                        }`}
                      />
                      <span>
                        {idx + 2}. {ally.callsign}
                      </span>
                    </span>
                    {isKnocked ? (
                      <span className="text-amber-300 font-black tabular-nums">
                        HELP! {Math.ceil(ally.knockedTimerSec)}s · {ally.distanceM}M
                      </span>
                    ) : isDead ? (
                      <span>KIA</span>
                    ) : (
                      <span className="text-stone-400 tabular-nums">{ally.distanceM}M</span>
                    )}
                  </div>
                  {!isDead && (
                    <div className="mt-1 w-full h-1 bg-neutral-800 overflow-hidden">
                      <div
                        className={`h-full ${isKnocked ? 'bg-red-500' : 'bg-sky-400'}`}
                        style={{ width: `${isKnocked ? Math.round((ally.knockedTimerSec / 26) * 100) : allyHpPct}%` }}
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <div className="flex flex-col gap-0.5 text-[11px] font-mono uppercase tracking-wider hud-text-shadow">
          <div className="flex items-center gap-2">
            <span className={hud.nvgActive ? 'text-emerald-400 font-bold' : 'text-stone-400'}>
              [N] NVG {hud.nvgActive ? `ON // ${hud.nvgBattery}%` : 'OFF'}
            </span>
          </div>
          <div className="text-stone-300">
            STANCE: <span className="text-stone-100">{hud.stance.replace('_', ' ')}</span>
          </div>
          <div className="text-sky-300">
            [V] VIEW: <span className="font-bold">{hud.cameraPerspective.toUpperCase()}</span>
          </div>
          {hud.isMounted ? (
            <div className="text-emerald-400 font-bold">MOUNTED // -65% RECOIL [Q]</div>
          ) : hud.canMount ? (
            <div className="text-amber-300">[Q] MOUNT WEAPON ON COVER</div>
          ) : null}
        </div>
      </div>

      {/* TOP-RIGHT: Utility Buttons ([V] TPP/FPP, ⚙️, Mute, Pause) + PUBG-Style Minimap */}
      <div className="fixed top-4 right-5 flex flex-col items-end gap-2">
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            type="button"
            tabIndex={-1}
            data-testid="hud-persp-btn"
            aria-label="Toggle 1st or 3rd Person Camera"
            onClick={(e) => {
              e.currentTarget.blur();
              onTogglePerspective();
            }}
            className="h-8 px-2.5 flex items-center gap-1 bg-neutral-950/85 hover:bg-neutral-800 border border-sky-500/70 text-sky-300 font-mono font-bold text-[11px] uppercase cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>[V] {hud.cameraPerspective.toUpperCase()}</span>
          </button>
          <button
            type="button"
            tabIndex={-1}
            aria-label="Settings"
            onClick={(e) => {
              e.currentTarget.blur();
              onOpenSettings();
            }}
            className="w-8 h-8 flex items-center justify-center bg-neutral-950/80 hover:bg-neutral-800 border border-stone-600/80 text-sm cursor-pointer"
          >
            <span aria-hidden="true">⚙️</span>
          </button>
          <button
            type="button"
            tabIndex={-1}
            aria-label={hud.isMuted ? 'Unmute audio' : 'Mute audio'}
            onClick={(e) => {
              e.currentTarget.blur();
              onToggleMute();
            }}
            className="w-8 h-8 flex items-center justify-center bg-neutral-950/80 hover:bg-neutral-800 border border-stone-600/80 text-stone-200 cursor-pointer"
          >
            {hud.isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <button
            type="button"
            tabIndex={-1}
            aria-label="Pause mission"
            onClick={(e) => {
              e.currentTarget.blur();
              onPause();
            }}
            className="w-8 h-8 flex items-center justify-center bg-neutral-950/80 hover:bg-neutral-800 border border-stone-600/80 text-stone-200 cursor-pointer"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>

        {/* Compact PUBG-Style Tactical Minimap Radar (112x112px) */}
        <div
          data-testid="tactical-minimap"
          className="relative w-28 h-28 bg-neutral-950/85 border border-stone-600/80 overflow-hidden"
        >
          <div className="absolute inset-x-0 top-1/2 h-px bg-stone-700/40" />
          <div className="absolute inset-y-0 left-1/2 w-px bg-stone-700/40" />
          <div className="absolute inset-3 rounded-full border border-stone-700/40" />

          <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full">
            <polygon points="50,50 32,18 68,18" fill="rgba(52, 211, 153, 0.14)" />
            <polygon points="50,43 45,54 50,51 55,54" fill="#34d399" />
          </svg>

          {hud.minimapBlips.map((b, idx) => {
            const rx = b.x * cosH + b.z * sinH;
            const rz = -b.x * sinH + b.z * cosH;
            const scale = 1.25;
            const px = Math.max(6, Math.min(106, 56 + rx * scale));
            const py = Math.max(6, Math.min(106, 56 + rz * scale));

            if (b.kind === 'objective') {
              return (
                <div
                  key={`obj-${idx}`}
                  className="absolute w-2.5 h-2.5 bg-amber-400 border border-neutral-950 rotate-45 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${px}px`, top: `${py}px` }}
                />
              );
            }
            if (b.kind === 'airdrop') {
              return (
                <div
                  key={`drop-${idx}`}
                  className="absolute w-3 h-3 bg-red-500 border-2 border-sky-400 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${px}px`, top: `${py}px` }}
                />
              );
            }
            if (b.kind === 'ally') {
              return (
                <div
                  key={`ally-${idx}`}
                  className="absolute w-2 h-2 rounded-full bg-sky-400 border border-neutral-950 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${px}px`, top: `${py}px` }}
                />
              );
            }
            if (b.kind === 'ally_knocked') {
              return (
                <div
                  key={`allyk-${idx}`}
                  className="absolute w-3 h-3 rounded-full bg-amber-400 border border-red-600 -translate-x-1/2 -translate-y-1/2 animate-pulse"
                  style={{ left: `${px}px`, top: `${py}px` }}
                />
              );
            }
            if (b.kind === 'loot') {
              return (
                <div
                  key={`loot-${idx}`}
                  className="absolute w-2 h-2 bg-emerald-400 border border-neutral-950 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${px}px`, top: `${py}px` }}
                />
              );
            }
            if (b.kind === 'grenade') {
              return (
                <div
                  key={`gren-${idx}`}
                  className="absolute w-2.5 h-2.5 rounded-full bg-orange-400 border border-red-600 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${px}px`, top: `${py}px` }}
                />
              );
            }
            return (
              <div
                key={`en-${idx}`}
                className="absolute w-2 h-2 rounded-full bg-red-500 border border-neutral-950 -translate-x-1/2 -translate-y-1/2"
                style={{ left: `${px}px`, top: `${py}px` }}
              />
            );
          })}
          <span className="absolute bottom-0.5 right-1 text-[8px] font-mono text-stone-400">
            RADAR
          </span>
        </div>
      </div>

      {/* CENTER RETICLE */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
        {!hud.isAds && hud.stance !== 'tactical_sprint' && (
          <svg viewBox="0 0 36 36" className="w-9 h-9 opacity-80">
            <circle cx="18" cy="18" r="1.2" fill="#f5f5f4" />
            <path
              d="M18 6V11M18 25V30M6 18H11M25 18H30"
              stroke="#f5f5f4"
              strokeWidth="1.4"
              strokeLinecap="square"
            />
          </svg>
        )}
        {hud.hitMarkerTimer > 0 && (
          <svg viewBox="0 0 36 36" className="w-9 h-9 absolute inset-0">
            <path
              d="M9 9L14 14M27 9L22 14M9 27L14 22M27 27L22 22"
              stroke={hud.hitMarkerHeadshot ? '#ef4444' : '#f5f5f4'}
              strokeWidth="2"
              strokeLinecap="square"
            />
          </svg>
        )}
      </div>

      {/* INCOMING FRAG GRENADE WARNING */}
      {hud.incomingGrenade && (
        <div className="fixed left-1/2 top-28 -translate-x-1/2 flex items-center gap-2 px-3.5 py-1.5 bg-red-950/90 border border-red-500 text-red-100 font-mono text-xs uppercase">
          <FragGrenadeIcon className="w-4 h-4" />
          <span className="font-bold">FRAG GRENADE · {hud.incomingGrenade.distanceM}M</span>
          <span className="text-amber-300 tabular-nums">
            {hud.incomingGrenade.fuseRemainingSec.toFixed(1)}S
          </span>
        </div>
      )}

      {/* REVIVE KNOCKED TEAMMATE ("HELP!" -> KO'TARISH / REVIVE) BUTTON & PROGRESS */}
      {hud.nearbyKnockedAlly && (
        <div className="fixed left-1/2 bottom-44 -translate-x-1/2 flex flex-col items-center gap-2 pointer-events-auto">
          {hud.nearbyKnockedAlly.isReviving && (
            <div className="w-60 bg-neutral-950/92 border border-sky-400 p-2">
              <div className="flex justify-between text-[10px] font-mono uppercase text-sky-300 mb-1">
                <span>KO&apos;TARILMOQDA // REVIVING {hud.nearbyKnockedAlly.callsign}</span>
                <span className="tabular-nums">
                  {Math.round(hud.nearbyKnockedAlly.progress * 100)}%
                </span>
              </div>
              <div className="w-full h-1.5 bg-neutral-800">
                <div
                  className="h-full bg-sky-400 transition-all duration-75"
                  style={{ width: `${Math.round(hud.nearbyKnockedAlly.progress * 100)}%` }}
                />
              </div>
            </div>
          )}
          <button
            type="button"
            tabIndex={-1}
            data-testid="revive-btn"
            onClick={(e) => {
              e.currentTarget.blur();
              onReviveAlly();
            }}
            className="flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-mono font-black text-xs uppercase tracking-wider border border-amber-200 cursor-pointer"
          >
            <span aria-hidden="true">🤝</span>
            <span>
              KO&apos;TARISH / REVIVE {hud.nearbyKnockedAlly.callsign} [F] ·{' '}
              {Math.ceil(hud.nearbyKnockedAlly.bleedoutSec)}s
            </span>
          </button>
        </div>
      )}

      {/* APTECHKA / BANDAGE HEALING CAST BAR */}
      {hud.isHealing && (
        <div className="fixed left-1/2 bottom-56 -translate-x-1/2 w-56 bg-neutral-950/90 border border-emerald-500/70 p-2">
          <div className="flex justify-between text-[10px] font-mono uppercase text-emerald-300 mb-1">
            <span>{hud.healKind === 'medkit' ? 'APPLYING APTECHKA...' : 'BANDAGING...'}</span>
            <span className="tabular-nums">{Math.round(hud.healProgress * 100)}%</span>
          </div>
          <div className="w-full h-1.5 bg-neutral-800">
            <div
              className="h-full bg-emerald-400 transition-all duration-75"
              style={{ width: `${Math.round(hud.healProgress * 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* CONTEXTUAL LOOT CRATE / BREACH / INTERACT PROMPT */}
      {hud.interactPrompt && (
        <div className="fixed left-1/2 bottom-32 -translate-x-1/2 px-4 py-1.5 bg-neutral-950/88 border border-amber-400/75 text-amber-300 font-mono text-xs tracking-wider uppercase hud-text-shadow">
          {hud.interactPrompt}
        </div>
      )}

      {/* RADIO COMMS TRANSCRIPT */}
      {hud.activeComms && (
        <div className="fixed left-1/2 bottom-16 -translate-x-1/2 w-[min(600px,86vw)] px-4 py-2 bg-neutral-950/85 border-l-2 border-emerald-400">
          <div className="text-[10px] font-mono tracking-[0.2em] uppercase text-emerald-400">
            {hud.activeComms.callsign}
          </div>
          <div className="mt-0.5 text-xs md:text-sm text-stone-100 leading-snug">
            {hud.activeComms.text}
          </div>
        </div>
      )}

      {/* BOTTOM-LEFT: PUBG-Style Compact Mini Inventory, Sumka Button & Vitality Bar */}
      <div
        data-testid="mini-inventory"
        className="fixed bottom-4 left-5 flex flex-col gap-1.5"
      >
        <div className="flex items-center gap-2 bg-neutral-950/80 border border-stone-700/80 px-2.5 py-1 w-60">
          <span className="text-[10px] font-mono font-bold text-stone-300">HP</span>
          <div className="flex-1 h-2 bg-neutral-800 overflow-hidden">
            <div
              className={`h-full transition-all duration-150 ${
                healthRatio > 0.5
                  ? 'bg-stone-100'
                  : healthRatio > 0.28
                    ? 'bg-amber-400'
                    : 'bg-red-500'
              }`}
              style={{ width: `${Math.round(healthRatio * 100)}%` }}
            />
          </div>
          <span className="text-xs font-mono font-bold text-stone-100 tabular-nums w-7 text-right">
            {hud.hp}
          </span>
        </div>

        <div className="flex items-center gap-1.5 font-mono text-[10px] uppercase">
          <button
            type="button"
            tabIndex={-1}
            data-testid="hud-bag-btn"
            onClick={(e) => {
              e.currentTarget.blur();
              onOpenBag();
            }}
            className="pointer-events-auto flex items-center gap-1 px-2 py-1 border bg-neutral-950/90 hover:bg-neutral-800 border-amber-400/70 text-amber-300 font-bold cursor-pointer"
          >
            <Backpack className="w-3.5 h-3.5" />
            <span>[TAB] BAG</span>
          </button>
          <div
            className={`px-2 py-1 border ${
              hud.weaponId === 'mk18_suppressed'
                ? 'bg-emerald-950/85 border-emerald-400 text-emerald-300 font-bold'
                : 'bg-neutral-950/80 border-stone-700 text-stone-400'
            }`}
          >
            [1] MK18
          </div>
          <div
            className={`px-2 py-1 border ${
              hud.weaponId === 'p226_suppressed'
                ? 'bg-emerald-950/85 border-emerald-400 text-emerald-300 font-bold'
                : 'bg-neutral-950/80 border-stone-700 text-stone-400'
            }`}
          >
            [2] P226
          </div>
          <div
            className={`flex items-center gap-1 px-2 py-1 border ${
              hud.grenadeCount > 0
                ? 'bg-neutral-950/85 border-amber-500/70 text-amber-200'
                : 'bg-neutral-950/70 border-stone-800 text-stone-500'
            }`}
          >
            <FragGrenadeIcon className="w-3.5 h-3.5" />
            <span>[G] {hud.grenadeCount}</span>
          </div>
          <div
            className={`flex items-center gap-1 px-2 py-1 border ${
              hud.medkitCount > 0
                ? 'bg-neutral-950/85 border-red-400/70 text-stone-100'
                : 'bg-neutral-950/70 border-stone-800 text-stone-500'
            }`}
          >
            <AptechkaIcon className="w-3.5 h-3.5" />
            <span>[H] {hud.medkitCount}</span>
          </div>
          {hud.bandageCount > 0 && (
            <div className="px-2 py-1 border bg-neutral-950/80 border-stone-700 text-stone-300">
              [5] BDG {hud.bandageCount}
            </div>
          )}
        </div>
      </div>

      {/* BOTTOM-RIGHT DIEGETIC AMMO CHECK */}
      <div
        className="fixed bottom-4 right-5 text-right transition-opacity duration-300"
        style={{ opacity: showAmmo ? 1 : 0.72 }}
      >
        <div className="text-[10px] font-mono tracking-[0.22em] uppercase text-stone-400 hud-text-shadow">
          {hud.weaponName}
        </div>
        <div className="mt-0.5 flex items-baseline justify-end gap-1.5 tabular-nums hud-text-shadow">
          {hud.isReloading ? (
            <span className="text-xl font-mono font-bold text-amber-400 tracking-widest">
              RELOADING
            </span>
          ) : (
            <>
              <span className="text-3xl font-black font-mono text-stone-100">
                {totalLoaded}
              </span>
              <span className="text-sm font-mono text-stone-400">/ {hud.reserveAmmo}</span>
            </>
          )}
        </div>
        <div className="text-[10px] font-mono text-stone-400 uppercase tracking-wider">
          [R] RELOAD · [G] FRAG · [H] APTECHKA · [V] {hud.cameraPerspective.toUpperCase()}
        </div>
      </div>
    </div>
  );
};
