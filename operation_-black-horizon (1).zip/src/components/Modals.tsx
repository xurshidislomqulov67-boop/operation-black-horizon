import React, { useEffect, useState } from 'react';
import { Backpack, FileCode2, Play, RotateCcw, ShieldCheck, Skull, X } from 'lucide-react';
import {
  MISSION_1_BREACH_DOORS,
  MISSION_1_SPAWNS,
  MISSION_1_TRIGGERS,
} from '../game/mission1Script';
import { MODULE_1_UE5_ARCHITECTURE } from '../game/ue5ArchitectureDocs';
import {
  DEFAULT_GAME_SETTINGS,
  type GameSettings,
  type HudSnapshot,
  type WeaponId,
} from '../game/types';
import { loadCutoutSpriteUrl } from '../utils/cutoutSprite';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onOpenSettings: () => void;
  onOpenDossier: () => void;
  onTitle: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onOpenSettings,
  onOpenDossier,
  onTitle,
}) => {
  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-neutral-950/80 p-6">
      <div className="w-full max-w-md bg-neutral-900 border border-stone-700 p-7">
        <div className="text-[11px] font-mono tracking-[0.25em] uppercase text-emerald-400">
          OPERATION: BLACK HORIZON
        </div>
        <h2 className="mt-1 text-2xl font-black tracking-tight uppercase text-stone-100">
          MISSION PAUSED
        </h2>

        <div className="mt-6 flex flex-col gap-3">
          <button
            type="button"
            onClick={onResume}
            className="w-full flex items-center justify-center gap-2 py-3 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold tracking-[0.14em] uppercase text-xs cursor-pointer"
          >
            <Play className="w-4 h-4" />
            RESUME MISSION
          </button>
          <button
            type="button"
            onClick={onRestart}
            className="w-full flex items-center justify-center gap-2 py-3 bg-neutral-800 hover:bg-neutral-700 border border-stone-600 text-stone-100 font-semibold tracking-[0.12em] uppercase text-xs cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            RESTART MATCH
          </button>
          <button
            type="button"
            aria-label="Settings"
            onClick={onOpenSettings}
            className="w-full flex items-center justify-center gap-2 py-3 bg-neutral-800 hover:bg-neutral-700 border border-stone-600 text-stone-100 font-semibold tracking-[0.12em] uppercase text-xs cursor-pointer"
          >
            <span aria-hidden="true">⚙️</span>
            SENSITIVITY &amp; AUDIO
          </button>
          <button
            type="button"
            onClick={onOpenDossier}
            className="w-full flex items-center justify-center gap-2 py-3 bg-neutral-800 hover:bg-neutral-700 border border-stone-600 text-emerald-300 font-semibold tracking-[0.12em] uppercase text-xs cursor-pointer"
          >
            <FileCode2 className="w-4 h-4" />
            MODULE 1: SCRIPT &amp; UE5 C++
          </button>
          <button
            type="button"
            onClick={onTitle}
            className="w-full py-2.5 text-stone-400 hover:text-stone-200 font-mono uppercase text-xs tracking-widest cursor-pointer"
          >
            RETURN TO LOBBY
          </button>
        </div>
      </div>
    </div>
  );
};

interface GameOverModalProps {
  hud: HudSnapshot;
  onRestart: () => void;
  onRematch?: () => void;
  onOpenDossier: () => void;
  onTitle: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  hud,
  onRestart,
  onRematch,
  onOpenDossier,
  onTitle,
}) => {
  const isVictory = hud.outcome === 'victory';
  const isDraw = hud.outcome === 'draw';
  const isArena = hud.gameMode === 'arena_4v4' && hud.arenaScore !== null;
  const isDuel = hud.gameMode === 'duel_1v1' && hud.duelScore !== null;
  const accuracy =
    hud.shotsFired > 0 ? Math.round((hud.shotsHit / hud.shotsFired) * 100) : 0;
  const mins = Math.floor(hud.elapsedSec / 60);
  const secs = Math.floor(hud.elapsedSec % 60);
  const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

  return (
    <div className="fixed inset-0 z-30 flex items-center justify-center bg-neutral-950/85 p-6">
      <div className="w-full max-w-lg bg-neutral-900 border border-stone-700 p-8">
        <div className="flex items-center gap-3">
          {isVictory || isDraw ? (
            <ShieldCheck className={`w-7 h-7 ${isDraw ? 'text-amber-400' : 'text-emerald-400'}`} />
          ) : (
            <Skull className="w-7 h-7 text-red-500" />
          )}
          <div>
            <div className="text-[11px] font-mono tracking-[0.25em] uppercase text-stone-400">
              {isDuel
                ? `1v1 HOTSPOT DUEL // MARRA ${hud.duelScore?.targetKills ?? 20}`
                : isArena
                  ? 'ARENA 4V4 // TEAM DEATHMATCH'
                  : 'CLASSIC SQUAD // NIGHTFALL IN KASHGAR'}
            </div>
            <h2
              className={`text-2xl font-black tracking-tight uppercase ${
                isDraw ? 'text-amber-400' : isVictory ? 'text-emerald-400' : 'text-red-500'
              }`}
            >
              {isDuel
                ? isDraw
                  ? 'DRAW // DURRANG'
                  : isVictory
                    ? "G'ALABA // YOU WIN"
                    : "MAG'LUBIYAT // RIVAL WINS"
                : isArena
                  ? isVictory
                    ? 'BLUE SQUAD VICTORY'
                    : 'RED TEAM VICTORY'
                  : isVictory
                    ? 'EXFILTRATION COMPLETE'
                    : 'OPERATOR DOWN'}
            </h2>
          </div>
        </div>

        {isDuel && hud.duelScore && (
          <div className="mt-5 flex items-center justify-center gap-6 py-3 bg-neutral-950 border border-amber-400/50 font-mono">
            <div className="text-center">
              <div className="text-[10px] text-emerald-400 uppercase">{hud.duelScore.myName}</div>
              <div className="text-3xl font-black text-emerald-300 tabular-nums">
                {hud.duelScore.myKills}
              </div>
            </div>
            <div className="text-stone-500 font-bold text-lg">VS</div>
            <div className="text-center">
              <div className="text-[10px] text-red-400 uppercase">
                {hud.duelScore.opponentName}
              </div>
              <div className="text-3xl font-black text-red-400 tabular-nums">
                {hud.duelScore.opponentKills}
              </div>
            </div>
          </div>
        )}

        {isArena && hud.arenaScore && (
          <div className="mt-5 flex items-center justify-center gap-6 py-3 bg-neutral-950 border border-stone-700 font-mono">
            <div className="text-center">
              <div className="text-[10px] text-sky-400 uppercase">BLUE SQUAD</div>
              <div className="text-3xl font-black text-sky-300 tabular-nums">
                {hud.arenaScore.blueKills}
              </div>
            </div>
            <div className="text-stone-500 font-bold text-lg">VS</div>
            <div className="text-center">
              <div className="text-[10px] text-red-400 uppercase">RED TEAM</div>
              <div className="text-3xl font-black text-red-400 tabular-nums">
                {hud.arenaScore.redKills}
              </div>
            </div>
          </div>
        )}

        <div className="mt-5 grid grid-cols-3 gap-3">
          <div className="bg-neutral-950 border border-stone-800 p-3">
            <div className="text-[10px] font-mono uppercase text-stone-400">TIME</div>
            <div className="mt-1 text-xl font-mono font-bold text-stone-100 tabular-nums">
              {timeStr}
            </div>
          </div>
          <div className="bg-neutral-950 border border-stone-800 p-3">
            <div className="text-[10px] font-mono uppercase text-stone-400">KILLS</div>
            <div className="mt-1 text-xl font-mono font-bold text-stone-100 tabular-nums">
              {hud.kills} ({hud.headshots} HS)
            </div>
          </div>
          <div className="bg-neutral-950 border border-stone-800 p-3">
            <div className="text-[10px] font-mono uppercase text-stone-400">ACCURACY</div>
            <div className="mt-1 text-xl font-mono font-bold text-stone-100 tabular-nums">
              {accuracy}%
            </div>
          </div>
        </div>

        <div className="mt-3 text-xs font-mono uppercase text-stone-400">
          {isDuel
            ? `CAMERA: ${hud.cameraPerspective.toUpperCase()} · ROOM #${hud.duelScore?.roomCode ?? '----'} · MARRA ${hud.duelScore?.targetKills ?? 20}`
            : isArena
              ? `CAMERA: ${hud.cameraPerspective.toUpperCase()} · MARRA: ${hud.arenaScore?.targetKills ?? 20} ELIMINATIONS`
              : `OBJECTIVE PROGRESS: PHASE ${Math.min(hud.phaseIndex + (isVictory ? 1 : 0), hud.totalPhases)} / ${hud.totalPhases} · BREACHES: ${hud.breachesCompleted} · STEALTH: ${hud.stealthAlerted ? 'COMPROMISED' : 'GHOST'}`}
        </div>

        <div className="mt-7 flex flex-wrap gap-3">
          <button
            type="button"
            data-start="true"
            onClick={isDuel && onRematch ? onRematch : onRestart}
            className="flex-1 py-3 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold tracking-[0.14em] uppercase text-xs cursor-pointer"
          >
            {isDuel ? 'REMATCH 1v1' : isVictory ? 'PLAY AGAIN' : 'TRY AGAIN'}
          </button>
          <button
            type="button"
            onClick={onOpenDossier}
            className="px-4 py-3 bg-neutral-800 hover:bg-neutral-700 border border-stone-600 text-stone-100 font-semibold tracking-[0.1em] uppercase text-xs cursor-pointer"
          >
            UE5 DOSSIER
          </button>
          <button
            type="button"
            onClick={onTitle}
            className="px-4 py-3 text-stone-400 hover:text-stone-200 font-mono uppercase text-xs cursor-pointer"
          >
            LOBBY
          </button>
        </div>
      </div>
    </div>
  );
};

interface BackpackModalProps {
  hud: HudSnapshot;
  inMatch: boolean;
  onEquipWeapon: (id: WeaponId) => void;
  onUseItem: (kind: 'medkit' | 'bandage') => void;
  onClose: () => void;
}

export const BackpackModal: React.FC<BackpackModalProps> = ({
  hud,
  inMatch,
  onEquipWeapon,
  onUseItem,
  onClose,
}) => {
  const [airdropImgUrl, setAirdropImgUrl] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    void loadCutoutSpriteUrl('/assets/aistudio/pubg_box_5f08a978.png', {
      maxChroma: 26,
      minLuma: 125,
    }).then((url) => {
      if (alive) setAirdropImgUrl(url);
    });
    return () => {
      alive = false;
    };
  }, []);

  const capacityPct = Math.min(100, Math.round((hud.bagWeightKg / hud.bagMaxKg) * 100));

  return (
    <div
      data-testid="backpack-modal"
      className="fixed inset-0 z-40 flex items-center justify-center bg-neutral-950/85 p-4 md:p-6"
      role="dialog"
      aria-label="Tactical Backpack Sumka"
    >
      <div className="w-full max-w-2xl bg-neutral-900 border border-stone-600 p-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-400/15 border border-amber-400/60 flex items-center justify-center text-amber-400">
              <Backpack className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-mono tracking-[0.24em] uppercase text-amber-400">
                TACTICAL LOADOUT // SUMKA
              </div>
              <h2 className="text-lg font-black tracking-tight uppercase text-stone-100">
                BACKPACK &amp; FIELD SUPPLIES
              </h2>
            </div>
          </div>

          <button
            type="button"
            aria-label="Close Backpack"
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center bg-neutral-800 hover:bg-neutral-700 border border-stone-600 text-stone-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Bag Capacity Gauge */}
        <div className="mt-4 bg-neutral-950 border border-stone-800 p-3 font-mono text-xs">
          <div className="flex justify-between text-stone-300 mb-1.5">
            <span>SUMKA CAPACITY</span>
            <span className="text-amber-300 font-bold tabular-nums">
              {hud.bagWeightKg.toFixed(1)} / {hud.bagMaxKg} KG ({capacityPct}%)
            </span>
          </div>
          <div className="w-full h-2 bg-neutral-800 overflow-hidden">
            <div
              className="h-full bg-amber-400 transition-all duration-150"
              style={{ width: `${capacityPct}%` }}
            />
          </div>
        </div>

        {/* Weapons & Supplies Grid */}
        <div className="mt-4 grid md:grid-cols-2 gap-4 font-mono text-xs">
          {/* Weapons Column */}
          <div className="bg-neutral-950 border border-stone-800 p-4 space-y-3">
            <div className="text-[10px] tracking-[0.2em] uppercase text-emerald-400 font-bold">
              EQUIPPED WEAPONS
            </div>

            <div
              className={`p-3 border ${
                hud.weaponId === 'mk18_suppressed'
                  ? 'border-emerald-400 bg-emerald-950/25'
                  : 'border-stone-800 bg-neutral-900'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-100">MK18 MOD 1 (SUPPRESSED)</span>
                <span className="text-[10px] text-stone-400">5.56x45mm</span>
              </div>
              <div className="mt-1.5 flex items-center justify-between text-[11px] text-stone-300">
                <span>O&apos;QDON (RESERVE): {hud.mk18ReserveAmmo}</span>
                {hud.weaponId === 'mk18_suppressed' ? (
                  <span className="text-emerald-400 font-bold">ACTIVE [1]</span>
                ) : (
                  <button
                    type="button"
                    disabled={!inMatch}
                    onClick={() => onEquipWeapon('mk18_suppressed')}
                    className="px-2 py-1 bg-emerald-500 disabled:bg-stone-800 text-neutral-950 disabled:text-stone-500 font-bold uppercase text-[10px] cursor-pointer disabled:cursor-default"
                  >
                    EQUIP
                  </button>
                )}
              </div>
            </div>

            <div
              className={`p-3 border ${
                hud.weaponId === 'p226_suppressed'
                  ? 'border-emerald-400 bg-emerald-950/25'
                  : 'border-stone-800 bg-neutral-900'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-100">P226 TACOPS (SUPPRESSED)</span>
                <span className="text-[10px] text-stone-400">9x19mm</span>
              </div>
              <div className="mt-1.5 flex items-center justify-between text-[11px] text-stone-300">
                <span>O&apos;QDON (RESERVE): {hud.p226ReserveAmmo}</span>
                {hud.weaponId === 'p226_suppressed' ? (
                  <span className="text-emerald-400 font-bold">ACTIVE [2]</span>
                ) : (
                  <button
                    type="button"
                    disabled={!inMatch}
                    onClick={() => onEquipWeapon('p226_suppressed')}
                    className="px-2 py-1 bg-emerald-500 disabled:bg-stone-800 text-neutral-950 disabled:text-stone-500 font-bold uppercase text-[10px] cursor-pointer disabled:cursor-default"
                  >
                    EQUIP
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Consumables & Gear Column */}
          <div className="bg-neutral-950 border border-stone-800 p-4 space-y-2.5">
            <div className="text-[10px] tracking-[0.2em] uppercase text-amber-400 font-bold">
              MEDICAL &amp; ORDNANCE
            </div>

            <div className="flex items-center justify-between p-2.5 bg-neutral-900 border border-stone-800">
              <div>
                <div className="font-bold text-stone-100">APTECHKA (FIRST AID KIT)</div>
                <div className="text-[10px] text-stone-400">QTY: {hud.medkitCount} · +75 HP [H]</div>
              </div>
              <button
                type="button"
                disabled={!inMatch || hud.medkitCount <= 0 || hud.hp >= hud.maxHp}
                onClick={() => onUseItem('medkit')}
                className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 disabled:bg-stone-800 text-neutral-950 disabled:text-stone-500 font-bold uppercase text-[10px] cursor-pointer disabled:cursor-default"
              >
                USE
              </button>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-neutral-900 border border-stone-800">
              <div>
                <div className="font-bold text-stone-100">TACTICAL BANDAGE</div>
                <div className="text-[10px] text-stone-400">QTY: {hud.bandageCount} · +30 HP [5]</div>
              </div>
              <button
                type="button"
                disabled={!inMatch || hud.bandageCount <= 0 || hud.hp >= hud.maxHp}
                onClick={() => onUseItem('bandage')}
                className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 disabled:bg-stone-800 text-neutral-950 disabled:text-stone-500 font-bold uppercase text-[10px] cursor-pointer disabled:cursor-default"
              >
                USE
              </button>
            </div>

            <div className="flex items-center justify-between p-2.5 bg-neutral-900 border border-stone-800">
              <div>
                <div className="font-bold text-stone-100">M67 FRAG GRENADE</div>
                <div className="text-[10px] text-stone-400">PRESS [G] TO THROW</div>
              </div>
              <span className="text-amber-300 font-bold text-sm tabular-nums">
                x{hud.grenadeCount}
              </span>
            </div>
          </div>
        </div>

        {/* 60s Airdrop Box Legend */}
        <div className="mt-4 flex items-center justify-between gap-4 bg-neutral-950 border border-sky-500/40 p-3 font-mono text-[11px]">
          <div className="flex items-center gap-3">
            {airdropImgUrl && (
              <img
                src={airdropImgUrl}
                alt="60s PUBG Supply Drop"
                className="w-12 h-12 object-contain shrink-0"
              />
            )}
            <div>
              <div className="text-sky-300 font-bold uppercase">
                60S SUPPLY AIRDROP CRATE (HAR 1 MINUTDA)
              </div>
              <div className="text-stone-400 text-[10px]">
                CONTAINS +2 APTECHKA · +2 BANDAGES · +90 O&apos;QDON (AMMO) · +2 FRAG GRENADES
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black uppercase text-xs cursor-pointer shrink-0"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};

interface DossierModalProps {
  onClose: () => void;
}

export const DossierModal: React.FC<DossierModalProps> = ({ onClose }) => {
  const [tab, setTab] = useState<'script' | 'cpp' | 'blueprint'>('script');

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-neutral-950/92 p-4 md:p-8">
      <div className="w-full max-w-5xl h-[88vh] bg-neutral-900 border border-stone-700 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-800">
          <div>
            <div className="text-[11px] font-mono tracking-[0.24em] uppercase text-emerald-400">
              MODULE 1 PRODUCTION ARCHITECTURE // OPERATION: BLACK HORIZON
            </div>
            <h2 className="text-lg font-black tracking-tight uppercase text-stone-100">
              MISSION 1 SCRIPT, SPAWN TELEMETRY &amp; UE5 C++ SYSTEMS
            </h2>
          </div>
          <button
            type="button"
            aria-label="Close Module 1 Dossier"
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center bg-neutral-800 hover:bg-neutral-700 border border-stone-600 text-stone-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-stone-800 px-6 gap-2 bg-neutral-950/60">
          <button
            type="button"
            onClick={() => setTab('script')}
            className={`px-4 py-3 text-xs font-mono uppercase tracking-wider border-b-2 cursor-pointer ${
              tab === 'script'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            Mission 1 Script &amp; Coordinates
          </button>
          <button
            type="button"
            onClick={() => setTab('cpp')}
            className={`px-4 py-3 text-xs font-mono uppercase tracking-wider border-b-2 cursor-pointer ${
              tab === 'cpp'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            UE5 C++ &amp; Ballistics Math
          </button>
          <button
            type="button"
            onClick={() => setTab('blueprint')}
            className={`px-4 py-3 text-xs font-mono uppercase tracking-wider border-b-2 cursor-pointer ${
              tab === 'blueprint'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-stone-400 hover:text-stone-200'
            }`}
          >
            Blueprint &amp; AnimBP Graph
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm text-stone-200">
          {tab === 'script' && (
            <>
              <div>
                <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-emerald-400 mb-3">
                  TRIGGER ZONES, LIGHTING CUES &amp; LINE-BY-LINE DIALOGUE
                </h3>
                <div className="space-y-4">
                  {MISSION_1_TRIGGERS.map((trg) => (
                    <div
                      key={trg.id}
                      className="bg-neutral-950 border border-stone-800 p-4 space-y-2"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-mono font-bold text-amber-300 text-xs">
                          {trg.id} // {trg.label}
                        </span>
                        <span className="font-mono text-[11px] text-stone-400 tabular-nums">
                          POS: ({trg.position.join(', ')}) · R={trg.radiusM}m
                        </span>
                      </div>
                      <div className="text-xs text-stone-400">
                        <strong className="text-stone-300">LIGHTING CUE:</strong> {trg.lightingCue}
                      </div>
                      <div className="text-xs text-stone-400">
                        <strong className="text-stone-300">AUDIO CUE:</strong> {trg.audioCue}
                      </div>
                      <div className="pt-2 border-t border-stone-800/80 space-y-1.5">
                        {trg.commsSequence.map((line) => (
                          <div key={line.id} className="text-xs leading-relaxed">
                            <span className="font-mono text-emerald-400 mr-2">
                              [{line.id}] {line.callsign}:
                            </span>
                            <span className="text-stone-100">&ldquo;{line.text}&rdquo;</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-neutral-950 border border-stone-800 p-4">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-emerald-400 mb-2">
                    ENEMY SPAWN COORDINATES (XYZ METERS)
                  </h4>
                  <div className="space-y-1.5 text-xs font-mono">
                    {MISSION_1_SPAWNS.map((sp) => (
                      <div key={sp.id} className="flex justify-between text-stone-300">
                        <span>
                          {sp.id} ({sp.archetype})
                        </span>
                        <span className="text-stone-400 tabular-nums">
                          ({sp.position.join(', ')})
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-neutral-950 border border-stone-800 p-4">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-emerald-400 mb-2">
                    BREACHABLE DOORWAY COORDINATES
                  </h4>
                  <div className="space-y-1.5 text-xs font-mono">
                    {MISSION_1_BREACH_DOORS.map((d) => (
                      <div key={d.id} className="flex justify-between text-stone-300">
                        <span>
                          {d.id} {d.locked ? '[LOCKED]' : '[UNLOCKED]'}
                        </span>
                        <span className="text-stone-400 tabular-nums">
                          ({d.position.join(', ')})
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}

          {tab === 'cpp' && (
            <div className="space-y-6">
              {MODULE_1_UE5_ARCHITECTURE.filter((s) => s.codeLanguage === 'cpp').map((sec) => (
                <div key={sec.id} className="bg-neutral-950 border border-stone-800 p-5 space-y-4">
                  <div>
                    <h3 className="text-sm font-bold text-emerald-400 uppercase">{sec.title}</h3>
                    <p className="text-xs text-stone-400 mt-0.5">{sec.subtitle}</p>
                  </div>
                  {sec.formulas && (
                    <div className="grid md:grid-cols-3 gap-3">
                      {sec.formulas.map((f) => (
                        <div key={f.name} className="bg-neutral-900 border border-stone-800 p-3">
                          <div className="text-[11px] font-mono uppercase text-amber-300">
                            {f.name}
                          </div>
                          <div className="mt-1 font-mono text-xs text-stone-100 break-words">
                            {f.equation}
                          </div>
                          <p className="mt-1.5 text-[11px] text-stone-400 leading-snug">
                            {f.explanation}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                  <pre className="p-4 bg-neutral-900 border border-stone-800 text-xs font-mono text-stone-200 overflow-x-auto leading-relaxed">
                    {sec.code}
                  </pre>
                </div>
              ))}
            </div>
          )}

          {tab === 'blueprint' && (
            <div className="space-y-6">
              {MODULE_1_UE5_ARCHITECTURE.filter((s) => s.codeLanguage === 'blueprint').map(
                (sec) => (
                  <div
                    key={sec.id}
                    className="bg-neutral-950 border border-stone-800 p-5 space-y-3"
                  >
                    <div>
                      <h3 className="text-sm font-bold text-emerald-400 uppercase">{sec.title}</h3>
                      <p className="text-xs text-stone-400 mt-0.5">{sec.subtitle}</p>
                    </div>
                    <pre className="p-4 bg-neutral-900 border border-stone-800 text-xs font-mono text-emerald-200 overflow-x-auto leading-relaxed">
                      {sec.code}
                    </pre>
                  </div>
                ),
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

interface SettingsModalProps {
  settings: GameSettings;
  onChange: (next: GameSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onChange,
  onClose,
}) => {
  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-neutral-950/85 p-6"
      role="dialog"
      aria-label="Sensitivity and Control Settings"
    >
      <div className="w-full max-w-md bg-neutral-900 border border-stone-700 p-7">
        <div className="flex items-center justify-between border-b border-stone-800 pb-4">
          <div className="flex items-center gap-2.5">
            <span className="text-xl" aria-hidden="true">⚙️</span>
            <div>
              <div className="text-[10px] font-mono tracking-[0.24em] uppercase text-emerald-400">
                SENSITIVITY &amp; OPTICS
              </div>
              <h2 className="text-lg font-black tracking-tight uppercase text-stone-100">
                TACTICAL CONTROLS
              </h2>
            </div>
          </div>
          <button
            type="button"
            aria-label="Close Settings"
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center bg-neutral-800 hover:bg-neutral-700 border border-stone-600 text-stone-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-5 space-y-4 text-xs font-mono uppercase">
          {/* General Look Sensitivity */}
          <div>
            <div className="flex justify-between text-stone-300 mb-1.5">
              <label htmlFor="look-sens">LOOK SENSITIVITY</label>
              <span className="text-emerald-400 tabular-nums font-bold">
                {settings.lookSensitivity.toFixed(2)}x
              </span>
            </div>
            <input
              id="look-sens"
              type="range"
              min="0.3"
              max="2.5"
              step="0.05"
              value={settings.lookSensitivity}
              onChange={(e) =>
                onChange({ ...settings, lookSensitivity: parseFloat(e.target.value) })
              }
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* ADS Scope Sensitivity */}
          <div>
            <div className="flex justify-between text-stone-300 mb-1.5">
              <label htmlFor="ads-sens">ADS / SCOPE SENSITIVITY</label>
              <span className="text-emerald-400 tabular-nums font-bold">
                {settings.adsSensitivity.toFixed(2)}x
              </span>
            </div>
            <input
              id="ads-sens"
              type="range"
              min="0.3"
              max="2.0"
              step="0.05"
              value={settings.adsSensitivity}
              onChange={(e) =>
                onChange({ ...settings, adsSensitivity: parseFloat(e.target.value) })
              }
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* Field of View */}
          <div>
            <div className="flex justify-between text-stone-300 mb-1.5">
              <label htmlFor="fov-slider">FIELD OF VIEW (FOV)</label>
              <span className="text-emerald-400 tabular-nums font-bold">
                {Math.round(settings.fov)}°
              </span>
            </div>
            <input
              id="fov-slider"
              type="range"
              min="65"
              max="95"
              step="1"
              value={settings.fov}
              onChange={(e) =>
                onChange({ ...settings, fov: parseFloat(e.target.value) })
              }
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* Master Audio Volume */}
          <div>
            <div className="flex justify-between text-stone-300 mb-1.5">
              <label htmlFor="vol-slider">MASTER VOLUME</label>
              <span className="text-emerald-400 tabular-nums font-bold">
                {Math.round(settings.masterVolume * 100)}%
              </span>
            </div>
            <input
              id="vol-slider"
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.masterVolume}
              onChange={(e) =>
                onChange({ ...settings, masterVolume: parseFloat(e.target.value) })
              }
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* Invert Y-Axis */}
          <div className="flex items-center justify-between pt-2 border-t border-stone-800">
            <span className="text-stone-300">INVERT Y-AXIS</span>
            <button
              type="button"
              onClick={() => onChange({ ...settings, invertY: !settings.invertY })}
              className={`px-3 py-1.5 border font-bold cursor-pointer ${
                settings.invertY
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                  : 'bg-neutral-800 border-stone-600 text-stone-400'
              }`}
            >
              {settings.invertY ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>

        <div className="mt-6 flex items-center gap-3">
          <button
            type="button"
            onClick={() => onChange({ ...DEFAULT_GAME_SETTINGS })}
            className="px-4 py-2.5 bg-neutral-800 hover:bg-neutral-700 border border-stone-600 text-stone-300 text-xs font-mono uppercase cursor-pointer"
          >
            RESET
          </button>
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold tracking-[0.14em] uppercase text-xs cursor-pointer"
          >
            DONE
          </button>
        </div>
      </div>
    </div>
  );
};
