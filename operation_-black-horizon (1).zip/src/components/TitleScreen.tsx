import React, { useEffect, useState } from 'react';
import { Backpack, Check, Copy, Eye, FileCode2, Shield, Users, Wifi } from 'lucide-react';
import {
  MATCH_DURATION_OPTIONS,
  TARGET_KILLS_OPTIONS,
  buildInviteUrl,
  normalizeRoomCode,
  type MultiplayerRoomState,
  type TargetKillsOption,
} from '../game/multiplayerProtocol';
import type { CameraPerspective, GameMode } from '../game/types';
import { loadCutoutSpriteUrl } from '../utils/cutoutSprite';

interface TitleScreenProps {
  gameMode: GameMode;
  cameraPerspective: CameraPerspective;
  targetKills: TargetKillsOption;
  durationSec: number;
  playerName: string;
  joinCode: string;
  roomState: MultiplayerRoomState | null;
  inviteBaseUrl: string;
  lanUrls: string[];
  duelError: string | null;
  wsConnected: boolean;
  onChangePlayerName: (name: string) => void;
  onChangeJoinCode: (code: string) => void;
  onSelectMode: (mode: GameMode) => void;
  onSelectPerspective: (persp: CameraPerspective) => void;
  onSelectTargetKills: (target: TargetKillsOption) => void;
  onSelectDurationSec: (sec: number) => void;
  onCreateRoom: () => void;
  onJoinRoom: () => void;
  onLeaveRoom: () => void;
  onStartDuel: () => void;
  onStart: () => void;
  onOpenSettings: () => void;
  onOpenBag: () => void;
  onOpenDossier: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  gameMode,
  cameraPerspective,
  targetKills,
  durationSec,
  playerName,
  joinCode,
  roomState,
  inviteBaseUrl,
  lanUrls,
  duelError,
  wsConnected,
  onChangePlayerName,
  onChangeJoinCode,
  onSelectMode,
  onSelectPerspective,
  onSelectTargetKills,
  onSelectDurationSec,
  onCreateRoom,
  onJoinRoom,
  onLeaveRoom,
  onStartDuel,
  onStart,
  onOpenSettings,
  onOpenBag,
  onOpenDossier,
}) => {
  const [soldierAvatarUrl, setSoldierAvatarUrl] = useState<string | null>(null);
  const [airdropBoxUrl, setAirdropBoxUrl] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    let alive = true;
    void loadCutoutSpriteUrl('/assets/aistudio/i_c3d8d8ab.webp', {
      maxChroma: 26,
      minLuma: 150,
    }).then((url) => {
      if (alive) setSoldierAvatarUrl(url);
    });
    void loadCutoutSpriteUrl('/assets/aistudio/pubg_box_5f08a978.png', {
      maxChroma: 26,
      minLuma: 125,
    }).then((url) => {
      if (alive) setAirdropBoxUrl(url);
    });
    return () => {
      alive = false;
    };
  }, []);

  const preferredInviteOrigin =
    lanUrls.length > 0 && /localhost|127\.0\.0\.1/.test(inviteBaseUrl)
      ? lanUrls[0]
      : inviteBaseUrl;
  const inviteLink = roomState ? buildInviteUrl(preferredInviteOrigin, roomState.code) : '';
  const connectedCount = roomState ? roomState.players.filter((p) => p.connected).length : 0;
  const isHost = roomState?.mySlot === 1;
  const canStartDuel = Boolean(roomState && isHost && connectedCount >= 2);

  const handleCopyInvite = async () => {
    if (!inviteLink) return;
    try {
      await navigator.clipboard.writeText(inviteLink);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 1800);
    } catch {
      // Clipboard fallback ignored in restricted frames
    }
  };

  return (
    <div className="fixed inset-0 z-20 flex flex-col justify-between p-5 md:p-7 pointer-events-none select-none">
      {/* Subtle framing vignette keeping the center 3D soldier avatar crisp & unobstructed */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at 50% 48%, rgba(6, 10, 15, 0) 32%, rgba(6, 10, 15, 0.56) 100%)',
        }}
      />

      {/* TOP BAR (PUBG Mobile Lobby Style: Profile + Squad on Left, Currency + Icon-only ⚙️ on Right) */}
      <div className="relative z-10 flex items-start justify-between gap-4 pointer-events-auto">
        {/* Top-Left: Soldier Avatar Profile Card + 4-Operator Squad */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3 bg-neutral-950/85 border border-stone-600/80 px-3 py-2">
            <div className="w-11 h-11 bg-neutral-900 border border-amber-400/70 overflow-hidden shrink-0 flex items-center justify-center">
              {soldierAvatarUrl ? (
                <img
                  src={soldierAvatarUrl}
                  alt="Operator Avatar"
                  className="w-full h-full object-cover object-top scale-125"
                />
              ) : (
                <Shield className="w-5 h-5 text-amber-400" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black tracking-wide uppercase text-stone-100">
                  {playerName || 'SPECTER-01'}
                </span>
                <span className="px-1.5 py-0.5 bg-amber-400/20 border border-amber-400/50 text-[10px] font-mono text-amber-300">
                  TIER 1
                </span>
              </div>
              <div className="text-[10px] font-mono uppercase text-stone-400">
                OPERATION: BLACK HORIZON
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-neutral-950/80 border border-stone-700/80 px-2.5 py-1.5 text-[10px] font-mono uppercase">
            <Users className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            {gameMode === 'duel_1v1' ? (
              <span className="text-sky-300 font-bold">
                1v1 HOTSPOT DUEL · MARRA {roomState?.targetKills ?? targetKills}
              </span>
            ) : (
              <>
                <span className="text-emerald-300 font-bold">SQUAD 4/4:</span>
                <span className="text-stone-200">YOU · DAGGER-2 · VIPER-3 · GHOST-4</span>
              </>
            )}
          </div>
        </div>

        {/* Top-Right: Tactical Credits + Icon-Only ⚙️ Settings Button (Zero "Sozlamalar/Settings" text) */}
        <div className="flex items-center gap-2.5">
          <div className="hidden sm:flex items-center gap-3 bg-neutral-950/85 border border-stone-700/80 px-3 py-2 text-xs font-mono">
            <span className="text-amber-400 font-bold">BP 14,500</span>
            <span className="text-stone-600">|</span>
            <span className="text-emerald-400 font-bold">60S AIRDROP</span>
          </div>

          <button
            type="button"
            aria-label="Settings"
            data-testid="settings-btn"
            onClick={(e) => {
              e.currentTarget.blur();
              onOpenSettings();
            }}
            className="w-11 h-11 inline-flex items-center justify-center bg-neutral-950/90 hover:bg-neutral-800 border border-stone-500/80 text-xl transition-colors cursor-pointer"
          >
            <span aria-hidden="true">⚙️</span>
          </button>

          <button
            type="button"
            aria-label="UE5 Architecture Dossier"
            onClick={(e) => {
              e.currentTarget.blur();
              onOpenDossier();
            }}
            className="w-11 h-11 inline-flex items-center justify-center bg-neutral-950/90 hover:bg-neutral-800 border border-stone-600/80 text-emerald-400 transition-colors cursor-pointer"
          >
            <FileCode2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* MIDDLE AREA: Left = 1v1 Hotspot Room Panel (when duel_1v1 active), Right = Supply Airdrop Card */}
      <div className="relative z-10 flex items-center justify-between gap-4 my-auto">
        {gameMode === 'duel_1v1' ? (
          <div
            data-testid="duel-room-panel"
            className="w-[min(360px,92vw)] bg-neutral-950/92 border border-sky-500/60 p-3.5 pointer-events-auto font-mono text-xs space-y-2.5"
          >
            <div className="flex items-center justify-between border-b border-stone-800 pb-2">
              <div className="flex items-center gap-2 text-sky-300 font-bold uppercase">
                <Wifi className="w-4 h-4" />
                <span>1v1 HOTSPOT / MULTIPLAYER</span>
              </div>
              <span
                className={`text-[10px] font-bold ${
                  wsConnected ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {wsConnected ? 'ONLINE' : 'ULANMOQDA...'}
              </span>
            </div>

            {/* Player Callsign */}
            <div className="flex items-center gap-2">
              <label htmlFor="duel-name" className="text-[10px] text-stone-400 uppercase shrink-0">
                ISMINGIZ:
              </label>
              <input
                id="duel-name"
                type="text"
                maxLength={16}
                value={playerName}
                onChange={(e) => onChangePlayerName(e.target.value)}
                disabled={Boolean(roomState)}
                className="flex-1 bg-neutral-900 border border-stone-700 px-2 py-1 text-stone-100 text-xs uppercase focus:outline-none focus:border-sky-400 disabled:opacity-60"
              />
            </div>

            {!roomState ? (
              <div className="space-y-2.5">
                <button
                  type="button"
                  data-testid="host-room-btn"
                  onClick={onCreateRoom}
                  className="w-full py-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black uppercase tracking-wider cursor-pointer"
                >
                  XONA OCHISH (HOTSPOT HOST)
                </button>

                <div className="flex items-center gap-1.5 pt-1 border-t border-stone-800">
                  <input
                    type="text"
                    data-testid="join-code-input"
                    placeholder="KOD (MASALAN: BH42)"
                    maxLength={6}
                    value={joinCode}
                    onChange={(e) => onChangeJoinCode(normalizeRoomCode(e.target.value))}
                    className="flex-1 bg-neutral-900 border border-stone-700 px-2.5 py-1.5 text-stone-100 text-xs uppercase tracking-widest focus:outline-none focus:border-sky-400"
                  />
                  <button
                    type="button"
                    data-testid="join-room-btn"
                    onClick={onJoinRoom}
                    disabled={joinCode.length < 3}
                    className="px-3 py-1.5 bg-sky-500 hover:bg-sky-400 disabled:bg-stone-800 text-neutral-950 disabled:text-stone-500 font-bold uppercase cursor-pointer"
                  >
                    KIRISH
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between bg-neutral-900 border border-stone-700 px-2.5 py-2">
                  <div>
                    <div className="text-[10px] text-stone-400 uppercase">XONA KODI</div>
                    <div
                      data-testid="room-code-display"
                      className="text-xl font-black text-amber-300 tracking-[0.22em]"
                    >
                      {roomState.code}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyInvite}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 border border-stone-600 text-stone-100 text-[10px] uppercase cursor-pointer"
                  >
                    {copiedLink ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>NUSXALANDI</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-amber-400" />
                        <span>LINK NUSXALASH</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Hotspot / Invite Link Preview */}
                <div className="text-[10px] text-stone-400 break-all bg-neutral-900/70 px-2 py-1 border border-stone-800">
                  HOTSPOT LINK: <span className="text-sky-300">{inviteLink}</span>
                </div>

                {/* Players 2/2 Status */}
                <div className="space-y-1">
                  {[1, 2].map((slot) => {
                    const p = roomState.players.find((pl) => pl.slot === slot);
                    return (
                      <div
                        key={slot}
                        className={`flex items-center justify-between px-2 py-1 border text-[11px] ${
                          p?.connected
                            ? 'bg-emerald-950/30 border-emerald-500/40 text-stone-100'
                            : 'bg-neutral-900 border-stone-800 text-stone-500'
                        }`}
                      >
                        <span>
                          {slot}. {p ? p.name : "DO'ST ULANISHI KUTILMOQDA..."}
                        </span>
                        <span className={p?.connected ? 'text-emerald-400' : 'text-amber-400'}>
                          {p?.connected ? 'TAYYOR ✓' : 'KUTILMOQDA'}
                        </span>
                      </div>
                    );
                  })}
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] text-stone-400">
                    {isHost
                      ? connectedCount < 2
                        ? "Do'stingiz kod yoki link orqali kirsin (1/2)"
                        : "Ikkala o'yinchi tayyor (2/2)!"
                      : 'Host o‘yinni boshlashini kuting...'}
                  </span>
                  <button
                    type="button"
                    onClick={onLeaveRoom}
                    className="text-[10px] text-red-400 hover:text-red-300 underline uppercase cursor-pointer"
                  >
                    CHIQISH
                  </button>
                </div>
              </div>
            )}

            {duelError && (
              <div className="px-2 py-1 bg-red-950/80 border border-red-500/70 text-red-200 text-[10px]">
                {duelError}
              </div>
            )}
          </div>
        ) : (
          <div />
        )}

        {/* Right: PUBG-Style Airdrop Supply Preview Card (pubg_box_5f08a978.png) */}
        <div className="hidden md:flex w-52 bg-neutral-950/85 border border-sky-500/50 p-3 flex-col gap-2 pointer-events-auto">
          <div className="flex items-center justify-between text-[10px] font-mono uppercase">
            <span className="text-sky-300 font-bold">SUPPLY AIRDROP</span>
            <span className="text-red-400 font-bold">EVERY 1:00</span>
          </div>
          <div className="h-24 bg-neutral-900/90 border border-stone-800 flex items-center justify-center overflow-hidden">
            {airdropBoxUrl ? (
              <img
                src={airdropBoxUrl}
                alt="PUBG Supply Airdrop Crate"
                className="h-20 w-auto object-contain"
              />
            ) : (
              <span className="text-xs font-mono text-stone-400">AIRDROP CRATE</span>
            )}
          </div>
          <div className="text-[10px] font-mono text-stone-300 leading-snug">
            +2 APTECHKA · +90 AMMO · +2 FRAG
          </div>
        </div>
      </div>

      {/* BOTTOM BAR (PUBG Mobile Layout: Left = Mode Selector + Marra 10/20/30/40 + Yellow START; Right = Sumka) */}
      <div className="relative z-10 flex flex-wrap items-end justify-between gap-4 pointer-events-auto">
        <div className="flex flex-col gap-2.5">
          <div className="bg-neutral-950/92 border border-stone-600/80 p-2.5 flex flex-col gap-2 w-80">
            {/* Game Mode Tabs: CLASSIC vs ARENA 4v4 vs 1v1 HOTSPOT */}
            <div className="grid grid-cols-3 gap-1.5 text-[10px] font-mono uppercase">
              <button
                type="button"
                data-testid="mode-classic"
                onClick={() => onSelectMode('classic')}
                className={`py-2 px-1.5 border font-bold tracking-wider cursor-pointer transition-colors ${
                  gameMode === 'classic'
                    ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                    : 'bg-neutral-900 border-stone-700 text-stone-400 hover:text-stone-200'
                }`}
              >
                CLASSIC
              </button>
              <button
                type="button"
                data-testid="mode-arena"
                onClick={() => onSelectMode('arena_4v4')}
                className={`py-2 px-1.5 border font-bold tracking-wider cursor-pointer transition-colors ${
                  gameMode === 'arena_4v4'
                    ? 'bg-sky-500/25 border-sky-400 text-sky-300'
                    : 'bg-neutral-900 border-stone-700 text-stone-400 hover:text-stone-200'
                }`}
              >
                ARENA 4v4
              </button>
              <button
                type="button"
                data-testid="mode-duel"
                onClick={() => onSelectMode('duel_1v1')}
                className={`py-2 px-1.5 border font-bold tracking-wider cursor-pointer transition-colors ${
                  gameMode === 'duel_1v1'
                    ? 'bg-emerald-500/25 border-emerald-400 text-emerald-300'
                    : 'bg-neutral-900 border-stone-700 text-stone-400 hover:text-stone-200'
                }`}
              >
                1v1 HOTSPOT
              </button>
            </div>

            {/* Marra (Target Kills: 10 / 20 / 30 / 40) & Match Duration Selector */}
            {(gameMode === 'duel_1v1' || gameMode === 'arena_4v4') && (
              <div className="border-t border-stone-800 pt-2 space-y-1.5 text-[10px] font-mono uppercase">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-stone-400">MARRA (KILL):</span>
                  <div className="flex gap-1">
                    {TARGET_KILLS_OPTIONS.map((opt) => {
                      const active = (roomState?.targetKills ?? targetKills) === opt;
                      const lockedByGuest = Boolean(roomState && !isHost);
                      return (
                        <button
                          key={opt}
                          type="button"
                          data-testid={`marra-${opt}`}
                          disabled={lockedByGuest}
                          onClick={() => onSelectTargetKills(opt)}
                          className={`px-2 py-1 border font-bold cursor-pointer disabled:opacity-60 ${
                            active
                              ? 'bg-amber-400/25 border-amber-400 text-amber-300'
                              : 'bg-neutral-900 border-stone-700 text-stone-400 hover:text-stone-200'
                          }`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2">
                  <span className="text-stone-400">DAVOMIYLIGI:</span>
                  <div className="flex gap-1">
                    {MATCH_DURATION_OPTIONS.map((d) => {
                      const active = (roomState?.durationSec ?? durationSec) === d.sec;
                      const lockedByGuest = Boolean(roomState && !isHost);
                      return (
                        <button
                          key={d.sec}
                          type="button"
                          data-testid={`dur-${d.sec}`}
                          disabled={lockedByGuest}
                          onClick={() => onSelectDurationSec(d.sec)}
                          className={`px-1.5 py-1 border font-bold cursor-pointer disabled:opacity-60 ${
                            active
                              ? 'bg-sky-500/25 border-sky-400 text-sky-300'
                              : 'bg-neutral-900 border-stone-700 text-stone-400 hover:text-stone-200'
                          }`}
                        >
                          {d.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Perspective Selector: 3rd Person (TPP) vs 1st Person (FPP) */}
            <div className="flex items-center justify-between gap-2 text-[10px] font-mono uppercase border-t border-stone-800 pt-2">
              <span className="flex items-center gap-1.5 text-stone-400">
                <Eye className="w-3.5 h-3.5 text-emerald-400" />
                CAMERA [V]:
              </span>
              <div className="flex gap-1">
                <button
                  type="button"
                  data-testid="persp-tpp"
                  onClick={() => onSelectPerspective('tpp')}
                  className={`px-2.5 py-1 border font-bold cursor-pointer ${
                    cameraPerspective === 'tpp'
                      ? 'bg-emerald-500/25 border-emerald-400 text-emerald-300'
                      : 'bg-neutral-900 border-stone-700 text-stone-400'
                  }`}
                >
                  3RD (TPP)
                </button>
                <button
                  type="button"
                  data-testid="persp-fpp"
                  onClick={() => onSelectPerspective('fpp')}
                  className={`px-2.5 py-1 border font-bold cursor-pointer ${
                    cameraPerspective === 'fpp'
                      ? 'bg-emerald-500/25 border-emerald-400 text-emerald-300'
                      : 'bg-neutral-900 border-stone-700 text-stone-400'
                  }`}
                >
                  1ST (FPP)
                </button>
              </div>
            </div>
          </div>

          {/* Iconic Yellow/Gold PUBG START Button */}
          {gameMode === 'duel_1v1' ? (
            <button
              type="button"
              data-start="true"
              disabled={!canStartDuel}
              onClick={(e) => {
                e.currentTarget.blur();
                onStartDuel();
              }}
              className="w-80 py-3.5 bg-amber-400 hover:bg-amber-300 disabled:bg-stone-800 disabled:text-stone-500 text-neutral-950 font-black tracking-[0.16em] uppercase text-base border border-amber-200 disabled:border-stone-700 transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              {!roomState
                ? 'AVVAL XONA OCHING'
                : !isHost
                  ? 'HOST START KUTILMOQDA'
                  : connectedCount < 2
                    ? "DO'ST KUTILMOQDA (1/2)"
                    : `START 1v1 (MARRA ${roomState.targetKills})`}
            </button>
          ) : (
            <button
              type="button"
              data-start="true"
              onClick={(e) => {
                e.currentTarget.blur();
                onStart();
              }}
              className="w-80 py-3.5 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black tracking-[0.22em] uppercase text-lg border border-amber-200 transition-colors cursor-pointer"
            >
              START
            </button>
          )}
        </div>

        {/* Bottom-Right: Sumka / Bag & Quick Controls */}
        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              data-testid="lobby-bag-btn"
              onClick={(e) => {
                e.currentTarget.blur();
                onOpenBag();
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-neutral-950/90 hover:bg-neutral-800 border border-stone-600 text-stone-100 font-mono font-bold text-xs uppercase tracking-wider cursor-pointer"
            >
              <Backpack className="w-4 h-4 text-amber-400" />
              BAG (SUMKA)
            </button>
          </div>
          <div className="text-[10px] font-mono tracking-wider text-stone-400 uppercase hud-text-shadow">
            WASD Move · V TPP/FPP · Tab Sumka · G Frag · H Aptechka · F Loot/Revive · RMB ADS · LMB Fire
          </div>
        </div>
      </div>
    </div>
  );
};
