const cutoutCache = new Map<string, Promise<string>>();

/**
 * Removes connected outer studio/checkerboard background pixels via BFS edge flood-fill,
 * returning a clean transparent PNG data URL for crisp UI embedding without opaque boxes.
 */
export function loadCutoutSpriteUrl(
  src: string,
  options: { maxChroma?: number; minLuma?: number } = {},
): Promise<string> {
  const key = `${src}:${options.maxChroma ?? 24}:${options.minLuma ?? 155}`;
  const cached = cutoutCache.get(key);
  if (cached) return cached;

  const promise = new Promise<string>((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const w = img.naturalWidth || img.width;
        const h = img.naturalHeight || img.height;
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(src);
          return;
        }
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, w, h);
        const data = imageData.data;

        const maxChroma = options.maxChroma ?? 24;
        const minLuma = options.minLuma ?? 155;

        const isBg = (idx: number): boolean => {
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];
          const a = data[idx + 3];
          if (a < 20) return true;
          const mx = Math.max(r, g, b);
          const mn = Math.min(r, g, b);
          const chroma = mx - mn;
          const luma = (r + g + b) / 3;
          return chroma <= maxChroma && luma >= minLuma;
        };

        const visited = new Uint8Array(w * h);
        const queue = new Int32Array(w * h);
        let head = 0;
        let tail = 0;

        const pushIfBg = (x: number, y: number) => {
          const p = y * w + x;
          if (visited[p]) return;
          const idx = p * 4;
          if (isBg(idx)) {
            visited[p] = 1;
            queue[tail++] = p;
          }
        };

        for (let x = 0; x < w; x++) {
          pushIfBg(x, 0);
          pushIfBg(x, h - 1);
        }
        for (let y = 0; y < h; y++) {
          pushIfBg(0, y);
          pushIfBg(w - 1, y);
        }

        while (head < tail) {
          const p = queue[head++];
          const idx = p * 4;
          data[idx + 3] = 0;
          const x = p % w;
          const y = (p - x) / w;
          if (x > 0) pushIfBg(x - 1, y);
          if (x + 1 < w) pushIfBg(x + 1, y);
          if (y > 0) pushIfBg(x, y - 1);
          if (y + 1 < h) pushIfBg(x, y + 1);
        }

        ctx.putImageData(imageData, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      } catch {
        resolve(src);
      }
    };
    img.onerror = () => resolve(src);
    img.src = src;
  });

  cutoutCache.set(key, promise);
  return promise;
}
