import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import { WebSocket, WebSocketServer } from 'ws';
import {
  clampDurationSec,
  generateRoomCode,
  isValidTargetKills,
  normalizeRoomCode,
  resolveDuelWinner,
} from './src/game/multiplayerProtocol.ts';
import type {
  ClientToServerMsg,
  MultiplayerRoomState,
  ServerToClientMsg,
  TargetKillsOption,
} from './src/game/multiplayerProtocol.ts';

interface PlayerSlot {
  slot: 1 | 2;
  name: string;
  kills: number;
  hp: number;
  respawnUntilMs: number;
  ws: WebSocket | null;
}

interface RoomRecord {
  code: string;
  status: 'waiting' | 'playing' | 'finished';
  targetKills: TargetKillsOption;
  durationSec: number;
  matchStartedAtMs: number;
  matchEndAtMs: number;
  winnerSlot: 1 | 2 | 'draw' | null;
  players: Map<1 | 2, PlayerSlot>;
}

const DEFAULT_PORT = Number(process.env.PORT || 3000);
const RESPAWN_DELAY_SEC = 2.5;

export interface StartServerOptions {
  port?: number;
  distDir?: string;
  forceProd?: boolean;
}

export interface RunningServer {
  httpServer: http.Server;
  wss: WebSocketServer;
  port: number;
  close: () => Promise<void>;
}

const rooms = new Map<string, RoomRecord>();
const socketSession = new WeakMap<WebSocket, { roomCode: string; slot: 1 | 2 }>();

function getTimeRemainingSec(room: RoomRecord, nowMs = Date.now()): number {
  if (room.status === 'waiting') return room.durationSec;
  if (room.status === 'finished') return Math.max(0, Math.ceil((room.matchEndAtMs - nowMs) / 1000));
  return Math.max(0, Math.ceil((room.matchEndAtMs - nowMs) / 1000));
}

function serializeRoom(room: RoomRecord, forSlot: 1 | 2 | null): MultiplayerRoomState {
  const players = ([1, 2] as const)
    .map((slot) => room.players.get(slot))
    .filter((p): p is PlayerSlot => Boolean(p))
    .map((p) => ({
      slot: p.slot,
      name: p.name,
      kills: p.kills,
      hp: p.hp,
      connected: Boolean(p.ws && p.ws.readyState === WebSocket.OPEN),
    }));

  return {
    code: room.code,
    status: room.status,
    targetKills: room.targetKills,
    durationSec: room.durationSec,
    timeRemainingSec: getTimeRemainingSec(room),
    mySlot: forSlot,
    winnerSlot: room.winnerSlot,
    players,
  };
}

function sendMsg(ws: WebSocket | null | undefined, msg: ServerToClientMsg): void {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify(msg));
}

function broadcastRoomState(room: RoomRecord, type: 'room_state' | 'match_started' | 'match_over' = 'room_state'): void {
  for (const player of room.players.values()) {
    sendMsg(player.ws, {
      type,
      room: serializeRoom(room, player.slot),
    });
  }
}

function getOpponent(room: RoomRecord, mySlot: 1 | 2): PlayerSlot | undefined {
  return room.players.get(mySlot === 1 ? 2 : 1);
}

function sanitizeName(raw: string, fallback: string): string {
  const cleaned = String(raw || '')
    .trim()
    .replace(/[^a-zA-Z0-9_\-\s']/g, '')
    .slice(0, 18);
  return cleaned || fallback;
}

function detachSocketFromRoom(ws: WebSocket): void {
  const session = socketSession.get(ws);
  if (!session) return;
  socketSession.delete(ws);

  const room = rooms.get(session.roomCode);
  if (!room) return;
  const player = room.players.get(session.slot);
  if (player && player.ws === ws) {
    player.ws = null;
  }

  const anyConnected = Array.from(room.players.values()).some(
    (p) => p.ws && p.ws.readyState === WebSocket.OPEN,
  );
  if (!anyConnected) {
    rooms.delete(room.code);
    return;
  }

  // If room was waiting and guest disconnected, free slot 2 so another friend can join
  if (room.status === 'waiting' && session.slot === 2) {
    room.players.delete(2);
  }
  broadcastRoomState(room, 'room_state');
}

function getLocalLanUrls(port: number): string[] {
  const urls: string[] = [];
  const nets = os.networkInterfaces();
  for (const iface of Object.values(nets)) {
    if (!iface) continue;
    for (const addr of iface) {
      if (addr.family === 'IPv4' && !addr.internal && !addr.address.startsWith('169.254.')) {
        urls.push(`http://${addr.address}:${port}`);
      }
    }
  }
  return Array.from(new Set(urls));
}

export async function startServer(options: StartServerOptions = {}): Promise<RunningServer> {
  const desiredPort = options.port ?? DEFAULT_PORT;
  const activeDistDir = options.distDir ?? path.resolve(process.cwd(), 'dist');
  const isProd = Boolean(options.forceProd) || process.env.NODE_ENV === 'production';

  let activePort = desiredPort;

  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, activeRooms: rooms.size, port: activePort });
  });

  app.get('/api/network-info', (req, res) => {
    const hostHeader = req.get('host') || `localhost:${activePort}`;
    const proto = req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
    res.json({
      lanUrls: getLocalLanUrls(activePort),
      originUrl: `${proto}://${hostHeader}`,
    });
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(activeDistDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(activeDistDir, 'index.html'));
    });
  }

  const httpServer = http.createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    ws.on('message', (raw) => {
      let msg: ClientToServerMsg;
      try {
        msg = JSON.parse(String(raw)) as ClientToServerMsg;
      } catch {
        sendMsg(ws, { type: 'error', message: 'Invalid message format.' });
        return;
      }

      if (msg.type === 'create_room') {
        detachSocketFromRoom(ws);
        const existingCodes = new Set(rooms.keys());
        const code = generateRoomCode(existingCodes);
        const targetKills: TargetKillsOption = isValidTargetKills(msg.targetKills)
          ? msg.targetKills
          : 20;
        const durationSec = clampDurationSec(msg.durationSec);

        const room: RoomRecord = {
          code,
          status: 'waiting',
          targetKills,
          durationSec,
          matchStartedAtMs: 0,
          matchEndAtMs: 0,
          winnerSlot: null,
          players: new Map(),
        };
        room.players.set(1, {
          slot: 1,
          name: sanitizeName(msg.playerName, 'HOST-01'),
          kills: 0,
          hp: 100,
          respawnUntilMs: 0,
          ws,
        });
        rooms.set(code, room);
        socketSession.set(ws, { roomCode: code, slot: 1 });
        broadcastRoomState(room, 'room_state');
        return;
      }

      if (msg.type === 'join_room') {
        detachSocketFromRoom(ws);
        const code = normalizeRoomCode(msg.code);
        const room = rooms.get(code);
        if (!room) {
          sendMsg(ws, { type: 'error', message: `Xona topilmadi: ${code || '????'}` });
          return;
        }

        const p1 = room.players.get(1);
        const p2 = room.players.get(2);

        // Allow reconnecting into an empty disconnected slot or taking Slot 2
        let assignedSlot: 1 | 2 | null = null;
        if (!p2 || !p2.ws || p2.ws.readyState !== WebSocket.OPEN) {
          assignedSlot = 2;
        } else if (!p1 || !p1.ws || p1.ws.readyState !== WebSocket.OPEN) {
          assignedSlot = 1;
        }

        if (!assignedSlot) {
          sendMsg(ws, { type: 'error', message: `Xona to'lgan (2/2): ${code}` });
          return;
        }

        const existing = room.players.get(assignedSlot);
        room.players.set(assignedSlot, {
          slot: assignedSlot,
          name: sanitizeName(msg.playerName, assignedSlot === 1 ? 'HOST-01' : "DO'ST-02"),
          kills: existing?.kills ?? 0,
          hp: existing?.hp ?? 100,
          respawnUntilMs: existing?.respawnUntilMs ?? 0,
          ws,
        });
        socketSession.set(ws, { roomCode: code, slot: assignedSlot });
        broadcastRoomState(room, room.status === 'playing' ? 'match_started' : 'room_state');
        return;
      }

      const session = socketSession.get(ws);
      if (!session) {
        sendMsg(ws, { type: 'error', message: 'Avval xona oching yoki xonaga kiring.' });
        return;
      }
      const room = rooms.get(session.roomCode);
      if (!room) {
        sendMsg(ws, { type: 'error', message: 'Xona mavjud emas.' });
        return;
      }

      if (msg.type === 'leave_room') {
        detachSocketFromRoom(ws);
        return;
      }

      if (msg.type === 'update_room_config') {
        if (session.slot !== 1 || room.status === 'playing') return;
        if (isValidTargetKills(msg.targetKills)) {
          room.targetKills = msg.targetKills;
        }
        room.durationSec = clampDurationSec(msg.durationSec);
        broadcastRoomState(room, 'room_state');
        return;
      }

      if (msg.type === 'start_match') {
        if (session.slot !== 1) return;
        const p1 = room.players.get(1);
        const p2 = room.players.get(2);
        if (!p1 || !p2 || !p2.ws || p2.ws.readyState !== WebSocket.OPEN) {
          sendMsg(ws, {
            type: 'error',
            message: "Do'stingiz ulanishini kuting (2/2 kerak).",
          });
          return;
        }
        const now = Date.now();
        room.status = 'playing';
        room.winnerSlot = null;
        room.matchStartedAtMs = now;
        room.matchEndAtMs = now + room.durationSec * 1000;
        p1.kills = 0;
        p1.hp = 100;
        p1.respawnUntilMs = 0;
        p2.kills = 0;
        p2.hp = 100;
        p2.respawnUntilMs = 0;
        broadcastRoomState(room, 'match_started');
        return;
      }

      if (msg.type === 'rematch') {
        const p1 = room.players.get(1);
        const p2 = room.players.get(2);
        if (!p1 || !p2 || !p2.ws || p2.ws.readyState !== WebSocket.OPEN) {
          room.status = 'waiting';
          broadcastRoomState(room, 'room_state');
          return;
        }
        const now = Date.now();
        room.status = 'playing';
        room.winnerSlot = null;
        room.matchStartedAtMs = now;
        room.matchEndAtMs = now + room.durationSec * 1000;
        p1.kills = 0;
        p1.hp = 100;
        p1.respawnUntilMs = 0;
        p2.kills = 0;
        p2.hp = 100;
        p2.respawnUntilMs = 0;
        broadcastRoomState(room, 'match_started');
        return;
      }

      if (room.status !== 'playing') return;

      if (msg.type === 'player_state') {
        const opp = getOpponent(room, session.slot);
        if (opp) {
          sendMsg(opp.ws, {
            type: 'remote_pose',
            pose: {
              slot: session.slot,
              ...msg.pose,
            },
          });
        }
        return;
      }

      if (msg.type === 'player_shot_fx') {
        const opp = getOpponent(room, session.slot);
        if (opp) {
          sendMsg(opp.ws, {
            type: 'remote_shot_fx',
            fx: {
              slot: session.slot,
              origin: msg.origin,
              hitPoint: msg.hitPoint,
              weaponId: msg.weaponId,
            },
          });
        }
        return;
      }

      if (msg.type === 'player_heal') {
        const self = room.players.get(session.slot);
        if (!self) return;
        const now = Date.now();
        if (now < self.respawnUntilMs) return;
        const cap = Math.max(50, Math.min(100, Math.round(msg.capHp)));
        const amount = Math.max(0, Math.min(100, Math.round(msg.amount)));
        if (self.hp < cap) {
          self.hp = Math.min(cap, self.hp + amount);
        }
        return;
      }

      if (msg.type === 'player_hit') {
        const attacker = room.players.get(session.slot);
        const victim = getOpponent(room, session.slot);
        if (!attacker || !victim) return;

        const now = Date.now();
        if (now < victim.respawnUntilMs || now < attacker.respawnUntilMs) return;

        const clampedDmg = Math.max(1, Math.min(150, Math.round(msg.damage)));
        victim.hp = Math.max(0, victim.hp - clampedDmg);

        const dmgEvent: ServerToClientMsg = {
          type: 'damage_event',
          victimSlot: victim.slot,
          attackerSlot: attacker.slot,
          victimHp: victim.hp,
          headshot: Boolean(msg.headshot),
        };
        sendMsg(attacker.ws, dmgEvent);
        sendMsg(victim.ws, dmgEvent);

        if (victim.hp <= 0) {
          attacker.kills += 1;
          victim.hp = 100;
          victim.respawnUntilMs = now + RESPAWN_DELAY_SEC * 1000;

          const p1Kills = room.players.get(1)?.kills ?? 0;
          const p2Kills = room.players.get(2)?.kills ?? 0;

          const killEvent: ServerToClientMsg = {
            type: 'kill_event',
            killerSlot: attacker.slot,
            victimSlot: victim.slot,
            p1Kills,
            p2Kills,
            headshot: Boolean(msg.headshot),
            respawnDelaySec: RESPAWN_DELAY_SEC,
          };
          sendMsg(attacker.ws, killEvent);
          sendMsg(victim.ws, killEvent);

          const winner = resolveDuelWinner(
            p1Kills,
            p2Kills,
            room.targetKills,
            getTimeRemainingSec(room, now),
          );
          if (winner !== null) {
            room.status = 'finished';
            room.winnerSlot = winner;
            broadcastRoomState(room, 'match_over');
          } else {
            broadcastRoomState(room, 'room_state');
          }
        }
      }
    });

    ws.on('close', () => {
      detachSocketFromRoom(ws);
    });
  });

  // 1Hz server match clock check for time-limit wins
  const clockInterval = setInterval(() => {
    const now = Date.now();
    for (const room of rooms.values()) {
      if (room.status !== 'playing') continue;
      const rem = getTimeRemainingSec(room, now);
      if (rem <= 0) {
        const p1Kills = room.players.get(1)?.kills ?? 0;
        const p2Kills = room.players.get(2)?.kills ?? 0;
        room.status = 'finished';
        room.winnerSlot = resolveDuelWinner(p1Kills, p2Kills, room.targetKills, 0);
        broadcastRoomState(room, 'match_over');
      }
    }
  }, 1000);

  await new Promise<void>((resolve, reject) => {
    const onError = (err: NodeJS.ErrnoException) => {
      if (err.code === 'EADDRINUSE' && desiredPort !== 0 && options.forceProd) {
        httpServer.removeListener('error', onError);
        httpServer.listen(0, '0.0.0.0');
        return;
      }
      reject(err);
    };

    httpServer.once('error', onError);
    httpServer.once('listening', () => {
      httpServer.removeListener('error', onError);
      const addr = httpServer.address();
      if (addr && typeof addr !== 'string') {
        activePort = addr.port;
      }
      console.log(`OPERATION: BLACK HORIZON server listening on http://0.0.0.0:${activePort}`);
      resolve();
    });
    httpServer.listen(desiredPort, '0.0.0.0');
  });

  return {
    httpServer,
    wss,
    port: activePort,
    close: async () => {
      clearInterval(clockInterval);
      wss.close();
      await new Promise<void>((resolve) => {
        httpServer.close(() => resolve());
      });
    },
  };
}

if (process.env.BLACK_HORIZON_EMBEDDED !== '1') {
  void startServer();
}
