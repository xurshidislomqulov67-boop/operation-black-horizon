# OPERATION: BLACK HORIZON — Windows `.exe` Yasash Qo'llanmasi

Ushbu loyihada tayyor **`.exe`** olishning **2 ta usuli** bor.

---

## 1-usul: Hech qanday dastur o'rnatmasdan GitHub Actions orqali (Tavsiya etiladi)

Kompyuteringizga Node.js yoki boshqa dastur o'rnatish **shart emas**. GitHub'ning o'zi bulutda `.exe` faylni yig'ib beradi:

1. **GitHub'da yangi repository oching**:
   - https://github.com/new saytiga kiring, nom bering (masalan, `operation-black-horizon`) va `Create repository` ni bosing.
2. **Loyiha fayllarini yuklang**:
   - AI Studio'dan loyihani **Download / Export ZIP** qilib yuklab oling va papkaga chiqaring.
   - GitHub'da **`uploading an existing file`** tugmasini bosib papkadagi barcha fayl va papkalarni (shu jumladan **`.github`** papkasini ham!) tashlang va **`Commit changes`** ni bosing.
   - *(Agar fayllar ko'p bo'lsa, GitHub Desktop yoki `git push` orqali yuklash yanada oson.)*
3. **Avtomatik yig'ilishni kuting (2–4 daqiqa)**:
   - Repository'ning yuqori menyusidan **`Actions`** bo'limiga kiring.
   - **`Build Windows EXE`** jarayoni avtomatik ishlaydi (yoki o'zingiz **`Run workflow`** tugmasini bosishingiz mumkin).
4. **Tayyor `.exe` ni yuklab oling**:
   - Jarayon yashil ✅ bo'lib tugagach, o'sha run'ni oching va pastdagi **`Artifacts`** bo'limidan **`Operation-Black-Horizon-Windows-EXE`** ni yuklab oling.
   - ZIP ichida 2 ta tayyor fayl bo'ladi:
     - `Operation-Black-Horizon-Portable-1.0.0.exe` (o'rnatishsiz darhol ochiladi)
     - `Operation-Black-Horizon-Setup-1.0.0.exe` (o'rnatuvchi)

---

## 2-usul: O'z Windows kompyuteringizda yasash (Node.js bilan)

1. https://nodejs.org saytidan **Node.js LTS** o'rnating.
2. Loyiha papkasida terminal (`cmd`) ochib quyidagilarni bajaring:
   ```bash
   npm install
   npm run dist:win
   ```
3. Tayyor `.exe` fayllar **`release/`** papkasida paydo bo'ladi.

---

## Hotspot orqali 1v1 o'ynash (Muhim!)
1. Kompyuteringizda **Mobile Hotspot** ni yoqing, do'stingiz shu Hotspot'ga ulansin.
2. `.exe` o'yinni oching. Windows Firewall so'rasa, **Allow access / Ruxsat berish** ni bosing.
3. O'yin ichida **`1v1 HOTSPOT` → `XONA OCHISH`** ni bosing va chiqqan havolani (`http://192.168.x.x:3000/?room=XXXX`) do'stingizga bering.
4. To'liq ekran uchun **`F11`** tugmasidan foydalaning.
